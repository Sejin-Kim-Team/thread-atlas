"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../packages/shared/dist/types/api.js
  var require_api = __commonJS({
    "../../packages/shared/dist/types/api.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/auth-session.js
  var require_auth_session = __commonJS({
    "../../packages/shared/dist/types/auth-session.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/article.js
  var require_article = __commonJS({
    "../../packages/shared/dist/types/article.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context.js
  var require_context = __commonJS({
    "../../packages/shared/dist/types/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context-pack.js
  var require_context_pack = __commonJS({
    "../../packages/shared/dist/types/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/intent.js
  var require_intent = __commonJS({
    "../../packages/shared/dist/types/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/memory.js
  var require_memory = __commonJS({
    "../../packages/shared/dist/types/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/projection.js
  var require_projection = __commonJS({
    "../../packages/shared/dist/types/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantic-snapshot.js
  var require_semantic_snapshot = __commonJS({
    "../../packages/shared/dist/types/semantic-snapshot.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantics.js
  var require_semantics = __commonJS({
    "../../packages/shared/dist/types/semantics.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/state.js
  var require_state = __commonJS({
    "../../packages/shared/dist/types/state.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/thread.js
  var require_thread = __commonJS({
    "../../packages/shared/dist/types/thread.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/constants/limits.js
  var require_limits = __commonJS({
    "../../packages/shared/dist/constants/limits.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.MAX_ACTIVE_TOPICS = exports.MAX_CONTEXT_TURNS = exports.TOKEN_RENEWAL_BUFFER_SECONDS = exports.TOKEN_TTL_SECONDS = exports.TOOL_TIMEOUT_MS = exports.LOOP_TIMEOUT_MS = exports.MAX_LOOPS = void 0;
      exports.MAX_LOOPS = 8;
      exports.LOOP_TIMEOUT_MS = 3e4;
      exports.TOOL_TIMEOUT_MS = 1e4;
      exports.TOKEN_TTL_SECONDS = 600;
      exports.TOKEN_RENEWAL_BUFFER_SECONDS = 120;
      exports.MAX_CONTEXT_TURNS = 10;
      exports.MAX_ACTIVE_TOPICS = 10;
    }
  });

  // ../../packages/shared/dist/constants/defaults.js
  var require_defaults = __commonJS({
    "../../packages/shared/dist/constants/defaults.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.CONTEXT_LIMITS = exports.EMPTY_CONVERSATION_CONTEXT = exports.DEFAULT_API_BASE_URL = exports.DEFAULT_USER_ID = void 0;
      var limits_1 = require_limits();
      exports.DEFAULT_USER_ID = "user_sungwoo";
      exports.DEFAULT_API_BASE_URL = "http://localhost:8080";
      exports.EMPTY_CONVERSATION_CONTEXT = {
        turns: [],
        activeTopics: [],
        threadUrl: ""
      };
      exports.CONTEXT_LIMITS = {
        maxTurns: limits_1.MAX_CONTEXT_TURNS,
        maxActiveTopics: limits_1.MAX_ACTIVE_TOPICS
      };
    }
  });

  // ../../packages/shared/dist/utils/context.js
  var require_context2 = __commonJS({
    "../../packages/shared/dist/utils/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.trimTurns = trimTurns;
      exports.appendTurn = appendTurn;
      exports.setActiveTopics = setActiveTopics;
      var defaults_1 = require_defaults();
      function trimTurns(turns) {
        if (turns.length <= defaults_1.CONTEXT_LIMITS.maxTurns) {
          return turns;
        }
        return turns.slice(turns.length - defaults_1.CONTEXT_LIMITS.maxTurns);
      }
      function appendTurn(context, turn) {
        return {
          ...context,
          turns: trimTurns([...context.turns, turn])
        };
      }
      function setActiveTopics(context, topics) {
        return {
          ...context,
          activeTopics: topics.slice(0, defaults_1.CONTEXT_LIMITS.maxActiveTopics)
        };
      }
    }
  });

  // ../../packages/shared/dist/utils/hash.js
  var require_hash = __commonJS({
    "../../packages/shared/dist/utils/hash.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.hashUrl = hashUrl;
      function intToFixedHex(value) {
        return (value >>> 0).toString(16).padStart(8, "0");
      }
      function hashUrl(url) {
        let h1 = 2654435769;
        let h2 = 2246822507;
        for (let i = 0; i < url.length; i += 1) {
          const code = url.charCodeAt(i);
          h1 = Math.imul(h1 ^ code, 2246822519);
          h2 = Math.imul(h2 ^ code, 3266489917);
        }
        return `${intToFixedHex(h1)}${intToFixedHex(h2)}`.slice(0, 16);
      }
    }
  });

  // ../../packages/shared/dist/utils/context-pack.js
  var require_context_pack2 = __commonJS({
    "../../packages/shared/dist/utils/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = buildContextPack;
      exports.selectProjectionView = selectProjectionView;
      exports.renderContextPack = renderContextPack;
      exports.renderCompactJson = renderCompactJson;
      exports.renderLinearText = renderLinearText;
      function isCommentNode(node) {
        return node.kind === "comment";
      }
      function isInteractiveNode(node) {
        return node.kind === "interactive";
      }
      function toContextPackNode(node, relation, distance) {
        if (isCommentNode(node)) {
          return {
            id: node.id,
            kind: "comment",
            relation,
            distance,
            text: node.text,
            ...node.author ? { author: node.author } : {},
            ...node.timestamp ? { timestamp: node.timestamp } : {},
            depth: node.depth,
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        if (isInteractiveNode(node)) {
          return {
            id: node.id,
            kind: "interactive",
            relation,
            distance,
            text: node.label ?? node.valuePreview ?? "",
            controlType: node.controlType,
            ...node.action ? { action: node.action } : {},
            ...node.state ? { state: node.state } : {},
            ...node.role ? { role: node.role } : {},
            ...node.valuePreview ? { valuePreview: node.valuePreview } : {},
            ...node.label ? { label: node.label } : {},
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        return {
          id: node.id,
          kind: "content",
          relation,
          distance,
          text: node.text,
          contentType: node.type,
          ...node.level ? { level: node.level } : {},
          ...node.parentId ? { parentId: node.parentId } : {},
          ...node.attributes ? { metadata: node.attributes } : {}
        };
      }
      function mapSlices(snapshot, relation) {
        return snapshot.context.map((slice, originalIndex) => ({ slice, originalIndex })).filter(({ slice }) => slice.relation === relation).map(({ slice, originalIndex }) => ({
          ...toContextPackNode(slice.node, relation === "child" ? "descendant" : relation === "container" ? "container" : relation === "sibling" ? "sibling" : "ancestor", slice.distance),
          originalIndex
        }));
      }
      function buildOmitted(snapshot) {
        const coverage = snapshot.meta.coverage;
        if (!coverage) {
          return {
            nodeCount: 0,
            rootCount: 0,
            note: "Coverage metadata unavailable."
          };
        }
        return {
          nodeCount: coverage.omittedNodeCount,
          rootCount: coverage.omittedRootCount,
          note: `Only the ${coverage.kind} semantic scope is included.`
        };
      }
      function buildScope(snapshot) {
        const coverage = snapshot.meta.coverage;
        return {
          kind: coverage?.kind ?? (isCommentNode(snapshot.focus.node) ? "focus-branch" : "focus-section"),
          rootNodeId: coverage?.rootNodeId ?? snapshot.focus.nodeId,
          focusNodeId: snapshot.focus.nodeId
        };
      }
      function buildProjectionFocusNode(pack) {
        const { metadata: _metadata, relation: _relation, distance: _distance, ...focus } = pack.focus;
        return focus;
      }
      function includeByProfile(node, group, profile) {
        if (group === "containers") {
          return false;
        }
        if (profile === "branch-summary") {
          return true;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        if (group === "ancestors") {
          return node.distance === 1;
        }
        if (group === "descendants") {
          return node.distance === 1;
        }
        if (group === "siblings") {
          return node.distance === 1;
        }
        return false;
      }
      function formatNodeSummary(node) {
        const headerParts = [
          node.author,
          node.timestamp,
          node.kind === "interactive" && node.controlType ? node.controlType : null,
          node.kind === "interactive" && node.action ? node.action : null,
          node.kind === "interactive" && node.state ? node.state : null,
          node.kind === "content" && node.contentType ? node.contentType : null
        ].filter(Boolean);
        if (headerParts.length === 0) {
          return `- ${node.text || node.valuePreview || "(empty)"}`;
        }
        return `- ${headerParts.join(", ")}: ${node.text || node.valuePreview || "(empty)"}`;
      }
      function buildContextPack(snapshot) {
        const ancestors = [
          ...mapSlices(snapshot, "parent"),
          ...mapSlices(snapshot, "ancestor")
        ].sort((left, right) => right.distance - left.distance || left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const descendants = mapSlices(snapshot, "child").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const siblings = mapSlices(snapshot, "sibling").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const containers = mapSlices(snapshot, "container").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        return {
          version: 1,
          scope: buildScope(snapshot),
          page: {
            id: snapshot.page.id,
            url: snapshot.page.url,
            ...snapshot.page.title ? { title: snapshot.page.title } : {},
            kind: snapshot.page.kind,
            ...snapshot.page.metadata ? { metadata: snapshot.page.metadata } : {}
          },
          focus: toContextPackNode(snapshot.focus.node, "focus", 0),
          groups: {
            ancestors,
            descendants,
            siblings,
            containers
          },
          omitted: buildOmitted(snapshot),
          provenance: {
            extractorId: snapshot.meta.extractorId,
            capturedAt: snapshot.meta.capturedAt,
            skeletonVersion: snapshot.meta.skeletonVersion
          }
        };
      }
      function selectProjectionView(pack, profile) {
        const groups = {
          ancestors: pack.groups.ancestors.filter((node) => includeByProfile(node, "ancestors", profile)),
          descendants: pack.groups.descendants.filter((node) => includeByProfile(node, "descendants", profile)),
          siblings: pack.groups.siblings.filter((node) => includeByProfile(node, "siblings", profile)),
          containers: pack.groups.containers.filter((node) => includeByProfile(node, "containers", profile))
        };
        return {
          scope: pack.scope,
          page: {
            ...pack.page.title ? { title: pack.page.title } : {},
            url: pack.page.url,
            kind: pack.page.kind
          },
          focus: buildProjectionFocusNode(pack),
          groups,
          omitted: pack.omitted,
          provenance: {
            extractorId: pack.provenance.extractorId,
            capturedAt: pack.provenance.capturedAt
          }
        };
      }
      function renderContextPack(pack) {
        return JSON.stringify(pack, null, 2);
      }
      function renderCompactJson(pack, profile) {
        return JSON.stringify(selectProjectionView(pack, profile), null, 2);
      }
      function renderLinearText(pack, profile) {
        const view = selectProjectionView(pack, profile);
        const lines = [
          `Page: ${view.page.title ?? "(untitled)"}`,
          `URL: ${view.page.url}`,
          `Kind: ${view.page.kind}`,
          `Scope: ${view.scope.kind}`,
          ""
        ];
        const sections = [
          ["Ancestors", view.groups.ancestors],
          ["Focus", [pack.focus]],
          ["Descendants", view.groups.descendants],
          ["Siblings", view.groups.siblings]
        ];
        for (const [label, nodes] of sections) {
          const groupKey = label === "Ancestors" ? "ancestors" : label === "Descendants" ? "descendants" : label === "Siblings" ? "siblings" : null;
          if (groupKey && !projectionIncludesGroup(profile, groupKey)) {
            continue;
          }
          lines.push(label);
          if (nodes.length === 0) {
            lines.push("- none");
          } else {
            for (const node of nodes) {
              lines.push(formatNodeSummary(node));
            }
          }
          lines.push("");
        }
        lines.push("Omitted");
        lines.push(`- ${view.omitted.nodeCount} nodes omitted`);
        lines.push(`- ${view.omitted.rootCount} roots omitted`);
        lines.push(`- ${view.omitted.note}`);
        return lines.join("\n");
      }
      function projectionIncludesGroup(profile, group) {
        if (group === "containers") {
          return false;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        return true;
      }
    }
  });

  // ../../packages/shared/dist/factories/intent.js
  var require_intent2 = __commonJS({
    "../../packages/shared/dist/factories/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createUserSpeechIntent = createUserSpeechIntent;
      exports.createUserSelectionIntent = createUserSelectionIntent;
      exports.createPageNavigationIntent = createPageNavigationIntent;
      function createUserSpeechIntent(transcript, intentType = "general") {
        return {
          type: "UserSpeech",
          transcript,
          intentType
        };
      }
      function createUserSelectionIntent(transcript) {
        return {
          type: "UserSelection",
          transcript,
          intentType: "memory_query"
        };
      }
      function createPageNavigationIntent(transcript) {
        return {
          type: "PageNavigation",
          transcript,
          intentType: "navigation_request"
        };
      }
    }
  });

  // ../../packages/shared/dist/factories/memory.js
  var require_memory2 = __commonJS({
    "../../packages/shared/dist/factories/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createEmptyInterestProfile = createEmptyInterestProfile;
      exports.createMemoryDelta = createMemoryDelta;
      exports.mergeTopicDeltas = mergeTopicDeltas;
      function createEmptyInterestProfile() {
        return {
          topics: {},
          updatedAt: Date.now()
        };
      }
      function createMemoryDelta(topicDeltas, highlights = []) {
        return {
          interestProfile: { topicDeltas },
          threadHistory: {
            highlights,
            turnCountDelta: 1
          }
        };
      }
      function mergeTopicDeltas(base, incoming) {
        const merged = { ...base };
        for (const [topic, count] of Object.entries(incoming)) {
          merged[topic] = (merged[topic] ?? 0) + count;
        }
        return merged;
      }
    }
  });

  // ../../packages/shared/dist/factories/projection.js
  var require_projection2 = __commonJS({
    "../../packages/shared/dist/factories/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.respond = respond;
      exports.focus = focus;
      exports.focusMultiple = focusMultiple;
      exports.navigate = navigate;
      exports.present = present;
      exports.notify = notify;
      exports.copy = copy;
      function respond(text, mode = "answer") {
        return { type: "respond", payload: { text, mode } };
      }
      function focus(commentId, options) {
        if (options) {
          return { type: "focus", payload: { commentId, options } };
        }
        return { type: "focus", payload: { commentId } };
      }
      function focusMultiple(targets, options) {
        if (options) {
          return { type: "focusMultiple", payload: { targets, options } };
        }
        return { type: "focusMultiple", payload: { targets } };
      }
      function navigate(url, options) {
        if (options) {
          return { type: "navigate", payload: { url, options } };
        }
        return { type: "navigate", payload: { url } };
      }
      function present(target, content, persistent = false) {
        return {
          type: "present",
          payload: {
            target,
            content,
            options: { persistent }
          }
        };
      }
      function notify(message, level = "info") {
        return {
          type: "notify",
          payload: { message, level }
        };
      }
      function copy(text) {
        return { type: "copy", payload: { text } };
      }
    }
  });

  // ../../packages/shared/dist/domain.js
  var require_domain = __commonJS({
    "../../packages/shared/dist/domain.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = void 0;
      __exportStar(require_api(), exports);
      __exportStar(require_auth_session(), exports);
      __exportStar(require_article(), exports);
      __exportStar(require_context(), exports);
      __exportStar(require_context_pack(), exports);
      __exportStar(require_intent(), exports);
      __exportStar(require_memory(), exports);
      __exportStar(require_projection(), exports);
      __exportStar(require_semantic_snapshot(), exports);
      __exportStar(require_semantics(), exports);
      __exportStar(require_state(), exports);
      __exportStar(require_thread(), exports);
      __exportStar(require_defaults(), exports);
      __exportStar(require_limits(), exports);
      __exportStar(require_context2(), exports);
      __exportStar(require_hash(), exports);
      var context_pack_1 = require_context_pack2();
      Object.defineProperty(exports, "buildContextPack", { enumerable: true, get: function() {
        return context_pack_1.buildContextPack;
      } });
      __exportStar(require_intent2(), exports);
      __exportStar(require_memory2(), exports);
      __exportStar(require_projection2(), exports);
    }
  });

  // ../../packages/shared/dist/index.js
  var require_dist = __commonJS({
    "../../packages/shared/dist/index.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      __exportStar(require_domain(), exports);
    }
  });

  // src/common/semantic-url.ts
  function isSemanticCaptureSupportedUrl(url) {
    return /^https?:\/\//.test(url ?? "");
  }

  // src/background/semantic-snapshot.ts
  var SEMANTIC_SNAPSHOT_COMMAND = "capture-snapshot";
  var SEMANTIC_SELECTION_COMMAND = "toggle-selection";
  var SEMANTIC_SNAPSHOT_CONTEXT_MENU_ID = "capture-semantic-snapshot";
  var SEMANTIC_HISTORY_LIMIT = 20;
  function buildReadyPayload(tabId, response) {
    return {
      tabId,
      snapshot: response.snapshot,
      error: response.error
    };
  }
  function buildHistoryPayload(tabId, snapshots) {
    return {
      tabId,
      snapshots
    };
  }
  function normalizeCaptureResponse(result) {
    if (result && typeof result === "object" && "snapshot" in result && "error" in result) {
      return result;
    }
    return {
      snapshot: null,
      error: "Semantic snapshot capture failed."
    };
  }
  function normalizeSelectionResponse(result) {
    if (result && typeof result === "object" && "enabled" in result && "selectedTarget" in result) {
      return result;
    }
    return {
      enabled: false,
      selectedTarget: null
    };
  }
  function normalizeRegionDumpResponse(result) {
    if (result && typeof result === "object" && "dump" in result) {
      return result;
    }
    return {
      dump: null
    };
  }
  function createSemanticSnapshotCoordinator(bridge) {
    const latestSnapshots = /* @__PURE__ */ new Map();
    const snapshotHistory = /* @__PURE__ */ new Map();
    const selectionState = /* @__PURE__ */ new Map();
    async function captureForTab(tabId, source, options = {}) {
      const { openPanel = true } = options;
      if (tabId === null) {
        const payload2 = buildReadyPayload(null, {
          snapshot: null,
          error: "No active tab available for semantic snapshot capture."
        });
        bridge.notifyRuntime({ type: "SEMANTIC_SNAPSHOT_READY", payload: payload2 });
        return payload2;
      }
      const tab = await bridge.getTab(tabId);
      if (!tab || !isSemanticCaptureSupportedUrl(tab.url)) {
        const payload2 = buildReadyPayload(tabId, {
          snapshot: null,
          error: "Semantic snapshots are only supported on standard web pages."
        });
        latestSnapshots.set(tabId, {
          snapshot: null,
          error: payload2.error
        });
        if (openPanel) {
          await bridge.openSidePanel(tabId);
        }
        bridge.notifyRuntime({ type: "SEMANTIC_SNAPSHOT_READY", payload: payload2 });
        return payload2;
      }
      let result;
      try {
        result = normalizeCaptureResponse(
          await bridge.sendToContentScript(tabId, {
            type: "CAPTURE_SEMANTIC_SNAPSHOT",
            payload: { source }
          })
        );
      } catch (error) {
        result = {
          snapshot: null,
          error: error instanceof Error ? error.message : "Semantic snapshot capture failed."
        };
      }
      latestSnapshots.set(tabId, result);
      if (result.snapshot) {
        const existing = snapshotHistory.get(tabId) ?? [];
        const nextHistory = [result.snapshot, ...existing].slice(0, SEMANTIC_HISTORY_LIMIT);
        snapshotHistory.set(tabId, nextHistory);
        bridge.notifyRuntime({
          type: "SEMANTIC_SNAPSHOT_HISTORY_UPDATED",
          payload: buildHistoryPayload(tabId, nextHistory)
        });
      }
      if (openPanel) {
        await bridge.openSidePanel(tabId);
      }
      const payload = buildReadyPayload(tabId, result);
      bridge.notifyRuntime({ type: "SEMANTIC_SNAPSHOT_READY", payload });
      return payload;
    }
    async function captureActiveTab(preferredTabId, source = "command", options = {}) {
      if (typeof preferredTabId === "number") {
        return captureForTab(preferredTabId, source, options);
      }
      const activeTab = await bridge.getActiveTab();
      return captureForTab(activeTab?.id ?? null, source, options);
    }
    async function getLatest(preferredTabId) {
      let tabId = preferredTabId ?? null;
      if (tabId === null) {
        tabId = (await bridge.getActiveTab())?.id ?? null;
      }
      if (tabId === null) {
        return {
          tabId: null,
          snapshot: null,
          error: null
        };
      }
      const cached = latestSnapshots.get(tabId);
      return {
        tabId,
        snapshot: cached?.snapshot ?? null,
        error: cached?.error ?? null
      };
    }
    async function getHistory(preferredTabId) {
      let tabId = preferredTabId ?? null;
      if (tabId === null) {
        tabId = (await bridge.getActiveTab())?.id ?? null;
      }
      return buildHistoryPayload(tabId, tabId === null ? [] : snapshotHistory.get(tabId) ?? []);
    }
    async function toggleSelectionMode(preferredTabId) {
      let tabId = preferredTabId ?? null;
      if (tabId === null) {
        tabId = (await bridge.getActiveTab())?.id ?? null;
      }
      if (tabId === null) {
        const payload2 = { tabId: null, enabled: false, selectedTarget: null };
        bridge.notifyRuntime({ type: "SEMANTIC_SELECTION_STATE_CHANGED", payload: payload2 });
        return payload2;
      }
      const response = normalizeSelectionResponse(
        await bridge.sendToContentScript(tabId, {
          type: "TOGGLE_SEMANTIC_SELECTION"
        })
      );
      selectionState.set(tabId, response);
      const payload = { tabId, enabled: response.enabled, selectedTarget: response.selectedTarget };
      bridge.notifyRuntime({ type: "SEMANTIC_SELECTION_STATE_CHANGED", payload });
      return payload;
    }
    async function getSelectionState(preferredTabId) {
      let tabId = preferredTabId ?? null;
      if (tabId === null) {
        tabId = (await bridge.getActiveTab())?.id ?? null;
      }
      if (tabId === null) {
        return { tabId: null, enabled: false, selectedTarget: null };
      }
      if (selectionState.has(tabId)) {
        const cached = selectionState.get(tabId);
        return {
          tabId,
          enabled: cached?.enabled ?? false,
          selectedTarget: cached?.selectedTarget ?? null
        };
      }
      const response = normalizeSelectionResponse(
        await bridge.sendToContentScript(tabId, {
          type: "GET_SEMANTIC_SELECTION_STATE"
        })
      );
      selectionState.set(tabId, response);
      return {
        tabId,
        enabled: response.enabled,
        selectedTarget: response.selectedTarget
      };
    }
    async function clearSelection(preferredTabId) {
      let tabId = preferredTabId ?? null;
      if (tabId === null) {
        tabId = (await bridge.getActiveTab())?.id ?? null;
      }
      if (tabId === null) {
        const payload2 = { tabId: null, enabled: false, selectedTarget: null };
        bridge.notifyRuntime({ type: "SEMANTIC_SELECTION_STATE_CHANGED", payload: payload2 });
        return payload2;
      }
      const response = normalizeSelectionResponse(
        await bridge.sendToContentScript(tabId, {
          type: "CLEAR_SEMANTIC_SELECTION"
        })
      );
      selectionState.set(tabId, response);
      const payload = { tabId, enabled: response.enabled, selectedTarget: response.selectedTarget };
      bridge.notifyRuntime({ type: "SEMANTIC_SELECTION_STATE_CHANGED", payload });
      return payload;
    }
    async function getRegionDump(preferredTabId) {
      let tabId = preferredTabId ?? null;
      if (tabId === null) {
        tabId = (await bridge.getActiveTab())?.id ?? null;
      }
      if (tabId === null) {
        return {
          tabId: null,
          dump: null,
          error: "No active tab available for semantic region dump."
        };
      }
      const tab = await bridge.getTab(tabId);
      if (!tab || !isSemanticCaptureSupportedUrl(tab.url)) {
        return {
          tabId,
          dump: null,
          error: "Semantic region dumps are only supported on standard web pages."
        };
      }
      try {
        const response = normalizeRegionDumpResponse(
          await bridge.sendToContentScript(tabId, {
            type: "GET_SEMANTIC_REGION_DUMP"
          })
        );
        return {
          tabId,
          dump: response.dump,
          error: response.dump ? null : "Semantic region dump unavailable on this page."
        };
      } catch (error) {
        return {
          tabId,
          dump: null,
          error: error instanceof Error ? error.message : "Semantic region dump lookup failed."
        };
      }
    }
    function syncSelectionState(tabId, response, capture) {
      if (tabId === null) {
        return { tabId: null, enabled: response.enabled, selectedTarget: response.selectedTarget };
      }
      selectionState.set(tabId, response);
      if (capture) {
        latestSnapshots.set(tabId, capture);
        if (capture.snapshot) {
          const existing = snapshotHistory.get(tabId) ?? [];
          const nextHistory = [capture.snapshot, ...existing].slice(0, SEMANTIC_HISTORY_LIMIT);
          snapshotHistory.set(tabId, nextHistory);
          bridge.notifyRuntime({
            type: "SEMANTIC_SNAPSHOT_HISTORY_UPDATED",
            payload: buildHistoryPayload(tabId, nextHistory)
          });
        }
        bridge.notifyRuntime({
          type: "SEMANTIC_SNAPSHOT_READY",
          payload: buildReadyPayload(tabId, capture)
        });
      }
      const payload = { tabId, enabled: response.enabled, selectedTarget: response.selectedTarget };
      bridge.notifyRuntime({ type: "SEMANTIC_SELECTION_STATE_CHANGED", payload });
      return payload;
    }
    return {
      captureActiveTab,
      captureForTab,
      getLatest,
      getHistory,
      toggleSelectionMode,
      getSelectionState,
      getRegionDump,
      clearSelection,
      syncSelectionState
    };
  }

  // src/common/extension-config.ts
  var import_shared = __toESM(require_dist());
  var API_BASE_URL_KEY = "THREADATLAS_API_BASE_URL";
  var GOOGLE_OAUTH_CLIENT_ID_KEY = "THREADATLAS_GOOGLE_OAUTH_CLIENT_ID";
  var AUTH_GRANT_TYPE_KEY = "THREADATLAS_AUTH_GRANT_TYPE";
  var BOOTSTRAP_SUBJECT_KEY = "THREADATLAS_BOOTSTRAP_SUBJECT";
  var BOOTSTRAP_KEY_KEY = "THREADATLAS_AUTH_BOOTSTRAP_KEY";
  var DISPLAY_NAME_KEY = "THREADATLAS_AUTH_DISPLAY_NAME";
  var PRIMARY_EMAIL_KEY = "THREADATLAS_AUTH_PRIMARY_EMAIL";
  var AVATAR_URL_KEY = "THREADATLAS_AUTH_AVATAR_URL";
  var EXTENSION_CONFIG_KEYS = [
    API_BASE_URL_KEY,
    GOOGLE_OAUTH_CLIENT_ID_KEY,
    AUTH_GRANT_TYPE_KEY,
    BOOTSTRAP_SUBJECT_KEY,
    BOOTSTRAP_KEY_KEY,
    DISPLAY_NAME_KEY,
    PRIMARY_EMAIL_KEY,
    AVATAR_URL_KEY
  ];
  function normalizeText(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }
  function readCompiledApiBaseUrl() {
    if (true) {
      const normalized = normalizeText("http://localhost:8080");
      if (normalized) {
        return normalized;
      }
    }
    return import_shared.DEFAULT_API_BASE_URL;
  }
  function readCompiledGoogleClientId() {
    if (true) {
      return normalizeText("");
    }
    return null;
  }
  function createChromeLocalStorage(area = chrome.storage.local) {
    return {
      get(keys) {
        return new Promise((resolve, reject) => {
          area.get(keys, (items) => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve(items);
          });
        });
      },
      set(values) {
        return new Promise((resolve, reject) => {
          area.set(values, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      },
      remove(keys) {
        return new Promise((resolve, reject) => {
          area.remove(keys, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      }
    };
  }
  async function loadExtensionConfig(storage = createChromeLocalStorage()) {
    const stored = await storage.get(EXTENSION_CONFIG_KEYS);
    const apiBaseUrl = normalizeText(stored[API_BASE_URL_KEY]) ?? readCompiledApiBaseUrl();
    const googleOAuthClientId = normalizeText(stored[GOOGLE_OAUTH_CLIENT_ID_KEY]) ?? readCompiledGoogleClientId();
    const configuredGrant = normalizeText(stored[AUTH_GRANT_TYPE_KEY]);
    const bootstrapSubject = normalizeText(stored[BOOTSTRAP_SUBJECT_KEY]);
    const bootstrapKey = normalizeText(stored[BOOTSTRAP_KEY_KEY]);
    let devBootstrap = null;
    if (configuredGrant === "dev-bootstrap" && bootstrapSubject && bootstrapKey) {
      const profile = {};
      const displayName = normalizeText(stored[DISPLAY_NAME_KEY]);
      const primaryEmail = normalizeText(stored[PRIMARY_EMAIL_KEY]);
      const avatarUrl = normalizeText(stored[AVATAR_URL_KEY]);
      if (displayName) {
        profile.displayName = displayName;
      }
      if (primaryEmail) {
        profile.primaryEmail = primaryEmail;
      }
      if (avatarUrl) {
        profile.avatarUrl = avatarUrl;
      }
      devBootstrap = {
        bootstrapSubject,
        bootstrapKey,
        ...Object.keys(profile).length > 0 ? { profile } : {}
      };
    }
    return {
      apiBaseUrl,
      googleOAuthClientId,
      devBootstrap
    };
  }

  // src/background/auth-manager.ts
  var AUTH_STATE_STORAGE_KEY = "THREADATLAS_AUTH_STATE";
  var SESSION_RENEWAL_SAFETY_WINDOW_SECONDS = 5 * 60;
  function normalizeText2(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }
  function normalizeAuthState(value) {
    if (!value || typeof value !== "object") {
      return null;
    }
    const candidate = value;
    const status = candidate.status;
    if (status !== "signed-out" && status !== "signing-in" && status !== "signed-in" && status !== "refreshing" && status !== "error") {
      return null;
    }
    const provider = candidate.provider === "google" || candidate.provider === "dev-bootstrap" ? candidate.provider : null;
    const user = candidate.user && typeof candidate.user === "object" && typeof candidate.user.id === "string" ? {
      id: candidate.user.id,
      ...normalizeText2(candidate.user.displayName) ? { displayName: normalizeText2(candidate.user.displayName) } : {},
      ...normalizeText2(candidate.user.primaryEmail) ? { primaryEmail: normalizeText2(candidate.user.primaryEmail) } : {},
      ...normalizeText2(candidate.user.avatarUrl) ? { avatarUrl: normalizeText2(candidate.user.avatarUrl) } : {}
    } : null;
    const session = candidate.session && typeof candidate.session === "object" && typeof candidate.session.token === "string" && typeof candidate.session.expiresAt === "number" ? {
      token: candidate.session.token,
      expiresAt: candidate.session.expiresAt
    } : null;
    const errorMessage = normalizeText2(candidate.errorMessage) ?? void 0;
    return {
      status,
      provider,
      user,
      session,
      ...errorMessage ? { errorMessage } : {}
    };
  }
  function createSignedOutState(errorMessage) {
    return {
      status: "signed-out",
      provider: null,
      user: null,
      session: null,
      ...errorMessage ? { errorMessage } : {}
    };
  }
  function createErrorState(errorMessage, provider = "google") {
    return {
      status: "error",
      provider,
      user: null,
      session: null,
      errorMessage
    };
  }
  function isSessionFresh(expiresAt, nowMs) {
    return expiresAt - Math.floor(nowMs / 1e3) > SESSION_RENEWAL_SAFETY_WINDOW_SECONDS;
  }
  function bufferToBase64Url(bytes) {
    let binary = "";
    for (const byte of bytes) {
      binary += String.fromCharCode(byte);
    }
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }
  function randomBase64Url(length = 24) {
    const bytes = new Uint8Array(length);
    crypto.getRandomValues(bytes);
    return bufferToBase64Url(bytes);
  }
  function decodeJwtPayload(token) {
    const segments = token.split(".");
    if (segments.length !== 3) {
      return null;
    }
    const payload = segments[1];
    if (!payload) {
      return null;
    }
    try {
      const padded = payload.replace(/-/g, "+").replace(/_/g, "/");
      const normalized = padded + "=".repeat((4 - (padded.length % 4 || 4)) % 4);
      const decoded = atob(normalized);
      const parsed = JSON.parse(decoded);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        return parsed;
      }
    } catch {
    }
    return null;
  }
  function parseGoogleAuthRedirect(args) {
    const url = new URL(args.redirectUrl);
    const params = new URLSearchParams(url.hash.startsWith("#") ? url.hash.slice(1) : url.hash);
    const error = normalizeText2(params.get("error"));
    if (error) {
      if (error === "access_denied") {
        throw new Error("Google sign-in was cancelled.");
      }
      throw new Error(`Google sign-in failed (${error}).`);
    }
    const state = normalizeText2(params.get("state"));
    if (!state || state !== args.expectedState) {
      throw new Error("Google sign-in returned an invalid state.");
    }
    const idToken = normalizeText2(params.get("id_token"));
    if (!idToken) {
      throw new Error("Google sign-in did not return an ID token.");
    }
    const payload = decodeJwtPayload(idToken);
    const nonce = normalizeText2(payload?.nonce);
    if (!nonce || nonce !== args.expectedNonce) {
      throw new Error("Google sign-in returned an invalid nonce.");
    }
    return idToken;
  }
  function buildGoogleAuthorizeUrl(args) {
    const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    url.searchParams.set("client_id", args.clientId);
    url.searchParams.set("response_type", "id_token");
    url.searchParams.set("redirect_uri", args.redirectUri);
    url.searchParams.set("scope", "openid email profile");
    url.searchParams.set("state", args.state);
    url.searchParams.set("nonce", args.nonce);
    url.searchParams.set("prompt", args.interactive ? "select_account consent" : "none");
    url.searchParams.set("include_granted_scopes", "true");
    return url.toString();
  }
  async function readPersistedAuthState(storage) {
    const items = await storage.get([AUTH_STATE_STORAGE_KEY]);
    const persisted = normalizeAuthState(items[AUTH_STATE_STORAGE_KEY]);
    return persisted ?? createSignedOutState();
  }
  function createExtensionAuthManager(args) {
    const fetchImpl = args.fetchImpl ?? fetch;
    const launchWebAuthFlow = args.launchWebAuthFlow ?? (async (details) => chrome.identity.launchWebAuthFlow({
      url: details.url,
      interactive: details.interactive
    }));
    const getRedirectUrl = args.getRedirectUrl ?? ((path) => chrome.identity.getRedirectURL(path));
    const loadConfig = args.loadConfig ?? (() => loadExtensionConfig(args.storage));
    const now = args.now ?? (() => Date.now());
    const broadcastAuthState = args.broadcastAuthState ?? (() => {
    });
    let ensureInFlight = null;
    let signInInFlight = null;
    async function writeState(next) {
      await args.storage.set({
        [AUTH_STATE_STORAGE_KEY]: next
      });
      broadcastAuthState(next);
      return next;
    }
    async function issueBackendToken(args2) {
      const headers = {
        "Content-Type": "application/json"
      };
      if (args2.bootstrapKey) {
        headers["X-Bootstrap-Key"] = args2.bootstrapKey;
      }
      const response = await fetchImpl(`${args2.config.apiBaseUrl}/api/token`, {
        method: "POST",
        headers,
        body: JSON.stringify(args2.body)
      });
      if (!response.ok) {
        let message = `token request failed (${response.status})`;
        try {
          const payload = await response.json();
          message = payload.message ?? payload.code ?? message;
        } catch {
        }
        throw new Error(message);
      }
      return await response.json();
    }
    async function revokeBackendToken(config, token) {
      try {
        await fetchImpl(`${config.apiBaseUrl}/api/token/revoke`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
      } catch {
      }
    }
    async function issueDevBootstrapSession(config, current) {
      const devBootstrap = config.devBootstrap;
      if (!devBootstrap) {
        return {
          ok: false,
          state: current,
          error: "No auth provider configured."
        };
      }
      const issued = await issueBackendToken({
        config,
        body: {
          grantType: "dev-bootstrap",
          bootstrapSubject: devBootstrap.bootstrapSubject,
          ...devBootstrap.profile ? { profile: devBootstrap.profile } : {}
        },
        bootstrapKey: devBootstrap.bootstrapKey
      });
      const next = await writeState({
        status: "signed-in",
        provider: "dev-bootstrap",
        user: issued.user,
        session: {
          token: issued.token,
          expiresAt: issued.expiresAt
        }
      });
      return {
        ok: true,
        state: next,
        token: issued.token,
        expiresAt: issued.expiresAt,
        user: issued.user
      };
    }
    async function exchangeGoogleIdToken(config, idToken) {
      const issued = await issueBackendToken({
        config,
        body: {
          grantType: "google-id-token",
          idToken
        }
      });
      const next = await writeState({
        status: "signed-in",
        provider: "google",
        user: issued.user,
        session: {
          token: issued.token,
          expiresAt: issued.expiresAt
        }
      });
      return {
        ok: true,
        state: next,
        token: issued.token,
        expiresAt: issued.expiresAt,
        user: issued.user
      };
    }
    async function runGoogleOidcFlow(config, interactive) {
      if (!config.googleOAuthClientId) {
        throw new Error("Google sign-in is not configured for this build.");
      }
      const redirectUri = getRedirectUrl("google-auth");
      const state = randomBase64Url();
      const nonce = randomBase64Url();
      const redirectUrl = await launchWebAuthFlow({
        url: buildGoogleAuthorizeUrl({
          clientId: config.googleOAuthClientId,
          redirectUri,
          state,
          nonce,
          interactive
        }),
        interactive
      });
      if (!redirectUrl) {
        throw new Error(interactive ? "Google sign-in was cancelled." : "Google session refresh failed.");
      }
      return parseGoogleAuthRedirect({
        redirectUrl,
        expectedState: state,
        expectedNonce: nonce
      });
    }
    async function transition(next) {
      return writeState(next);
    }
    async function getState() {
      const config = await loadConfig();
      const current = await readPersistedAuthState(args.storage);
      if (config.devBootstrap && (!current.session || !isSessionFresh(current.session.expiresAt, now()))) {
        try {
          return (await issueDevBootstrapSession(config, current)).state;
        } catch (error) {
          return transition(
            createErrorState(
              error instanceof Error ? error.message : "Failed to start the internal preview session.",
              "dev-bootstrap"
            )
          );
        }
      }
      if (!config.googleOAuthClientId && !config.devBootstrap) {
        return transition(createErrorState("Google sign-in is not configured for this build.", "google"));
      }
      if (current.status === "error") {
        return current;
      }
      if (current.user && current.provider === "google") {
        return {
          ...current,
          status: "signed-in"
        };
      }
      return current;
    }
    async function signInWithGoogle() {
      if (signInInFlight) {
        return signInInFlight;
      }
      signInInFlight = (async () => {
        const config = await loadConfig();
        if (!config.googleOAuthClientId) {
          return transition(createErrorState("Google sign-in is not configured for this build.", "google"));
        }
        await transition({
          status: "signing-in",
          provider: "google",
          user: null,
          session: null
        });
        try {
          const idToken = await runGoogleOidcFlow(config, true);
          return (await exchangeGoogleIdToken(config, idToken)).state;
        } catch (error) {
          return transition(
            createErrorState(
              error instanceof Error ? error.message : "Google sign-in failed. Try again.",
              "google"
            )
          );
        }
      })().finally(() => {
        signInInFlight = null;
      });
      return signInInFlight;
    }
    async function ensureAuthSession() {
      if (ensureInFlight) {
        return ensureInFlight;
      }
      ensureInFlight = (async () => {
        const config = await loadConfig();
        const current = await readPersistedAuthState(args.storage);
        if (config.devBootstrap) {
          try {
            return await issueDevBootstrapSession(config, current);
          } catch (error) {
            const state = await transition(
              createErrorState(
                error instanceof Error ? error.message : "Failed to start the internal preview session.",
                "dev-bootstrap"
              )
            );
            return {
              ok: false,
              state,
              error: state.errorMessage ?? "Failed to start the internal preview session."
            };
          }
        }
        if (!config.googleOAuthClientId) {
          const state = await transition(
            createErrorState("Google sign-in is not configured for this build.", "google")
          );
          return {
            ok: false,
            state,
            error: state.errorMessage ?? "Google sign-in is not configured for this build."
          };
        }
        if (current.session && isSessionFresh(current.session.expiresAt, now()) && current.user) {
          const state = current.status === "signed-in" ? current : await transition({
            status: "signed-in",
            provider: "google",
            user: current.user,
            session: current.session
          });
          return {
            ok: true,
            state,
            token: current.session.token,
            expiresAt: current.session.expiresAt,
            user: current.user
          };
        }
        if (!current.user || current.provider !== "google") {
          const state = await transition(
            createSignedOutState("Sign in with Google to ask about the current page.")
          );
          return {
            ok: false,
            state,
            error: state.errorMessage ?? "Sign in with Google to continue."
          };
        }
        await transition({
          status: "refreshing",
          provider: "google",
          user: current.user,
          session: current.session
        });
        try {
          const idToken = await runGoogleOidcFlow(config, false);
          return await exchangeGoogleIdToken(config, idToken);
        } catch {
          const state = await transition(
            createSignedOutState("Your Google session expired. Sign in again to continue.")
          );
          return {
            ok: false,
            state,
            error: state.errorMessage ?? "Your Google session expired. Sign in again."
          };
        }
      })().finally(() => {
        ensureInFlight = null;
      });
      return ensureInFlight;
    }
    async function signOut() {
      const config = await loadConfig();
      const current = await readPersistedAuthState(args.storage);
      if (current.session?.token) {
        await revokeBackendToken(config, current.session.token);
      }
      return transition(createSignedOutState());
    }
    return {
      getState,
      signInWithGoogle,
      ensureAuthSession,
      signOut
    };
  }

  // src/background/service-worker.ts
  function isPageTextSelectionChangedMessage(message) {
    if (typeof message !== "object" || message === null) {
      return false;
    }
    const candidate = message;
    return candidate.type === "PAGE_TEXT_SELECTION_CHANGED" && typeof candidate.payload?.hasSelection === "boolean" && typeof candidate.payload?.textPreview === "string" && typeof candidate.payload?.timestamp === "number";
  }
  function safeBroadcastRuntimeMessage(message) {
    chrome.runtime.sendMessage(message, () => {
      void chrome.runtime.lastError;
    });
  }
  var knownArticleUrls = /* @__PURE__ */ new Map();
  var authManager = createExtensionAuthManager({
    storage: createChromeLocalStorage(),
    broadcastAuthState(state) {
      safeBroadcastRuntimeMessage({
        type: "AUTH_STATE_CHANGED",
        payload: state
      });
    }
  });
  var semanticSnapshotCoordinator = createSemanticSnapshotCoordinator({
    async getActiveTab() {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      return tabs[0] ?? null;
    },
    async getTab(tabId) {
      return await chrome.tabs.get(tabId) ?? null;
    },
    async sendToContentScript(tabId, message) {
      const trySend = () => new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, message, (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            reject(new Error(runtimeError.message));
            return;
          }
          resolve(response);
        });
      });
      try {
        return await trySend();
      } catch (error) {
        const messageText = error instanceof Error ? error.message : "";
        if (!messageText.includes("Receiving end does not exist") || !chrome.scripting?.executeScript) {
          throw error;
        }
        await chrome.scripting.executeScript({
          target: { tabId },
          files: ["content-semantic.js"]
        });
        return trySend();
      }
    },
    async openSidePanel(tabId) {
      if (chrome.sidePanel?.open) {
        await chrome.sidePanel.open({ tabId });
      }
    },
    notifyRuntime(message) {
      safeBroadcastRuntimeMessage(message);
    }
  });
  function resolveSemanticTabId(payloadTabId, sender) {
    return payloadTabId ?? sender.tab?.id ?? void 0;
  }
  function notifyActiveTabChanged(tabId, url, title) {
    safeBroadcastRuntimeMessage({
      type: "ACTIVE_TAB_CHANGED",
      payload: {
        tabId,
        url,
        title
      }
    });
  }
  function registerContextMenus() {
    if (!chrome.contextMenus) {
      return;
    }
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({
        id: SEMANTIC_SNAPSHOT_CONTEXT_MENU_ID,
        title: "Capture Semantic Snapshot",
        contexts: ["page", "selection"]
      });
    });
  }
  registerContextMenus();
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    notifyActiveTabChanged(activeInfo.tabId, tab.url ?? "", tab.title ?? "");
  });
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status !== "complete" || !tab.url) {
      return;
    }
    if (tab.active) {
      notifyActiveTabChanged(tabId, tab.url ?? "", tab.title ?? "");
    }
    if (!knownArticleUrls.has(tab.url)) {
      return;
    }
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content-article.js"]
      });
      safeBroadcastRuntimeMessage({
        type: "ARTICLE_INJECTED",
        payload: {
          tabId,
          url: tab.url
        }
      });
    } catch (error) {
      console.error("content-article inject failed", error);
    }
  });
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender.tab?.id != null) {
      if (isPageTextSelectionChangedMessage(msg)) {
        safeBroadcastRuntimeMessage({
          type: "PAGE_TEXT_SELECTION_CHANGED",
          payload: {
            ...msg.payload,
            tabId: sender.tab.id
          }
        });
        sendResponse({ ok: true });
        return true;
      }
      switch (msg.type) {
        case "PAGE_AUDIO_CAPTURE_READY": {
          safeBroadcastRuntimeMessage({
            type: "PAGE_AUDIO_CAPTURE_READY",
            payload: {
              tabId: sender.tab.id
            }
          });
          sendResponse({ ok: true });
          return true;
        }
        case "PAGE_AUDIO_CAPTURE_STATE_CHANGED": {
          safeBroadcastRuntimeMessage({
            type: "PAGE_AUDIO_CAPTURE_STATE_CHANGED",
            payload: {
              ...msg.payload,
              tabId: sender.tab.id
            }
          });
          sendResponse({ ok: true });
          return true;
        }
        case "PAGE_AUDIO_CAPTURE_CHUNK": {
          safeBroadcastRuntimeMessage({
            type: "PAGE_AUDIO_CAPTURE_CHUNK",
            payload: {
              ...msg.payload,
              tabId: sender.tab.id
            }
          });
          sendResponse({ ok: true });
          return true;
        }
      }
    }
    const sidePanelMessage = msg;
    switch (sidePanelMessage.type) {
      case "CAPTURE_VIEWPORT": {
        chrome.tabs.captureVisibleTab({ format: "jpeg", quality: 70 }, (dataUrl) => {
          const viewport = dataUrl?.split(",")[1] ?? null;
          sendResponse({ viewport });
        });
        return true;
      }
      case "REGISTER_ARTICLE_URL": {
        knownArticleUrls.set(sidePanelMessage.payload.url, sidePanelMessage.payload.threadId);
        sendResponse({ ok: true });
        return true;
      }
      case "OPEN_TAB": {
        chrome.tabs.create({ url: sidePanelMessage.payload.url, active: sidePanelMessage.payload.active }, (tab) => {
          sendResponse({ tabId: tab.id });
        });
        return true;
      }
      case "REQUEST_SEMANTIC_SNAPSHOT": {
        void semanticSnapshotCoordinator.captureActiveTab(
          resolveSemanticTabId(sidePanelMessage.payload?.tabId, sender),
          sidePanelMessage.payload?.source ?? "sidepanel",
          {
            openPanel: false
          }
        ).then((payload) => sendResponse(payload)).catch((error) => {
          const message = error instanceof Error ? error.message : "semantic snapshot request failed";
          sendResponse({ tabId: null, snapshot: null, error: message });
        });
        return true;
      }
      case "GET_AUTH_STATE": {
        void authManager.getState().then((payload) => sendResponse(payload)).catch((error) => {
          sendResponse({
            status: "error",
            provider: "google",
            user: null,
            session: null,
            errorMessage: error instanceof Error ? error.message : "failed to read auth state"
          });
        });
        return true;
      }
      case "SIGN_IN_WITH_GOOGLE": {
        void authManager.signInWithGoogle().then((payload) => sendResponse(payload)).catch((error) => {
          sendResponse({
            status: "error",
            provider: "google",
            user: null,
            session: null,
            errorMessage: error instanceof Error ? error.message : "failed to sign in with Google"
          });
        });
        return true;
      }
      case "ENSURE_AUTH_SESSION": {
        void authManager.ensureAuthSession().then((payload) => sendResponse(payload)).catch((error) => {
          sendResponse({
            ok: false,
            state: {
              status: "error",
              provider: "google",
              user: null,
              session: null,
              errorMessage: error instanceof Error ? error.message : "failed to ensure an authenticated session"
            },
            error: error instanceof Error ? error.message : "failed to ensure an authenticated session"
          });
        });
        return true;
      }
      case "SIGN_OUT": {
        void authManager.signOut().then((payload) => sendResponse(payload)).catch((error) => {
          sendResponse({
            status: "error",
            provider: "google",
            user: null,
            session: null,
            errorMessage: error instanceof Error ? error.message : "failed to sign out"
          });
        });
        return true;
      }
      case "GET_LATEST_SEMANTIC_SNAPSHOT": {
        void semanticSnapshotCoordinator.getLatest(resolveSemanticTabId(sidePanelMessage.payload?.tabId, sender)).then((payload) => sendResponse(payload)).catch((error) => {
          const message = error instanceof Error ? error.message : "semantic snapshot lookup failed";
          sendResponse({ tabId: null, snapshot: null, error: message });
        });
        return true;
      }
      case "GET_SEMANTIC_SNAPSHOT_HISTORY": {
        void semanticSnapshotCoordinator.getHistory(resolveSemanticTabId(sidePanelMessage.payload?.tabId, sender)).then((payload) => sendResponse(payload)).catch(() => {
          sendResponse({ tabId: null, snapshots: [] });
        });
        return true;
      }
      case "TOGGLE_SEMANTIC_SELECTION": {
        void semanticSnapshotCoordinator.toggleSelectionMode(resolveSemanticTabId(sidePanelMessage.payload?.tabId, sender)).then((payload) => sendResponse(payload)).catch(() => {
          sendResponse({ tabId: null, enabled: false, selectedTarget: null });
        });
        return true;
      }
      case "GET_SEMANTIC_SELECTION_STATE": {
        void semanticSnapshotCoordinator.getSelectionState(resolveSemanticTabId(sidePanelMessage.payload?.tabId, sender)).then((payload) => sendResponse(payload)).catch(() => {
          sendResponse({ tabId: null, enabled: false, selectedTarget: null });
        });
        return true;
      }
      case "GET_SEMANTIC_REGION_DUMP": {
        void semanticSnapshotCoordinator.getRegionDump(resolveSemanticTabId(sidePanelMessage.payload?.tabId, sender)).then((payload) => sendResponse(payload)).catch((error) => {
          const message = error instanceof Error ? error.message : "semantic region dump lookup failed";
          sendResponse({ tabId: null, dump: null, error: message });
        });
        return true;
      }
      case "CLEAR_SEMANTIC_SELECTION": {
        void semanticSnapshotCoordinator.clearSelection(resolveSemanticTabId(sidePanelMessage.payload?.tabId, sender)).then((payload) => sendResponse(payload)).catch(() => {
          sendResponse({ tabId: null, enabled: false, selectedTarget: null });
        });
        return true;
      }
      case "SYNC_SEMANTIC_SELECTION_STATE": {
        const tabId = sender.tab?.id ?? null;
        const payload = semanticSnapshotCoordinator.syncSelectionState(
          tabId,
          {
            enabled: sidePanelMessage.payload.enabled,
            selectedTarget: sidePanelMessage.payload.selectedTarget
          },
          typeof sidePanelMessage.payload.snapshot !== "undefined" || typeof sidePanelMessage.payload.error !== "undefined" ? {
            snapshot: sidePanelMessage.payload.snapshot ?? null,
            error: sidePanelMessage.payload.error ?? null
          } : void 0
        );
        sendResponse(payload);
        return true;
      }
      default:
        return false;
    }
  });
  if (chrome.runtime.onInstalled) {
    chrome.runtime.onInstalled.addListener(() => {
      registerContextMenus();
    });
  }
  if (chrome.contextMenus?.onClicked) {
    chrome.contextMenus.onClicked.addListener((info, tab) => {
      if (info.menuItemId !== SEMANTIC_SNAPSHOT_CONTEXT_MENU_ID) {
        return;
      }
      void semanticSnapshotCoordinator.captureForTab(tab?.id ?? null, "context-menu");
    });
  }
  if (chrome.commands?.onCommand) {
    chrome.commands.onCommand.addListener((command) => {
      if (command === SEMANTIC_SNAPSHOT_COMMAND) {
        void semanticSnapshotCoordinator.captureActiveTab(void 0, "command");
        return;
      }
      if (command === SEMANTIC_SELECTION_COMMAND) {
        void semanticSnapshotCoordinator.toggleSelectionMode();
      }
    });
  }
})();
//# sourceMappingURL=service-worker.js.map
