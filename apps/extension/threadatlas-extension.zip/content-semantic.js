"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/Readability.js
  var require_Readability = __commonJS({
    "../../node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/Readability.js"(exports, module) {
      function Readability2(doc, options) {
        if (options && options.documentElement) {
          doc = options;
          options = arguments[2];
        } else if (!doc || !doc.documentElement) {
          throw new Error(
            "First argument to Readability constructor should be a document object."
          );
        }
        options = options || {};
        this._doc = doc;
        this._docJSDOMParser = this._doc.firstChild.__JSDOMParser__;
        this._articleTitle = null;
        this._articleByline = null;
        this._articleDir = null;
        this._articleSiteName = null;
        this._attempts = [];
        this._metadata = {};
        this._debug = !!options.debug;
        this._maxElemsToParse = options.maxElemsToParse || this.DEFAULT_MAX_ELEMS_TO_PARSE;
        this._nbTopCandidates = options.nbTopCandidates || this.DEFAULT_N_TOP_CANDIDATES;
        this._charThreshold = options.charThreshold || this.DEFAULT_CHAR_THRESHOLD;
        this._classesToPreserve = this.CLASSES_TO_PRESERVE.concat(
          options.classesToPreserve || []
        );
        this._keepClasses = !!options.keepClasses;
        this._serializer = options.serializer || function(el) {
          return el.innerHTML;
        };
        this._disableJSONLD = !!options.disableJSONLD;
        this._allowedVideoRegex = options.allowedVideoRegex || this.REGEXPS.videos;
        this._linkDensityModifier = options.linkDensityModifier || 0;
        this._flags = this.FLAG_STRIP_UNLIKELYS | this.FLAG_WEIGHT_CLASSES | this.FLAG_CLEAN_CONDITIONALLY;
        if (this._debug) {
          let logNode = function(node) {
            if (node.nodeType == node.TEXT_NODE) {
              return `${node.nodeName} ("${node.textContent}")`;
            }
            let attrPairs = Array.from(node.attributes || [], function(attr) {
              return `${attr.name}="${attr.value}"`;
            }).join(" ");
            return `<${node.localName} ${attrPairs}>`;
          };
          this.log = function() {
            if (typeof console !== "undefined") {
              let args = Array.from(arguments, (arg) => {
                if (arg && arg.nodeType == this.ELEMENT_NODE) {
                  return logNode(arg);
                }
                return arg;
              });
              args.unshift("Reader: (Readability)");
              console.log(...args);
            } else if (typeof dump !== "undefined") {
              var msg = Array.prototype.map.call(arguments, function(x) {
                return x && x.nodeName ? logNode(x) : x;
              }).join(" ");
              dump("Reader: (Readability) " + msg + "\n");
            }
          };
        } else {
          this.log = function() {
          };
        }
      }
      Readability2.prototype = {
        FLAG_STRIP_UNLIKELYS: 1,
        FLAG_WEIGHT_CLASSES: 2,
        FLAG_CLEAN_CONDITIONALLY: 4,
        // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
        ELEMENT_NODE: 1,
        TEXT_NODE: 3,
        // Max number of nodes supported by this parser. Default: 0 (no limit)
        DEFAULT_MAX_ELEMS_TO_PARSE: 0,
        // The number of top candidates to consider when analysing how
        // tight the competition is among candidates.
        DEFAULT_N_TOP_CANDIDATES: 5,
        // Element tags to score by default.
        DEFAULT_TAGS_TO_SCORE: "section,h2,h3,h4,h5,h6,p,td,pre".toUpperCase().split(","),
        // The default number of chars an article must have in order to return a result
        DEFAULT_CHAR_THRESHOLD: 500,
        // All of the regular expressions in use within readability.
        // Defined up here so we don't instantiate them repeatedly in loops.
        REGEXPS: {
          // NOTE: These two regular expressions are duplicated in
          // Readability-readerable.js. Please keep both copies in sync.
          unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
          okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i,
          positive: /article|body|content|entry|hentry|h-entry|main|page|pagination|post|text|blog|story/i,
          negative: /-ad-|hidden|^hid$| hid$| hid |^hid |banner|combx|comment|com-|contact|footer|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|widget/i,
          extraneous: /print|archive|comment|discuss|e[\-]?mail|share|reply|all|login|sign|single|utility/i,
          byline: /byline|author|dateline|writtenby|p-author/i,
          replaceFonts: /<(\/?)font[^>]*>/gi,
          normalize: /\s{2,}/g,
          videos: /\/\/(www\.)?((dailymotion|youtube|youtube-nocookie|player\.vimeo|v\.qq)\.com|(archive|upload\.wikimedia)\.org|player\.twitch\.tv)/i,
          shareElements: /(\b|_)(share|sharedaddy)(\b|_)/i,
          nextLink: /(next|weiter|continue|>([^\|]|$)|»([^\|]|$))/i,
          prevLink: /(prev|earl|old|new|<|«)/i,
          tokenize: /\W+/g,
          whitespace: /^\s*$/,
          hasContent: /\S$/,
          hashUrl: /^#.+/,
          srcsetUrl: /(\S+)(\s+[\d.]+[xw])?(\s*(?:,|$))/g,
          b64DataUrl: /^data:\s*([^\s;,]+)\s*;\s*base64\s*,/i,
          // Commas as used in Latin, Sindhi, Chinese and various other scripts.
          // see: https://en.wikipedia.org/wiki/Comma#Comma_variants
          commas: /\u002C|\u060C|\uFE50|\uFE10|\uFE11|\u2E41|\u2E34|\u2E32|\uFF0C/g,
          // See: https://schema.org/Article
          jsonLdArticleTypes: /^Article|AdvertiserContentArticle|NewsArticle|AnalysisNewsArticle|AskPublicNewsArticle|BackgroundNewsArticle|OpinionNewsArticle|ReportageNewsArticle|ReviewNewsArticle|Report|SatiricalArticle|ScholarlyArticle|MedicalScholarlyArticle|SocialMediaPosting|BlogPosting|LiveBlogPosting|DiscussionForumPosting|TechArticle|APIReference$/,
          // used to see if a node's content matches words commonly used for ad blocks or loading indicators
          adWords: /^(ad(vertising|vertisement)?|pub(licité)?|werb(ung)?|广告|Реклама|Anuncio)$/iu,
          loadingWords: /^((loading|正在加载|Загрузка|chargement|cargando)(…|\.\.\.)?)$/iu
        },
        UNLIKELY_ROLES: [
          "menu",
          "menubar",
          "complementary",
          "navigation",
          "alert",
          "alertdialog",
          "dialog"
        ],
        DIV_TO_P_ELEMS: /* @__PURE__ */ new Set([
          "BLOCKQUOTE",
          "DL",
          "DIV",
          "IMG",
          "OL",
          "P",
          "PRE",
          "TABLE",
          "UL"
        ]),
        ALTER_TO_DIV_EXCEPTIONS: ["DIV", "ARTICLE", "SECTION", "P", "OL", "UL"],
        PRESENTATIONAL_ATTRIBUTES: [
          "align",
          "background",
          "bgcolor",
          "border",
          "cellpadding",
          "cellspacing",
          "frame",
          "hspace",
          "rules",
          "style",
          "valign",
          "vspace"
        ],
        DEPRECATED_SIZE_ATTRIBUTE_ELEMS: ["TABLE", "TH", "TD", "HR", "PRE"],
        // The commented out elements qualify as phrasing content but tend to be
        // removed by readability when put into paragraphs, so we ignore them here.
        PHRASING_ELEMS: [
          // "CANVAS", "IFRAME", "SVG", "VIDEO",
          "ABBR",
          "AUDIO",
          "B",
          "BDO",
          "BR",
          "BUTTON",
          "CITE",
          "CODE",
          "DATA",
          "DATALIST",
          "DFN",
          "EM",
          "EMBED",
          "I",
          "IMG",
          "INPUT",
          "KBD",
          "LABEL",
          "MARK",
          "MATH",
          "METER",
          "NOSCRIPT",
          "OBJECT",
          "OUTPUT",
          "PROGRESS",
          "Q",
          "RUBY",
          "SAMP",
          "SCRIPT",
          "SELECT",
          "SMALL",
          "SPAN",
          "STRONG",
          "SUB",
          "SUP",
          "TEXTAREA",
          "TIME",
          "VAR",
          "WBR"
        ],
        // These are the classes that readability sets itself.
        CLASSES_TO_PRESERVE: ["page"],
        // These are the list of HTML entities that need to be escaped.
        HTML_ESCAPE_MAP: {
          lt: "<",
          gt: ">",
          amp: "&",
          quot: '"',
          apos: "'"
        },
        /**
         * Run any post-process modifications to article content as necessary.
         *
         * @param Element
         * @return void
         **/
        _postProcessContent(articleContent) {
          this._fixRelativeUris(articleContent);
          this._simplifyNestedElements(articleContent);
          if (!this._keepClasses) {
            this._cleanClasses(articleContent);
          }
        },
        /**
         * Iterates over a NodeList, calls `filterFn` for each node and removes node
         * if function returned `true`.
         *
         * If function is not passed, removes all the nodes in node list.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param Function filterFn the function to use as a filter
         * @return void
         */
        _removeNodes(nodeList, filterFn) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _removeNodes");
          }
          for (var i = nodeList.length - 1; i >= 0; i--) {
            var node = nodeList[i];
            var parentNode = node.parentNode;
            if (parentNode) {
              if (!filterFn || filterFn.call(this, node, i, nodeList)) {
                parentNode.removeChild(node);
              }
            }
          }
        },
        /**
         * Iterates over a NodeList, and calls _setNodeTag for each node.
         *
         * @param NodeList nodeList The nodes to operate on
         * @param String newTagName the new tag name to use
         * @return void
         */
        _replaceNodeTags(nodeList, newTagName) {
          if (this._docJSDOMParser && nodeList._isLiveNodeList) {
            throw new Error("Do not pass live node lists to _replaceNodeTags");
          }
          for (const node of nodeList) {
            this._setNodeTag(node, newTagName);
          }
        },
        /**
         * Iterate over a NodeList, which doesn't natively fully implement the Array
         * interface.
         *
         * For convenience, the current object context is applied to the provided
         * iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return void
         */
        _forEachNode(nodeList, fn) {
          Array.prototype.forEach.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, and return the first node that passes
         * the supplied test function
         *
         * For convenience, the current object context is applied to the provided
         * test function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The test function.
         * @return void
         */
        _findNode(nodeList, fn) {
          return Array.prototype.find.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if any of the provided iterate
         * function calls returns true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _someNode(nodeList, fn) {
          return Array.prototype.some.call(nodeList, fn, this);
        },
        /**
         * Iterate over a NodeList, return true if all of the provided iterate
         * function calls return true, false otherwise.
         *
         * For convenience, the current object context is applied to the
         * provided iterate function.
         *
         * @param  NodeList nodeList The NodeList.
         * @param  Function fn       The iterate function.
         * @return Boolean
         */
        _everyNode(nodeList, fn) {
          return Array.prototype.every.call(nodeList, fn, this);
        },
        _getAllNodesWithTag(node, tagNames) {
          if (node.querySelectorAll) {
            return node.querySelectorAll(tagNames.join(","));
          }
          return [].concat.apply(
            [],
            tagNames.map(function(tag) {
              var collection = node.getElementsByTagName(tag);
              return Array.isArray(collection) ? collection : Array.from(collection);
            })
          );
        },
        /**
         * Removes the class="" attribute from every element in the given
         * subtree, except those that match CLASSES_TO_PRESERVE and
         * the classesToPreserve array from the options object.
         *
         * @param Element
         * @return void
         */
        _cleanClasses(node) {
          var classesToPreserve = this._classesToPreserve;
          var className = (node.getAttribute("class") || "").split(/\s+/).filter((cls) => classesToPreserve.includes(cls)).join(" ");
          if (className) {
            node.setAttribute("class", className);
          } else {
            node.removeAttribute("class");
          }
          for (node = node.firstElementChild; node; node = node.nextElementSibling) {
            this._cleanClasses(node);
          }
        },
        /**
         * Tests whether a string is a URL or not.
         *
         * @param {string} str The string to test
         * @return {boolean} true if str is a URL, false if not
         */
        _isUrl(str) {
          try {
            new URL(str);
            return true;
          } catch {
            return false;
          }
        },
        /**
         * Converts each <a> and <img> uri in the given element to an absolute URI,
         * ignoring #ref URIs.
         *
         * @param Element
         * @return void
         */
        _fixRelativeUris(articleContent) {
          var baseURI = this._doc.baseURI;
          var documentURI = this._doc.documentURI;
          function toAbsoluteURI(uri) {
            if (baseURI == documentURI && uri.charAt(0) == "#") {
              return uri;
            }
            try {
              return new URL(uri, baseURI).href;
            } catch (ex) {
            }
            return uri;
          }
          var links = this._getAllNodesWithTag(articleContent, ["a"]);
          this._forEachNode(links, function(link) {
            var href = link.getAttribute("href");
            if (href) {
              if (href.indexOf("javascript:") === 0) {
                if (link.childNodes.length === 1 && link.childNodes[0].nodeType === this.TEXT_NODE) {
                  var text = this._doc.createTextNode(link.textContent);
                  link.parentNode.replaceChild(text, link);
                } else {
                  var container = this._doc.createElement("span");
                  while (link.firstChild) {
                    container.appendChild(link.firstChild);
                  }
                  link.parentNode.replaceChild(container, link);
                }
              } else {
                link.setAttribute("href", toAbsoluteURI(href));
              }
            }
          });
          var medias = this._getAllNodesWithTag(articleContent, [
            "img",
            "picture",
            "figure",
            "video",
            "audio",
            "source"
          ]);
          this._forEachNode(medias, function(media) {
            var src = media.getAttribute("src");
            var poster = media.getAttribute("poster");
            var srcset = media.getAttribute("srcset");
            if (src) {
              media.setAttribute("src", toAbsoluteURI(src));
            }
            if (poster) {
              media.setAttribute("poster", toAbsoluteURI(poster));
            }
            if (srcset) {
              var newSrcset = srcset.replace(
                this.REGEXPS.srcsetUrl,
                function(_, p1, p2, p3) {
                  return toAbsoluteURI(p1) + (p2 || "") + p3;
                }
              );
              media.setAttribute("srcset", newSrcset);
            }
          });
        },
        _simplifyNestedElements(articleContent) {
          var node = articleContent;
          while (node) {
            if (node.parentNode && ["DIV", "SECTION"].includes(node.tagName) && !(node.id && node.id.startsWith("readability"))) {
              if (this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              } else if (this._hasSingleTagInsideElement(node, "DIV") || this._hasSingleTagInsideElement(node, "SECTION")) {
                var child = node.children[0];
                for (var i = 0; i < node.attributes.length; i++) {
                  child.setAttributeNode(node.attributes[i].cloneNode());
                }
                node.parentNode.replaceChild(child, node);
                node = child;
                continue;
              }
            }
            node = this._getNextNode(node);
          }
        },
        /**
         * Get the article title as an H1.
         *
         * @return string
         **/
        _getArticleTitle() {
          var doc = this._doc;
          var curTitle = "";
          var origTitle = "";
          try {
            curTitle = origTitle = doc.title.trim();
            if (typeof curTitle !== "string") {
              curTitle = origTitle = this._getInnerText(
                doc.getElementsByTagName("title")[0]
              );
            }
          } catch (e) {
          }
          var titleHadHierarchicalSeparators = false;
          function wordCount(str) {
            return str.split(/\s+/).length;
          }
          if (/ [\|\-\\\/>»] /.test(curTitle)) {
            titleHadHierarchicalSeparators = / [\\\/>»] /.test(curTitle);
            let allSeparators = Array.from(origTitle.matchAll(/ [\|\-\\\/>»] /gi));
            curTitle = origTitle.substring(0, allSeparators.pop().index);
            if (wordCount(curTitle) < 3) {
              curTitle = origTitle.replace(/^[^\|\-\\\/>»]*[\|\-\\\/>»]/gi, "");
            }
          } else if (curTitle.includes(": ")) {
            var headings = this._getAllNodesWithTag(doc, ["h1", "h2"]);
            var trimmedTitle = curTitle.trim();
            var match = this._someNode(headings, function(heading) {
              return heading.textContent.trim() === trimmedTitle;
            });
            if (!match) {
              curTitle = origTitle.substring(origTitle.lastIndexOf(":") + 1);
              if (wordCount(curTitle) < 3) {
                curTitle = origTitle.substring(origTitle.indexOf(":") + 1);
              } else if (wordCount(origTitle.substr(0, origTitle.indexOf(":"))) > 5) {
                curTitle = origTitle;
              }
            }
          } else if (curTitle.length > 150 || curTitle.length < 15) {
            var hOnes = doc.getElementsByTagName("h1");
            if (hOnes.length === 1) {
              curTitle = this._getInnerText(hOnes[0]);
            }
          }
          curTitle = curTitle.trim().replace(this.REGEXPS.normalize, " ");
          var curTitleWordCount = wordCount(curTitle);
          if (curTitleWordCount <= 4 && (!titleHadHierarchicalSeparators || curTitleWordCount != wordCount(origTitle.replace(/[\|\-\\\/>»]+/g, "")) - 1)) {
            curTitle = origTitle;
          }
          return curTitle;
        },
        /**
         * Prepare the HTML document for readability to scrape it.
         * This includes things like stripping javascript, CSS, and handling terrible markup.
         *
         * @return void
         **/
        _prepDocument() {
          var doc = this._doc;
          this._removeNodes(this._getAllNodesWithTag(doc, ["style"]));
          if (doc.body) {
            this._replaceBrs(doc.body);
          }
          this._replaceNodeTags(this._getAllNodesWithTag(doc, ["font"]), "SPAN");
        },
        /**
         * Finds the next node, starting from the given node, and ignoring
         * whitespace in between. If the given node is an element, the same node is
         * returned.
         */
        _nextNode(node) {
          var next = node;
          while (next && next.nodeType != this.ELEMENT_NODE && this.REGEXPS.whitespace.test(next.textContent)) {
            next = next.nextSibling;
          }
          return next;
        },
        /**
         * Replaces 2 or more successive <br> elements with a single <p>.
         * Whitespace between <br> elements are ignored. For example:
         *   <div>foo<br>bar<br> <br><br>abc</div>
         * will become:
         *   <div>foo<br>bar<p>abc</p></div>
         */
        _replaceBrs(elem) {
          this._forEachNode(this._getAllNodesWithTag(elem, ["br"]), function(br) {
            var next = br.nextSibling;
            var replaced = false;
            while ((next = this._nextNode(next)) && next.tagName == "BR") {
              replaced = true;
              var brSibling = next.nextSibling;
              next.remove();
              next = brSibling;
            }
            if (replaced) {
              var p = this._doc.createElement("p");
              br.parentNode.replaceChild(p, br);
              next = p.nextSibling;
              while (next) {
                if (next.tagName == "BR") {
                  var nextElem = this._nextNode(next.nextSibling);
                  if (nextElem && nextElem.tagName == "BR") {
                    break;
                  }
                }
                if (!this._isPhrasingContent(next)) {
                  break;
                }
                var sibling = next.nextSibling;
                p.appendChild(next);
                next = sibling;
              }
              while (p.lastChild && this._isWhitespace(p.lastChild)) {
                p.lastChild.remove();
              }
              if (p.parentNode.tagName === "P") {
                this._setNodeTag(p.parentNode, "DIV");
              }
            }
          });
        },
        _setNodeTag(node, tag) {
          this.log("_setNodeTag", node, tag);
          if (this._docJSDOMParser) {
            node.localName = tag.toLowerCase();
            node.tagName = tag.toUpperCase();
            return node;
          }
          var replacement = node.ownerDocument.createElement(tag);
          while (node.firstChild) {
            replacement.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(replacement, node);
          if (node.readability) {
            replacement.readability = node.readability;
          }
          for (var i = 0; i < node.attributes.length; i++) {
            replacement.setAttributeNode(node.attributes[i].cloneNode());
          }
          return replacement;
        },
        /**
         * Prepare the article node for display. Clean out any inline styles,
         * iframes, forms, strip extraneous <p> tags, etc.
         *
         * @param Element
         * @return void
         **/
        _prepArticle(articleContent) {
          this._cleanStyles(articleContent);
          this._markDataTables(articleContent);
          this._fixLazyImages(articleContent);
          this._cleanConditionally(articleContent, "form");
          this._cleanConditionally(articleContent, "fieldset");
          this._clean(articleContent, "object");
          this._clean(articleContent, "embed");
          this._clean(articleContent, "footer");
          this._clean(articleContent, "link");
          this._clean(articleContent, "aside");
          var shareElementThreshold = this.DEFAULT_CHAR_THRESHOLD;
          this._forEachNode(articleContent.children, function(topCandidate) {
            this._cleanMatchedNodes(topCandidate, function(node, matchString) {
              return this.REGEXPS.shareElements.test(matchString) && node.textContent.length < shareElementThreshold;
            });
          });
          this._clean(articleContent, "iframe");
          this._clean(articleContent, "input");
          this._clean(articleContent, "textarea");
          this._clean(articleContent, "select");
          this._clean(articleContent, "button");
          this._cleanHeaders(articleContent);
          this._cleanConditionally(articleContent, "table");
          this._cleanConditionally(articleContent, "ul");
          this._cleanConditionally(articleContent, "div");
          this._replaceNodeTags(
            this._getAllNodesWithTag(articleContent, ["h1"]),
            "h2"
          );
          this._removeNodes(
            this._getAllNodesWithTag(articleContent, ["p"]),
            function(paragraph) {
              var contentElementCount = this._getAllNodesWithTag(paragraph, [
                "img",
                "embed",
                "object",
                "iframe"
              ]).length;
              return contentElementCount === 0 && !this._getInnerText(paragraph, false);
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["br"]),
            function(br) {
              var next = this._nextNode(br.nextSibling);
              if (next && next.tagName == "P") {
                br.remove();
              }
            }
          );
          this._forEachNode(
            this._getAllNodesWithTag(articleContent, ["table"]),
            function(table) {
              var tbody = this._hasSingleTagInsideElement(table, "TBODY") ? table.firstElementChild : table;
              if (this._hasSingleTagInsideElement(tbody, "TR")) {
                var row = tbody.firstElementChild;
                if (this._hasSingleTagInsideElement(row, "TD")) {
                  var cell = row.firstElementChild;
                  cell = this._setNodeTag(
                    cell,
                    this._everyNode(cell.childNodes, this._isPhrasingContent) ? "P" : "DIV"
                  );
                  table.parentNode.replaceChild(cell, table);
                }
              }
            }
          );
        },
        /**
         * Initialize a node with the readability object. Also checks the
         * className/id for special names to add to its score.
         *
         * @param Element
         * @return void
         **/
        _initializeNode(node) {
          node.readability = { contentScore: 0 };
          switch (node.tagName) {
            case "DIV":
              node.readability.contentScore += 5;
              break;
            case "PRE":
            case "TD":
            case "BLOCKQUOTE":
              node.readability.contentScore += 3;
              break;
            case "ADDRESS":
            case "OL":
            case "UL":
            case "DL":
            case "DD":
            case "DT":
            case "LI":
            case "FORM":
              node.readability.contentScore -= 3;
              break;
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "TH":
              node.readability.contentScore -= 5;
              break;
          }
          node.readability.contentScore += this._getClassWeight(node);
        },
        _removeAndGetNext(node) {
          var nextNode = this._getNextNode(node, true);
          node.remove();
          return nextNode;
        },
        /**
         * Traverse the DOM from node to node, starting at the node passed in.
         * Pass true for the second parameter to indicate this node itself
         * (and its kids) are going away, and we want the next node over.
         *
         * Calling this in a loop will traverse the DOM depth-first.
         *
         * @param {Element} node
         * @param {boolean} ignoreSelfAndKids
         * @return {Element}
         */
        _getNextNode(node, ignoreSelfAndKids) {
          if (!ignoreSelfAndKids && node.firstElementChild) {
            return node.firstElementChild;
          }
          if (node.nextElementSibling) {
            return node.nextElementSibling;
          }
          do {
            node = node.parentNode;
          } while (node && !node.nextElementSibling);
          return node && node.nextElementSibling;
        },
        // compares second text to first one
        // 1 = same text, 0 = completely different text
        // works the way that it splits both texts into words and then finds words that are unique in second text
        // the result is given by the lower length of unique parts
        _textSimilarity(textA, textB) {
          var tokensA = textA.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          var tokensB = textB.toLowerCase().split(this.REGEXPS.tokenize).filter(Boolean);
          if (!tokensA.length || !tokensB.length) {
            return 0;
          }
          var uniqTokensB = tokensB.filter((token) => !tokensA.includes(token));
          var distanceB = uniqTokensB.join(" ").length / tokensB.join(" ").length;
          return 1 - distanceB;
        },
        /**
         * Checks whether an element node contains a valid byline
         *
         * @param node {Element}
         * @param matchString {string}
         * @return boolean
         */
        _isValidByline(node, matchString) {
          var rel = node.getAttribute("rel");
          var itemprop = node.getAttribute("itemprop");
          var bylineLength = node.textContent.trim().length;
          return (rel === "author" || itemprop && itemprop.includes("author") || this.REGEXPS.byline.test(matchString)) && !!bylineLength && bylineLength < 100;
        },
        _getNodeAncestors(node, maxDepth) {
          maxDepth = maxDepth || 0;
          var i = 0, ancestors = [];
          while (node.parentNode) {
            ancestors.push(node.parentNode);
            if (maxDepth && ++i === maxDepth) {
              break;
            }
            node = node.parentNode;
          }
          return ancestors;
        },
        /***
         * grabArticle - Using a variety of metrics (content score, classname, element types), find the content that is
         *         most likely to be the stuff a user wants to read. Then return it wrapped up in a div.
         *
         * @param page a document to run upon. Needs to be a full document, complete with body.
         * @return Element
         **/
        /* eslint-disable-next-line complexity */
        _grabArticle(page) {
          this.log("**** grabArticle ****");
          var doc = this._doc;
          var isPaging = page !== null;
          page = page ? page : this._doc.body;
          if (!page) {
            this.log("No body found in document. Abort.");
            return null;
          }
          var pageCacheHtml = page.innerHTML;
          while (true) {
            this.log("Starting grabArticle loop");
            var stripUnlikelyCandidates = this._flagIsActive(
              this.FLAG_STRIP_UNLIKELYS
            );
            var elementsToScore = [];
            var node = this._doc.documentElement;
            let shouldRemoveTitleHeader = true;
            while (node) {
              if (node.tagName === "HTML") {
                this._articleLang = node.getAttribute("lang");
              }
              var matchString = node.className + " " + node.id;
              if (!this._isProbablyVisible(node)) {
                this.log("Removing hidden node - " + matchString);
                node = this._removeAndGetNext(node);
                continue;
              }
              if (node.getAttribute("aria-modal") == "true" && node.getAttribute("role") == "dialog") {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (!this._articleByline && !this._metadata.byline && this._isValidByline(node, matchString)) {
                var endOfSearchMarkerNode = this._getNextNode(node, true);
                var next = this._getNextNode(node);
                var itemPropNameNode = null;
                while (next && next != endOfSearchMarkerNode) {
                  var itemprop = next.getAttribute("itemprop");
                  if (itemprop && itemprop.includes("name")) {
                    itemPropNameNode = next;
                    break;
                  } else {
                    next = this._getNextNode(next);
                  }
                }
                this._articleByline = (itemPropNameNode ?? node).textContent.trim();
                node = this._removeAndGetNext(node);
                continue;
              }
              if (shouldRemoveTitleHeader && this._headerDuplicatesTitle(node)) {
                this.log(
                  "Removing header: ",
                  node.textContent.trim(),
                  this._articleTitle.trim()
                );
                shouldRemoveTitleHeader = false;
                node = this._removeAndGetNext(node);
                continue;
              }
              if (stripUnlikelyCandidates) {
                if (this.REGEXPS.unlikelyCandidates.test(matchString) && !this.REGEXPS.okMaybeItsACandidate.test(matchString) && !this._hasAncestorTag(node, "table") && !this._hasAncestorTag(node, "code") && node.tagName !== "BODY" && node.tagName !== "A") {
                  this.log("Removing unlikely candidate - " + matchString);
                  node = this._removeAndGetNext(node);
                  continue;
                }
                if (this.UNLIKELY_ROLES.includes(node.getAttribute("role"))) {
                  this.log(
                    "Removing content with role " + node.getAttribute("role") + " - " + matchString
                  );
                  node = this._removeAndGetNext(node);
                  continue;
                }
              }
              if ((node.tagName === "DIV" || node.tagName === "SECTION" || node.tagName === "HEADER" || node.tagName === "H1" || node.tagName === "H2" || node.tagName === "H3" || node.tagName === "H4" || node.tagName === "H5" || node.tagName === "H6") && this._isElementWithoutContent(node)) {
                node = this._removeAndGetNext(node);
                continue;
              }
              if (this.DEFAULT_TAGS_TO_SCORE.includes(node.tagName)) {
                elementsToScore.push(node);
              }
              if (node.tagName === "DIV") {
                var p = null;
                var childNode = node.firstChild;
                while (childNode) {
                  var nextSibling = childNode.nextSibling;
                  if (this._isPhrasingContent(childNode)) {
                    if (p !== null) {
                      p.appendChild(childNode);
                    } else if (!this._isWhitespace(childNode)) {
                      p = doc.createElement("p");
                      node.replaceChild(p, childNode);
                      p.appendChild(childNode);
                    }
                  } else if (p !== null) {
                    while (p.lastChild && this._isWhitespace(p.lastChild)) {
                      p.lastChild.remove();
                    }
                    p = null;
                  }
                  childNode = nextSibling;
                }
                if (this._hasSingleTagInsideElement(node, "P") && this._getLinkDensity(node) < 0.25) {
                  var newNode = node.children[0];
                  node.parentNode.replaceChild(newNode, node);
                  node = newNode;
                  elementsToScore.push(node);
                } else if (!this._hasChildBlockElement(node)) {
                  node = this._setNodeTag(node, "P");
                  elementsToScore.push(node);
                }
              }
              node = this._getNextNode(node);
            }
            var candidates = [];
            this._forEachNode(elementsToScore, function(elementToScore) {
              if (!elementToScore.parentNode || typeof elementToScore.parentNode.tagName === "undefined") {
                return;
              }
              var innerText = this._getInnerText(elementToScore);
              if (innerText.length < 25) {
                return;
              }
              var ancestors2 = this._getNodeAncestors(elementToScore, 5);
              if (ancestors2.length === 0) {
                return;
              }
              var contentScore = 0;
              contentScore += 1;
              contentScore += innerText.split(this.REGEXPS.commas).length;
              contentScore += Math.min(Math.floor(innerText.length / 100), 3);
              this._forEachNode(ancestors2, function(ancestor, level) {
                if (!ancestor.tagName || !ancestor.parentNode || typeof ancestor.parentNode.tagName === "undefined") {
                  return;
                }
                if (typeof ancestor.readability === "undefined") {
                  this._initializeNode(ancestor);
                  candidates.push(ancestor);
                }
                if (level === 0) {
                  var scoreDivider = 1;
                } else if (level === 1) {
                  scoreDivider = 2;
                } else {
                  scoreDivider = level * 3;
                }
                ancestor.readability.contentScore += contentScore / scoreDivider;
              });
            });
            var topCandidates = [];
            for (var c = 0, cl = candidates.length; c < cl; c += 1) {
              var candidate = candidates[c];
              var candidateScore = candidate.readability.contentScore * (1 - this._getLinkDensity(candidate));
              candidate.readability.contentScore = candidateScore;
              this.log("Candidate:", candidate, "with score " + candidateScore);
              for (var t = 0; t < this._nbTopCandidates; t++) {
                var aTopCandidate = topCandidates[t];
                if (!aTopCandidate || candidateScore > aTopCandidate.readability.contentScore) {
                  topCandidates.splice(t, 0, candidate);
                  if (topCandidates.length > this._nbTopCandidates) {
                    topCandidates.pop();
                  }
                  break;
                }
              }
            }
            var topCandidate = topCandidates[0] || null;
            var neededToCreateTopCandidate = false;
            var parentOfTopCandidate;
            if (topCandidate === null || topCandidate.tagName === "BODY") {
              topCandidate = doc.createElement("DIV");
              neededToCreateTopCandidate = true;
              while (page.firstChild) {
                this.log("Moving child out:", page.firstChild);
                topCandidate.appendChild(page.firstChild);
              }
              page.appendChild(topCandidate);
              this._initializeNode(topCandidate);
            } else if (topCandidate) {
              var alternativeCandidateAncestors = [];
              for (var i = 1; i < topCandidates.length; i++) {
                if (topCandidates[i].readability.contentScore / topCandidate.readability.contentScore >= 0.75) {
                  alternativeCandidateAncestors.push(
                    this._getNodeAncestors(topCandidates[i])
                  );
                }
              }
              var MINIMUM_TOPCANDIDATES = 3;
              if (alternativeCandidateAncestors.length >= MINIMUM_TOPCANDIDATES) {
                parentOfTopCandidate = topCandidate.parentNode;
                while (parentOfTopCandidate.tagName !== "BODY") {
                  var listsContainingThisAncestor = 0;
                  for (var ancestorIndex = 0; ancestorIndex < alternativeCandidateAncestors.length && listsContainingThisAncestor < MINIMUM_TOPCANDIDATES; ancestorIndex++) {
                    listsContainingThisAncestor += Number(
                      alternativeCandidateAncestors[ancestorIndex].includes(
                        parentOfTopCandidate
                      )
                    );
                  }
                  if (listsContainingThisAncestor >= MINIMUM_TOPCANDIDATES) {
                    topCandidate = parentOfTopCandidate;
                    break;
                  }
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                }
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
              parentOfTopCandidate = topCandidate.parentNode;
              var lastScore = topCandidate.readability.contentScore;
              var scoreThreshold = lastScore / 3;
              while (parentOfTopCandidate.tagName !== "BODY") {
                if (!parentOfTopCandidate.readability) {
                  parentOfTopCandidate = parentOfTopCandidate.parentNode;
                  continue;
                }
                var parentScore = parentOfTopCandidate.readability.contentScore;
                if (parentScore < scoreThreshold) {
                  break;
                }
                if (parentScore > lastScore) {
                  topCandidate = parentOfTopCandidate;
                  break;
                }
                lastScore = parentOfTopCandidate.readability.contentScore;
                parentOfTopCandidate = parentOfTopCandidate.parentNode;
              }
              parentOfTopCandidate = topCandidate.parentNode;
              while (parentOfTopCandidate.tagName != "BODY" && parentOfTopCandidate.children.length == 1) {
                topCandidate = parentOfTopCandidate;
                parentOfTopCandidate = topCandidate.parentNode;
              }
              if (!topCandidate.readability) {
                this._initializeNode(topCandidate);
              }
            }
            var articleContent = doc.createElement("DIV");
            if (isPaging) {
              articleContent.id = "readability-content";
            }
            var siblingScoreThreshold = Math.max(
              10,
              topCandidate.readability.contentScore * 0.2
            );
            parentOfTopCandidate = topCandidate.parentNode;
            var siblings = parentOfTopCandidate.children;
            for (var s = 0, sl = siblings.length; s < sl; s++) {
              var sibling = siblings[s];
              var append = false;
              this.log(
                "Looking at sibling node:",
                sibling,
                sibling.readability ? "with score " + sibling.readability.contentScore : ""
              );
              this.log(
                "Sibling has score",
                sibling.readability ? sibling.readability.contentScore : "Unknown"
              );
              if (sibling === topCandidate) {
                append = true;
              } else {
                var contentBonus = 0;
                if (sibling.className === topCandidate.className && topCandidate.className !== "") {
                  contentBonus += topCandidate.readability.contentScore * 0.2;
                }
                if (sibling.readability && sibling.readability.contentScore + contentBonus >= siblingScoreThreshold) {
                  append = true;
                } else if (sibling.nodeName === "P") {
                  var linkDensity = this._getLinkDensity(sibling);
                  var nodeContent = this._getInnerText(sibling);
                  var nodeLength = nodeContent.length;
                  if (nodeLength > 80 && linkDensity < 0.25) {
                    append = true;
                  } else if (nodeLength < 80 && nodeLength > 0 && linkDensity === 0 && nodeContent.search(/\.( |$)/) !== -1) {
                    append = true;
                  }
                }
              }
              if (append) {
                this.log("Appending node:", sibling);
                if (!this.ALTER_TO_DIV_EXCEPTIONS.includes(sibling.nodeName)) {
                  this.log("Altering sibling:", sibling, "to div.");
                  sibling = this._setNodeTag(sibling, "DIV");
                }
                articleContent.appendChild(sibling);
                siblings = parentOfTopCandidate.children;
                s -= 1;
                sl -= 1;
              }
            }
            if (this._debug) {
              this.log("Article content pre-prep: " + articleContent.innerHTML);
            }
            this._prepArticle(articleContent);
            if (this._debug) {
              this.log("Article content post-prep: " + articleContent.innerHTML);
            }
            if (neededToCreateTopCandidate) {
              topCandidate.id = "readability-page-1";
              topCandidate.className = "page";
            } else {
              var div = doc.createElement("DIV");
              div.id = "readability-page-1";
              div.className = "page";
              while (articleContent.firstChild) {
                div.appendChild(articleContent.firstChild);
              }
              articleContent.appendChild(div);
            }
            if (this._debug) {
              this.log("Article content after paging: " + articleContent.innerHTML);
            }
            var parseSuccessful = true;
            var textLength = this._getInnerText(articleContent, true).length;
            if (textLength < this._charThreshold) {
              parseSuccessful = false;
              page.innerHTML = pageCacheHtml;
              this._attempts.push({
                articleContent,
                textLength
              });
              if (this._flagIsActive(this.FLAG_STRIP_UNLIKELYS)) {
                this._removeFlag(this.FLAG_STRIP_UNLIKELYS);
              } else if (this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
                this._removeFlag(this.FLAG_WEIGHT_CLASSES);
              } else if (this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
                this._removeFlag(this.FLAG_CLEAN_CONDITIONALLY);
              } else {
                this._attempts.sort(function(a, b) {
                  return b.textLength - a.textLength;
                });
                if (!this._attempts[0].textLength) {
                  return null;
                }
                articleContent = this._attempts[0].articleContent;
                parseSuccessful = true;
              }
            }
            if (parseSuccessful) {
              var ancestors = [parentOfTopCandidate, topCandidate].concat(
                this._getNodeAncestors(parentOfTopCandidate)
              );
              this._someNode(ancestors, function(ancestor) {
                if (!ancestor.tagName) {
                  return false;
                }
                var articleDir = ancestor.getAttribute("dir");
                if (articleDir) {
                  this._articleDir = articleDir;
                  return true;
                }
                return false;
              });
              return articleContent;
            }
          }
        },
        /**
         * Converts some of the common HTML entities in string to their corresponding characters.
         *
         * @param str {string} - a string to unescape.
         * @return string without HTML entity.
         */
        _unescapeHtmlEntities(str) {
          if (!str) {
            return str;
          }
          var htmlEscapeMap = this.HTML_ESCAPE_MAP;
          return str.replace(/&(quot|amp|apos|lt|gt);/g, function(_, tag) {
            return htmlEscapeMap[tag];
          }).replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi, function(_, hex, numStr) {
            var num = parseInt(hex || numStr, hex ? 16 : 10);
            if (num == 0 || num > 1114111 || num >= 55296 && num <= 57343) {
              num = 65533;
            }
            return String.fromCodePoint(num);
          });
        },
        /**
         * Try to extract metadata from JSON-LD object.
         * For now, only Schema.org objects of type Article or its subtypes are supported.
         * @return Object with any metadata that could be extracted (possibly none)
         */
        _getJSONLD(doc) {
          var scripts = this._getAllNodesWithTag(doc, ["script"]);
          var metadata;
          this._forEachNode(scripts, function(jsonLdElement) {
            if (!metadata && jsonLdElement.getAttribute("type") === "application/ld+json") {
              try {
                var content = jsonLdElement.textContent.replace(
                  /^\s*<!\[CDATA\[|\]\]>\s*$/g,
                  ""
                );
                var parsed = JSON.parse(content);
                if (Array.isArray(parsed)) {
                  parsed = parsed.find((it) => {
                    return it["@type"] && it["@type"].match(this.REGEXPS.jsonLdArticleTypes);
                  });
                  if (!parsed) {
                    return;
                  }
                }
                var schemaDotOrgRegex = /^https?\:\/\/schema\.org\/?$/;
                var matches = typeof parsed["@context"] === "string" && parsed["@context"].match(schemaDotOrgRegex) || typeof parsed["@context"] === "object" && typeof parsed["@context"]["@vocab"] == "string" && parsed["@context"]["@vocab"].match(schemaDotOrgRegex);
                if (!matches) {
                  return;
                }
                if (!parsed["@type"] && Array.isArray(parsed["@graph"])) {
                  parsed = parsed["@graph"].find((it) => {
                    return (it["@type"] || "").match(this.REGEXPS.jsonLdArticleTypes);
                  });
                }
                if (!parsed || !parsed["@type"] || !parsed["@type"].match(this.REGEXPS.jsonLdArticleTypes)) {
                  return;
                }
                metadata = {};
                if (typeof parsed.name === "string" && typeof parsed.headline === "string" && parsed.name !== parsed.headline) {
                  var title = this._getArticleTitle();
                  var nameMatches = this._textSimilarity(parsed.name, title) > 0.75;
                  var headlineMatches = this._textSimilarity(parsed.headline, title) > 0.75;
                  if (headlineMatches && !nameMatches) {
                    metadata.title = parsed.headline;
                  } else {
                    metadata.title = parsed.name;
                  }
                } else if (typeof parsed.name === "string") {
                  metadata.title = parsed.name.trim();
                } else if (typeof parsed.headline === "string") {
                  metadata.title = parsed.headline.trim();
                }
                if (parsed.author) {
                  if (typeof parsed.author.name === "string") {
                    metadata.byline = parsed.author.name.trim();
                  } else if (Array.isArray(parsed.author) && parsed.author[0] && typeof parsed.author[0].name === "string") {
                    metadata.byline = parsed.author.filter(function(author) {
                      return author && typeof author.name === "string";
                    }).map(function(author) {
                      return author.name.trim();
                    }).join(", ");
                  }
                }
                if (typeof parsed.description === "string") {
                  metadata.excerpt = parsed.description.trim();
                }
                if (parsed.publisher && typeof parsed.publisher.name === "string") {
                  metadata.siteName = parsed.publisher.name.trim();
                }
                if (typeof parsed.datePublished === "string") {
                  metadata.datePublished = parsed.datePublished.trim();
                }
              } catch (err) {
                this.log(err.message);
              }
            }
          });
          return metadata ? metadata : {};
        },
        /**
         * Attempts to get excerpt and byline metadata for the article.
         *
         * @param {Object} jsonld — object containing any metadata that
         * could be extracted from JSON-LD object.
         *
         * @return Object with optional "excerpt" and "byline" properties
         */
        _getArticleMetadata(jsonld) {
          var metadata = {};
          var values = {};
          var metaElements = this._doc.getElementsByTagName("meta");
          var propertyPattern = /\s*(article|dc|dcterm|og|twitter)\s*:\s*(author|creator|description|published_time|title|site_name)\s*/gi;
          var namePattern = /^\s*(?:(dc|dcterm|og|twitter|parsely|weibo:(article|webpage))\s*[-\.:]\s*)?(author|creator|pub-date|description|title|site_name)\s*$/i;
          this._forEachNode(metaElements, function(element) {
            var elementName = element.getAttribute("name");
            var elementProperty = element.getAttribute("property");
            var content = element.getAttribute("content");
            if (!content) {
              return;
            }
            var matches = null;
            var name = null;
            if (elementProperty) {
              matches = elementProperty.match(propertyPattern);
              if (matches) {
                name = matches[0].toLowerCase().replace(/\s/g, "");
                values[name] = content.trim();
              }
            }
            if (!matches && elementName && namePattern.test(elementName)) {
              name = elementName;
              if (content) {
                name = name.toLowerCase().replace(/\s/g, "").replace(/\./g, ":");
                values[name] = content.trim();
              }
            }
          });
          metadata.title = jsonld.title || values["dc:title"] || values["dcterm:title"] || values["og:title"] || values["weibo:article:title"] || values["weibo:webpage:title"] || values.title || values["twitter:title"] || values["parsely-title"];
          if (!metadata.title) {
            metadata.title = this._getArticleTitle();
          }
          const articleAuthor = typeof values["article:author"] === "string" && !this._isUrl(values["article:author"]) ? values["article:author"] : void 0;
          metadata.byline = jsonld.byline || values["dc:creator"] || values["dcterm:creator"] || values.author || values["parsely-author"] || articleAuthor;
          metadata.excerpt = jsonld.excerpt || values["dc:description"] || values["dcterm:description"] || values["og:description"] || values["weibo:article:description"] || values["weibo:webpage:description"] || values.description || values["twitter:description"];
          metadata.siteName = jsonld.siteName || values["og:site_name"];
          metadata.publishedTime = jsonld.datePublished || values["article:published_time"] || values["parsely-pub-date"] || null;
          metadata.title = this._unescapeHtmlEntities(metadata.title);
          metadata.byline = this._unescapeHtmlEntities(metadata.byline);
          metadata.excerpt = this._unescapeHtmlEntities(metadata.excerpt);
          metadata.siteName = this._unescapeHtmlEntities(metadata.siteName);
          metadata.publishedTime = this._unescapeHtmlEntities(metadata.publishedTime);
          return metadata;
        },
        /**
         * Check if node is image, or if node contains exactly only one image
         * whether as a direct child or as its descendants.
         *
         * @param Element
         **/
        _isSingleImage(node) {
          while (node) {
            if (node.tagName === "IMG") {
              return true;
            }
            if (node.children.length !== 1 || node.textContent.trim() !== "") {
              return false;
            }
            node = node.children[0];
          }
          return false;
        },
        /**
         * Find all <noscript> that are located after <img> nodes, and which contain only one
         * <img> element. Replace the first image with the image from inside the <noscript> tag,
         * and remove the <noscript> tag. This improves the quality of the images we use on
         * some sites (e.g. Medium).
         *
         * @param Element
         **/
        _unwrapNoscriptImages(doc) {
          var imgs = Array.from(doc.getElementsByTagName("img"));
          this._forEachNode(imgs, function(img) {
            for (var i = 0; i < img.attributes.length; i++) {
              var attr = img.attributes[i];
              switch (attr.name) {
                case "src":
                case "srcset":
                case "data-src":
                case "data-srcset":
                  return;
              }
              if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                return;
              }
            }
            img.remove();
          });
          var noscripts = Array.from(doc.getElementsByTagName("noscript"));
          this._forEachNode(noscripts, function(noscript) {
            if (!this._isSingleImage(noscript)) {
              return;
            }
            var tmp = doc.createElement("div");
            tmp.innerHTML = noscript.innerHTML;
            var prevElement = noscript.previousElementSibling;
            if (prevElement && this._isSingleImage(prevElement)) {
              var prevImg = prevElement;
              if (prevImg.tagName !== "IMG") {
                prevImg = prevElement.getElementsByTagName("img")[0];
              }
              var newImg = tmp.getElementsByTagName("img")[0];
              for (var i = 0; i < prevImg.attributes.length; i++) {
                var attr = prevImg.attributes[i];
                if (attr.value === "") {
                  continue;
                }
                if (attr.name === "src" || attr.name === "srcset" || /\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                  if (newImg.getAttribute(attr.name) === attr.value) {
                    continue;
                  }
                  var attrName = attr.name;
                  if (newImg.hasAttribute(attrName)) {
                    attrName = "data-old-" + attrName;
                  }
                  newImg.setAttribute(attrName, attr.value);
                }
              }
              noscript.parentNode.replaceChild(tmp.firstElementChild, prevElement);
            }
          });
        },
        /**
         * Removes script tags from the document.
         *
         * @param Element
         **/
        _removeScripts(doc) {
          this._removeNodes(this._getAllNodesWithTag(doc, ["script", "noscript"]));
        },
        /**
         * Check if this node has only whitespace and a single element with given tag
         * Returns false if the DIV node contains non-empty text nodes
         * or if it contains no element with given tag or more than 1 element.
         *
         * @param Element
         * @param string tag of child element
         **/
        _hasSingleTagInsideElement(element, tag) {
          if (element.children.length != 1 || element.children[0].tagName !== tag) {
            return false;
          }
          return !this._someNode(element.childNodes, function(node) {
            return node.nodeType === this.TEXT_NODE && this.REGEXPS.hasContent.test(node.textContent);
          });
        },
        _isElementWithoutContent(node) {
          return node.nodeType === this.ELEMENT_NODE && !node.textContent.trim().length && (!node.children.length || node.children.length == node.getElementsByTagName("br").length + node.getElementsByTagName("hr").length);
        },
        /**
         * Determine whether element has any children block level elements.
         *
         * @param Element
         */
        _hasChildBlockElement(element) {
          return this._someNode(element.childNodes, function(node) {
            return this.DIV_TO_P_ELEMS.has(node.tagName) || this._hasChildBlockElement(node);
          });
        },
        /***
         * Determine if a node qualifies as phrasing content.
         * https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Phrasing_content
         **/
        _isPhrasingContent(node) {
          return node.nodeType === this.TEXT_NODE || this.PHRASING_ELEMS.includes(node.tagName) || (node.tagName === "A" || node.tagName === "DEL" || node.tagName === "INS") && this._everyNode(node.childNodes, this._isPhrasingContent);
        },
        _isWhitespace(node) {
          return node.nodeType === this.TEXT_NODE && node.textContent.trim().length === 0 || node.nodeType === this.ELEMENT_NODE && node.tagName === "BR";
        },
        /**
         * Get the inner text of a node - cross browser compatibly.
         * This also strips out any excess whitespace to be found.
         *
         * @param Element
         * @param Boolean normalizeSpaces (default: true)
         * @return string
         **/
        _getInnerText(e, normalizeSpaces) {
          normalizeSpaces = typeof normalizeSpaces === "undefined" ? true : normalizeSpaces;
          var textContent = e.textContent.trim();
          if (normalizeSpaces) {
            return textContent.replace(this.REGEXPS.normalize, " ");
          }
          return textContent;
        },
        /**
         * Get the number of times a string s appears in the node e.
         *
         * @param Element
         * @param string - what to split on. Default is ","
         * @return number (integer)
         **/
        _getCharCount(e, s) {
          s = s || ",";
          return this._getInnerText(e).split(s).length - 1;
        },
        /**
         * Remove the style attribute on every e and under.
         * TODO: Test if getElementsByTagName(*) is faster.
         *
         * @param Element
         * @return void
         **/
        _cleanStyles(e) {
          if (!e || e.tagName.toLowerCase() === "svg") {
            return;
          }
          for (var i = 0; i < this.PRESENTATIONAL_ATTRIBUTES.length; i++) {
            e.removeAttribute(this.PRESENTATIONAL_ATTRIBUTES[i]);
          }
          if (this.DEPRECATED_SIZE_ATTRIBUTE_ELEMS.includes(e.tagName)) {
            e.removeAttribute("width");
            e.removeAttribute("height");
          }
          var cur = e.firstElementChild;
          while (cur !== null) {
            this._cleanStyles(cur);
            cur = cur.nextElementSibling;
          }
        },
        /**
         * Get the density of links as a percentage of the content
         * This is the amount of text that is inside a link divided by the total text in the node.
         *
         * @param Element
         * @return number (float)
         **/
        _getLinkDensity(element) {
          var textLength = this._getInnerText(element).length;
          if (textLength === 0) {
            return 0;
          }
          var linkLength = 0;
          this._forEachNode(element.getElementsByTagName("a"), function(linkNode) {
            var href = linkNode.getAttribute("href");
            var coefficient = href && this.REGEXPS.hashUrl.test(href) ? 0.3 : 1;
            linkLength += this._getInnerText(linkNode).length * coefficient;
          });
          return linkLength / textLength;
        },
        /**
         * Get an elements class/id weight. Uses regular expressions to tell if this
         * element looks good or bad.
         *
         * @param Element
         * @return number (Integer)
         **/
        _getClassWeight(e) {
          if (!this._flagIsActive(this.FLAG_WEIGHT_CLASSES)) {
            return 0;
          }
          var weight = 0;
          if (typeof e.className === "string" && e.className !== "") {
            if (this.REGEXPS.negative.test(e.className)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.className)) {
              weight += 25;
            }
          }
          if (typeof e.id === "string" && e.id !== "") {
            if (this.REGEXPS.negative.test(e.id)) {
              weight -= 25;
            }
            if (this.REGEXPS.positive.test(e.id)) {
              weight += 25;
            }
          }
          return weight;
        },
        /**
         * Clean a node of all elements of type "tag".
         * (Unless it's a youtube/vimeo video. People love movies.)
         *
         * @param Element
         * @param string tag to clean
         * @return void
         **/
        _clean(e, tag) {
          var isEmbed = ["object", "embed", "iframe"].includes(tag);
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(element) {
            if (isEmbed) {
              for (var i = 0; i < element.attributes.length; i++) {
                if (this._allowedVideoRegex.test(element.attributes[i].value)) {
                  return false;
                }
              }
              if (element.tagName === "object" && this._allowedVideoRegex.test(element.innerHTML)) {
                return false;
              }
            }
            return true;
          });
        },
        /**
         * Check if a given node has one of its ancestor tag name matching the
         * provided one.
         * @param  HTMLElement node
         * @param  String      tagName
         * @param  Number      maxDepth
         * @param  Function    filterFn a filter to invoke to determine whether this node 'counts'
         * @return Boolean
         */
        _hasAncestorTag(node, tagName, maxDepth, filterFn) {
          maxDepth = maxDepth || 3;
          tagName = tagName.toUpperCase();
          var depth = 0;
          while (node.parentNode) {
            if (maxDepth > 0 && depth > maxDepth) {
              return false;
            }
            if (node.parentNode.tagName === tagName && (!filterFn || filterFn(node.parentNode))) {
              return true;
            }
            node = node.parentNode;
            depth++;
          }
          return false;
        },
        /**
         * Return an object indicating how many rows and columns this table has.
         */
        _getRowAndColumnCount(table) {
          var rows = 0;
          var columns = 0;
          var trs = table.getElementsByTagName("tr");
          for (var i = 0; i < trs.length; i++) {
            var rowspan = trs[i].getAttribute("rowspan") || 0;
            if (rowspan) {
              rowspan = parseInt(rowspan, 10);
            }
            rows += rowspan || 1;
            var columnsInThisRow = 0;
            var cells = trs[i].getElementsByTagName("td");
            for (var j = 0; j < cells.length; j++) {
              var colspan = cells[j].getAttribute("colspan") || 0;
              if (colspan) {
                colspan = parseInt(colspan, 10);
              }
              columnsInThisRow += colspan || 1;
            }
            columns = Math.max(columns, columnsInThisRow);
          }
          return { rows, columns };
        },
        /**
         * Look for 'data' (as opposed to 'layout') tables, for which we use
         * similar checks as
         * https://searchfox.org/mozilla-central/rev/f82d5c549f046cb64ce5602bfd894b7ae807c8f8/accessible/generic/TableAccessible.cpp#19
         */
        _markDataTables(root) {
          var tables = root.getElementsByTagName("table");
          for (var i = 0; i < tables.length; i++) {
            var table = tables[i];
            var role = table.getAttribute("role");
            if (role == "presentation") {
              table._readabilityDataTable = false;
              continue;
            }
            var datatable = table.getAttribute("datatable");
            if (datatable == "0") {
              table._readabilityDataTable = false;
              continue;
            }
            var summary = table.getAttribute("summary");
            if (summary) {
              table._readabilityDataTable = true;
              continue;
            }
            var caption = table.getElementsByTagName("caption")[0];
            if (caption && caption.childNodes.length) {
              table._readabilityDataTable = true;
              continue;
            }
            var dataTableDescendants = ["col", "colgroup", "tfoot", "thead", "th"];
            var descendantExists = function(tag) {
              return !!table.getElementsByTagName(tag)[0];
            };
            if (dataTableDescendants.some(descendantExists)) {
              this.log("Data table because found data-y descendant");
              table._readabilityDataTable = true;
              continue;
            }
            if (table.getElementsByTagName("table")[0]) {
              table._readabilityDataTable = false;
              continue;
            }
            var sizeInfo = this._getRowAndColumnCount(table);
            if (sizeInfo.columns == 1 || sizeInfo.rows == 1) {
              table._readabilityDataTable = false;
              continue;
            }
            if (sizeInfo.rows >= 10 || sizeInfo.columns > 4) {
              table._readabilityDataTable = true;
              continue;
            }
            table._readabilityDataTable = sizeInfo.rows * sizeInfo.columns > 10;
          }
        },
        /* convert images and figures that have properties like data-src into images that can be loaded without JS */
        _fixLazyImages(root) {
          this._forEachNode(
            this._getAllNodesWithTag(root, ["img", "picture", "figure"]),
            function(elem) {
              if (elem.src && this.REGEXPS.b64DataUrl.test(elem.src)) {
                var parts = this.REGEXPS.b64DataUrl.exec(elem.src);
                if (parts[1] === "image/svg+xml") {
                  return;
                }
                var srcCouldBeRemoved = false;
                for (var i = 0; i < elem.attributes.length; i++) {
                  var attr = elem.attributes[i];
                  if (attr.name === "src") {
                    continue;
                  }
                  if (/\.(jpg|jpeg|png|webp)/i.test(attr.value)) {
                    srcCouldBeRemoved = true;
                    break;
                  }
                }
                if (srcCouldBeRemoved) {
                  var b64starts = parts[0].length;
                  var b64length = elem.src.length - b64starts;
                  if (b64length < 133) {
                    elem.removeAttribute("src");
                  }
                }
              }
              if ((elem.src || elem.srcset && elem.srcset != "null") && !elem.className.toLowerCase().includes("lazy")) {
                return;
              }
              for (var j = 0; j < elem.attributes.length; j++) {
                attr = elem.attributes[j];
                if (attr.name === "src" || attr.name === "srcset" || attr.name === "alt") {
                  continue;
                }
                var copyTo = null;
                if (/\.(jpg|jpeg|png|webp)\s+\d/.test(attr.value)) {
                  copyTo = "srcset";
                } else if (/^\s*\S+\.(jpg|jpeg|png|webp)\S*\s*$/.test(attr.value)) {
                  copyTo = "src";
                }
                if (copyTo) {
                  if (elem.tagName === "IMG" || elem.tagName === "PICTURE") {
                    elem.setAttribute(copyTo, attr.value);
                  } else if (elem.tagName === "FIGURE" && !this._getAllNodesWithTag(elem, ["img", "picture"]).length) {
                    var img = this._doc.createElement("img");
                    img.setAttribute(copyTo, attr.value);
                    elem.appendChild(img);
                  }
                }
              }
            }
          );
        },
        _getTextDensity(e, tags) {
          var textLength = this._getInnerText(e, true).length;
          if (textLength === 0) {
            return 0;
          }
          var childrenLength = 0;
          var children = this._getAllNodesWithTag(e, tags);
          this._forEachNode(
            children,
            (child) => childrenLength += this._getInnerText(child, true).length
          );
          return childrenLength / textLength;
        },
        /**
         * Clean an element of all tags of type "tag" if they look fishy.
         * "Fishy" is an algorithm based on content length, classnames, link density, number of images & embeds, etc.
         *
         * @return void
         **/
        _cleanConditionally(e, tag) {
          if (!this._flagIsActive(this.FLAG_CLEAN_CONDITIONALLY)) {
            return;
          }
          this._removeNodes(this._getAllNodesWithTag(e, [tag]), function(node) {
            var isDataTable = function(t) {
              return t._readabilityDataTable;
            };
            var isList = tag === "ul" || tag === "ol";
            if (!isList) {
              var listLength = 0;
              var listNodes = this._getAllNodesWithTag(node, ["ul", "ol"]);
              this._forEachNode(
                listNodes,
                (list) => listLength += this._getInnerText(list).length
              );
              isList = listLength / this._getInnerText(node).length > 0.9;
            }
            if (tag === "table" && isDataTable(node)) {
              return false;
            }
            if (this._hasAncestorTag(node, "table", -1, isDataTable)) {
              return false;
            }
            if (this._hasAncestorTag(node, "code")) {
              return false;
            }
            if ([...node.getElementsByTagName("table")].some(
              (tbl) => tbl._readabilityDataTable
            )) {
              return false;
            }
            var weight = this._getClassWeight(node);
            this.log("Cleaning Conditionally", node);
            var contentScore = 0;
            if (weight + contentScore < 0) {
              return true;
            }
            if (this._getCharCount(node, ",") < 10) {
              var p = node.getElementsByTagName("p").length;
              var img = node.getElementsByTagName("img").length;
              var li = node.getElementsByTagName("li").length - 100;
              var input = node.getElementsByTagName("input").length;
              var headingDensity = this._getTextDensity(node, [
                "h1",
                "h2",
                "h3",
                "h4",
                "h5",
                "h6"
              ]);
              var embedCount = 0;
              var embeds = this._getAllNodesWithTag(node, [
                "object",
                "embed",
                "iframe"
              ]);
              for (var i = 0; i < embeds.length; i++) {
                for (var j = 0; j < embeds[i].attributes.length; j++) {
                  if (this._allowedVideoRegex.test(embeds[i].attributes[j].value)) {
                    return false;
                  }
                }
                if (embeds[i].tagName === "object" && this._allowedVideoRegex.test(embeds[i].innerHTML)) {
                  return false;
                }
                embedCount++;
              }
              var innerText = this._getInnerText(node);
              if (this.REGEXPS.adWords.test(innerText) || this.REGEXPS.loadingWords.test(innerText)) {
                return true;
              }
              var contentLength = innerText.length;
              var linkDensity = this._getLinkDensity(node);
              var textishTags = ["SPAN", "LI", "TD"].concat(
                Array.from(this.DIV_TO_P_ELEMS)
              );
              var textDensity = this._getTextDensity(node, textishTags);
              var isFigureChild = this._hasAncestorTag(node, "figure");
              const shouldRemoveNode = () => {
                const errs = [];
                if (!isFigureChild && img > 1 && p / img < 0.5) {
                  errs.push(`Bad p to img ratio (img=${img}, p=${p})`);
                }
                if (!isList && li > p) {
                  errs.push(`Too many li's outside of a list. (li=${li} > p=${p})`);
                }
                if (input > Math.floor(p / 3)) {
                  errs.push(`Too many inputs per p. (input=${input}, p=${p})`);
                }
                if (!isList && !isFigureChild && headingDensity < 0.9 && contentLength < 25 && (img === 0 || img > 2) && linkDensity > 0) {
                  errs.push(
                    `Suspiciously short. (headingDensity=${headingDensity}, img=${img}, linkDensity=${linkDensity})`
                  );
                }
                if (!isList && weight < 25 && linkDensity > 0.2 + this._linkDensityModifier) {
                  errs.push(
                    `Low weight and a little linky. (linkDensity=${linkDensity})`
                  );
                }
                if (weight >= 25 && linkDensity > 0.5 + this._linkDensityModifier) {
                  errs.push(
                    `High weight and mostly links. (linkDensity=${linkDensity})`
                  );
                }
                if (embedCount === 1 && contentLength < 75 || embedCount > 1) {
                  errs.push(
                    `Suspicious embed. (embedCount=${embedCount}, contentLength=${contentLength})`
                  );
                }
                if (img === 0 && textDensity === 0) {
                  errs.push(
                    `No useful content. (img=${img}, textDensity=${textDensity})`
                  );
                }
                if (errs.length) {
                  this.log("Checks failed", errs);
                  return true;
                }
                return false;
              };
              var haveToRemove = shouldRemoveNode();
              if (isList && haveToRemove) {
                for (var x = 0; x < node.children.length; x++) {
                  let child = node.children[x];
                  if (child.children.length > 1) {
                    return haveToRemove;
                  }
                }
                let li_count = node.getElementsByTagName("li").length;
                if (img == li_count) {
                  return false;
                }
              }
              return haveToRemove;
            }
            return false;
          });
        },
        /**
         * Clean out elements that match the specified conditions
         *
         * @param Element
         * @param Function determines whether a node should be removed
         * @return void
         **/
        _cleanMatchedNodes(e, filter) {
          var endOfSearchMarkerNode = this._getNextNode(e, true);
          var next = this._getNextNode(e);
          while (next && next != endOfSearchMarkerNode) {
            if (filter.call(this, next, next.className + " " + next.id)) {
              next = this._removeAndGetNext(next);
            } else {
              next = this._getNextNode(next);
            }
          }
        },
        /**
         * Clean out spurious headers from an Element.
         *
         * @param Element
         * @return void
         **/
        _cleanHeaders(e) {
          let headingNodes = this._getAllNodesWithTag(e, ["h1", "h2"]);
          this._removeNodes(headingNodes, function(node) {
            let shouldRemove = this._getClassWeight(node) < 0;
            if (shouldRemove) {
              this.log("Removing header with low class weight:", node);
            }
            return shouldRemove;
          });
        },
        /**
         * Check if this node is an H1 or H2 element whose content is mostly
         * the same as the article title.
         *
         * @param Element  the node to check.
         * @return boolean indicating whether this is a title-like header.
         */
        _headerDuplicatesTitle(node) {
          if (node.tagName != "H1" && node.tagName != "H2") {
            return false;
          }
          var heading = this._getInnerText(node, false);
          this.log("Evaluating similarity of header:", heading, this._articleTitle);
          return this._textSimilarity(this._articleTitle, heading) > 0.75;
        },
        _flagIsActive(flag) {
          return (this._flags & flag) > 0;
        },
        _removeFlag(flag) {
          this._flags = this._flags & ~flag;
        },
        _isProbablyVisible(node) {
          return (!node.style || node.style.display != "none") && (!node.style || node.style.visibility != "hidden") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
          (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
        },
        /**
         * Runs readability.
         *
         * Workflow:
         *  1. Prep the document by removing script tags, css, etc.
         *  2. Build readability's DOM tree.
         *  3. Grab the article content from the current dom tree.
         *  4. Replace the current DOM tree with the new one.
         *  5. Read peacefully.
         *
         * @return void
         **/
        parse() {
          if (this._maxElemsToParse > 0) {
            var numTags = this._doc.getElementsByTagName("*").length;
            if (numTags > this._maxElemsToParse) {
              throw new Error(
                "Aborting parsing document; " + numTags + " elements found"
              );
            }
          }
          this._unwrapNoscriptImages(this._doc);
          var jsonLd = this._disableJSONLD ? {} : this._getJSONLD(this._doc);
          this._removeScripts(this._doc);
          this._prepDocument();
          var metadata = this._getArticleMetadata(jsonLd);
          this._metadata = metadata;
          this._articleTitle = metadata.title;
          var articleContent = this._grabArticle();
          if (!articleContent) {
            return null;
          }
          this.log("Grabbed: " + articleContent.innerHTML);
          this._postProcessContent(articleContent);
          if (!metadata.excerpt) {
            var paragraphs = articleContent.getElementsByTagName("p");
            if (paragraphs.length) {
              metadata.excerpt = paragraphs[0].textContent.trim();
            }
          }
          var textContent = articleContent.textContent;
          return {
            title: this._articleTitle,
            byline: metadata.byline || this._articleByline,
            dir: this._articleDir,
            lang: this._articleLang,
            content: this._serializer(articleContent),
            textContent,
            length: textContent.length,
            excerpt: metadata.excerpt,
            siteName: metadata.siteName || this._articleSiteName,
            publishedTime: metadata.publishedTime
          };
        }
      };
      if (typeof module === "object") {
        module.exports = Readability2;
      }
    }
  });

  // ../../node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/Readability-readerable.js
  var require_Readability_readerable = __commonJS({
    "../../node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/Readability-readerable.js"(exports, module) {
      var REGEXPS = {
        // NOTE: These two regular expressions are duplicated in
        // Readability.js. Please keep both copies in sync.
        unlikelyCandidates: /-ad-|ai2html|banner|breadcrumbs|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legends|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|yom-remote/i,
        okMaybeItsACandidate: /and|article|body|column|content|main|shadow/i
      };
      function isNodeVisible(node) {
        return (!node.style || node.style.display != "none") && !node.hasAttribute("hidden") && //check for "fallback-image" so that wikimedia math images are displayed
        (!node.hasAttribute("aria-hidden") || node.getAttribute("aria-hidden") != "true" || node.className && node.className.includes && node.className.includes("fallback-image"));
      }
      function isProbablyReaderable2(doc, options = {}) {
        if (typeof options == "function") {
          options = { visibilityChecker: options };
        }
        var defaultOptions = {
          minScore: 20,
          minContentLength: 140,
          visibilityChecker: isNodeVisible
        };
        options = Object.assign(defaultOptions, options);
        var nodes = doc.querySelectorAll("p, pre, article");
        var brNodes = doc.querySelectorAll("div > br");
        if (brNodes.length) {
          var set = new Set(nodes);
          [].forEach.call(brNodes, function(node) {
            set.add(node.parentNode);
          });
          nodes = Array.from(set);
        }
        var score = 0;
        return [].some.call(nodes, function(node) {
          if (!options.visibilityChecker(node)) {
            return false;
          }
          var matchString = node.className + " " + node.id;
          if (REGEXPS.unlikelyCandidates.test(matchString) && !REGEXPS.okMaybeItsACandidate.test(matchString)) {
            return false;
          }
          if (node.matches("li p")) {
            return false;
          }
          var textContentLength = node.textContent.trim().length;
          if (textContentLength < options.minContentLength) {
            return false;
          }
          score += Math.sqrt(textContentLength - options.minContentLength);
          if (score > options.minScore) {
            return true;
          }
          return false;
        });
      }
      if (typeof module === "object") {
        module.exports = isProbablyReaderable2;
      }
    }
  });

  // ../../node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/index.js
  var require_readability = __commonJS({
    "../../node_modules/.pnpm/@mozilla+readability@0.6.0/node_modules/@mozilla/readability/index.js"(exports, module) {
      var Readability2 = require_Readability();
      var isProbablyReaderable2 = require_Readability_readerable();
      module.exports = {
        Readability: Readability2,
        isProbablyReaderable: isProbablyReaderable2
      };
    }
  });

  // ../../packages/shared/dist/types/semantic-browser-runtime.js
  var require_semantic_browser_runtime = __commonJS({
    "../../packages/shared/dist/types/semantic-browser-runtime.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.sanitizeInteractiveNode = sanitizeInteractiveNode2;
      var SENSITIVE_INPUT_TYPES = /* @__PURE__ */ new Set(["password", "hidden", "email", "tel"]);
      var SENSITIVE_AUTOCOMPLETE = /* @__PURE__ */ new Set([
        "cc-number",
        "cc-exp",
        "cc-csc",
        "cc-name",
        "email",
        "tel",
        "one-time-code"
      ]);
      var SENSITIVE_NAME_PATTERNS = /ssn|social|secret|token|password|credit|session|auth|api[-_]?key/i;
      var PREVIEW_LIMIT = 80;
      function sanitizeInteractiveNode2(node) {
        const metadata = node.metadata ?? {};
        const inputType = metadata.inputType?.toLowerCase() ?? "";
        const autocomplete = metadata.autocomplete?.toLowerCase() ?? "";
        const name = metadata.name ?? "";
        const rawValue = metadata.rawValue ?? "";
        const placeholder = metadata.placeholder ?? "";
        const isSensitive = SENSITIVE_INPUT_TYPES.has(inputType) || SENSITIVE_AUTOCOMPLETE.has(autocomplete) || SENSITIVE_NAME_PATTERNS.test(name);
        const nextMetadata = { ...metadata };
        delete nextMetadata.rawValue;
        if (inputType === "hidden" || inputType === "file") {
          return {
            ...node,
            ...Object.keys(nextMetadata).length > 0 ? { metadata: nextMetadata } : {}
          };
        }
        if (node.controlType === "textarea") {
          return {
            ...node,
            ...Object.keys(nextMetadata).length > 0 ? { metadata: nextMetadata } : {}
          };
        }
        if (node.controlType === "checkbox" || node.controlType === "radio" || node.controlType === "select") {
          return {
            ...node,
            ...Object.keys(nextMetadata).length > 0 ? { metadata: nextMetadata } : {}
          };
        }
        const previewSource = isSensitive ? "[redacted]" : rawValue || placeholder;
        const valuePreview = previewSource ? previewSource.slice(0, PREVIEW_LIMIT) : void 0;
        return {
          ...node,
          ...valuePreview ? { valuePreview } : {},
          ...Object.keys(nextMetadata).length > 0 ? { metadata: nextMetadata } : {}
        };
      }
    }
  });

  // ../../packages/shared/dist/types/semantic-enhancer.js
  var require_semantic_enhancer = __commonJS({
    "../../packages/shared/dist/types/semantic-enhancer.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantic-runtime.js
  var require_semantic_runtime = __commonJS({
    "../../packages/shared/dist/types/semantic-runtime.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/browser-runtime.js
  var require_browser_runtime = __commonJS({
    "../../packages/shared/dist/browser-runtime.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      __exportStar(require_semantic_browser_runtime(), exports);
      __exportStar(require_semantic_enhancer(), exports);
      __exportStar(require_semantic_runtime(), exports);
    }
  });

  // ../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/ElementNode.js
  var require_ElementNode = __commonJS({
    "../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/ElementNode.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports._Node = void 0;
      exports._Node = {
        /** node is an element. */
        ELEMENT_NODE: 1,
        ATTRIBUTE_NODE: 2,
        /** node is a Text node. */
        TEXT_NODE: 3,
        /** node is a CDATASection node. */
        CDATA_SECTION_NODE: 4,
        ENTITY_REFERENCE_NODE: 5,
        ENTITY_NODE: 6,
        /** node is a ProcessingInstruction node. */
        PROCESSING_INSTRUCTION_NODE: 7,
        /** node is a Comment node. */
        COMMENT_NODE: 8,
        /** node is a document. */
        DOCUMENT_NODE: 9,
        /** node is a doctype. */
        DOCUMENT_TYPE_NODE: 10,
        /** node is a DocumentFragment node. */
        DOCUMENT_FRAGMENT_NODE: 11,
        NOTATION_NODE: 12,
        /** Set when node and other are not in the same tree. */
        DOCUMENT_POSITION_DISCONNECTED: 1,
        /** Set when other is preceding node. */
        DOCUMENT_POSITION_PRECEDING: 2,
        /** Set when other is following node. */
        DOCUMENT_POSITION_FOLLOWING: 4,
        /** Set when other is an ancestor of node. */
        DOCUMENT_POSITION_CONTAINS: 8,
        /** Set when other is a descendant of node. */
        DOCUMENT_POSITION_CONTAINED_BY: 16,
        DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC: 32
      };
    }
  });

  // ../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/htmlToMarkdownAST.js
  var require_htmlToMarkdownAST = __commonJS({
    "../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/htmlToMarkdownAST.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.htmlToMarkdownAST = htmlToMarkdownAST2;
      var ElementNode_1 = require_ElementNode();
      function htmlToMarkdownAST2(element, options, indentLevel = 0) {
        let result = [];
        const debugLog = (message) => {
          if (options?.debug) {
            console.log(message);
          }
        };
        element.childNodes.forEach((childElement) => {
          const overriddenElementProcessing = options?.overrideElementProcessing?.(childElement, options, indentLevel);
          if (overriddenElementProcessing) {
            debugLog(`Element Processing Overridden: '${childElement.nodeType}'`);
            result.push(...overriddenElementProcessing);
          } else if (childElement.nodeType === ElementNode_1._Node.TEXT_NODE) {
            const textContent = escapeMarkdownCharacters(childElement.textContent?.trim() ?? "");
            if (textContent && !!childElement.textContent) {
              debugLog(`Text Node: '${textContent}'`);
              result.push({ type: "text", content: childElement.textContent?.trim() });
            }
          } else if (childElement.nodeType === ElementNode_1._Node.ELEMENT_NODE) {
            const elem = childElement;
            if (/^h[1-6]$/i.test(elem.tagName)) {
              const level = parseInt(elem.tagName.substring(1));
              debugLog(`Heading ${level}`);
              result.push({
                type: "heading",
                level,
                content: htmlToMarkdownAST2(elem, options)
                // Process child elements
              });
            } else if (elem.tagName.toLowerCase() === "p") {
              debugLog("Paragraph");
              result.push(...htmlToMarkdownAST2(elem, options));
              result.push({ type: "text", content: "\n\n" });
            } else if (elem.tagName.toLowerCase() === "a") {
              debugLog(`Link: '${elem.href}' with text '${elem.textContent}'`);
              if (typeof elem.href === "string" && elem.href.startsWith("data:image")) {
                result.push({
                  type: "link",
                  href: "-",
                  content: htmlToMarkdownAST2(elem, options)
                });
              } else {
                let href = elem.href;
                if (typeof href === "string") {
                  href = options?.websiteDomain && href.startsWith(options.websiteDomain) ? href.substring(options.websiteDomain.length) : href;
                } else {
                  href = "#";
                }
                if (Array.from(elem.childNodes).every((_) => _.nodeType === ElementNode_1._Node.TEXT_NODE)) {
                  result.push({
                    type: "link",
                    href,
                    content: [{ type: "text", content: elem.textContent?.trim() ?? "" }]
                  });
                } else {
                  result.push({
                    type: "link",
                    href,
                    content: htmlToMarkdownAST2(elem, options)
                  });
                }
              }
            } else if (elem.tagName.toLowerCase() === "img") {
              debugLog(`Image: src='${elem.src}', alt='${elem.alt}'`);
              if (elem.src?.startsWith("data:image")) {
                result.push({
                  type: "image",
                  src: "-",
                  alt: escapeMarkdownCharacters(elem.alt)
                });
              } else {
                const src = options?.websiteDomain && elem.src?.startsWith(options.websiteDomain) ? elem.src?.substring(options.websiteDomain.length) : elem.src;
                result.push({ type: "image", src, alt: escapeMarkdownCharacters(elem.alt) });
              }
            } else if (elem.tagName.toLowerCase() === "video") {
              debugLog(`Video: src='${elem.src}', poster='${elem.poster}', controls='${elem.controls}'`);
              result.push({
                type: "video",
                src: elem.src,
                poster: escapeMarkdownCharacters(elem.poster),
                controls: elem.controls
              });
            } else if (elem.tagName.toLowerCase() === "ul" || elem.tagName.toLowerCase() === "ol") {
              debugLog(`${elem.tagName.toLowerCase() === "ul" ? "Unordered" : "Ordered"} List`);
              result.push({
                type: "list",
                ordered: elem.tagName.toLowerCase() === "ol",
                items: Array.from(elem.children).map((li) => ({
                  type: "listItem",
                  content: htmlToMarkdownAST2(li, options, indentLevel + 1)
                }))
              });
            } else if (elem.tagName.toLowerCase() === "br") {
              debugLog("Line Break");
              result.push({ type: "text", content: "\n" });
            } else if (elem.tagName.toLowerCase() === "table") {
              debugLog("Table");
              let colIds = [];
              if (options?.enableTableColumnTracking) {
                const headerCells = Array.from(elem.querySelectorAll("th, td"));
                headerCells.forEach((_, index) => {
                  colIds.push(`col-${index}`);
                });
              }
              const tableRows = Array.from(elem.querySelectorAll("tr"));
              const markdownTableRows = tableRows.map((row) => {
                let columnIndex = 0;
                const cells = Array.from(row.querySelectorAll("th, td")).map((cell) => {
                  const colspan = parseInt(cell.getAttribute("colspan") || "1", 10);
                  const rowspan = parseInt(cell.getAttribute("rowspan") || "1", 10);
                  const cellNode = {
                    type: "tableCell",
                    content: cell.nodeType === ElementNode_1._Node.TEXT_NODE ? escapeMarkdownCharacters(cell.textContent?.trim() ?? "") : htmlToMarkdownAST2(cell, options, indentLevel + 1),
                    colId: colIds[columnIndex],
                    colspan: colspan > 1 ? colspan : void 0,
                    rowspan: rowspan > 1 ? rowspan : void 0
                  };
                  columnIndex += colspan;
                  return cellNode;
                });
                return { type: "tableRow", cells };
              });
              if (markdownTableRows.length > 0) {
                const hasHeaders = tableRows[0].querySelector("th") !== null;
                if (hasHeaders) {
                  const headerSeparatorCells = Array.from(tableRows[0].querySelectorAll("th, td")).map(() => ({
                    type: "tableCell",
                    content: "---",
                    colId: void 0,
                    colspan: void 0,
                    rowspan: void 0
                  }));
                  const headerSeparatorRow = {
                    type: "tableRow",
                    cells: headerSeparatorCells
                  };
                  markdownTableRows.splice(1, 0, headerSeparatorRow);
                }
              }
              result.push({ type: "table", rows: markdownTableRows, colIds });
            } else if (elem.tagName.toLowerCase() === "head" && !!options?.includeMetaData) {
              const node = {
                type: "meta",
                content: {
                  standard: {},
                  openGraph: {},
                  twitter: {}
                }
              };
              elem.querySelectorAll("title").forEach((titleElem) => {
                node.content.standard["title"] = escapeMarkdownCharacters(titleElem.text);
              });
              const metaTags = elem.querySelectorAll("meta");
              const nonSemanticTagNames = [
                "viewport",
                "referrer",
                "Content-Security-Policy"
              ];
              metaTags.forEach((metaTag) => {
                const name = metaTag.getAttribute("name");
                const property = metaTag.getAttribute("property");
                const content = metaTag.getAttribute("content");
                if (property && property.startsWith("og:") && content) {
                  if (options.includeMetaData === "extended") {
                    node.content.openGraph[property.substring(3)] = content;
                  }
                } else if (name && name.startsWith("twitter:") && content) {
                  if (options.includeMetaData === "extended") {
                    node.content.twitter[name.substring(8)] = content;
                  }
                } else if (name && !nonSemanticTagNames.includes(name) && content) {
                  node.content.standard[name] = content;
                }
              });
              if (options.includeMetaData === "extended") {
                const jsonLdData = [];
                const jsonLDScripts = elem.querySelectorAll('script[type="application/ld+json"]');
                jsonLDScripts.forEach((script) => {
                  try {
                    const jsonContent = script.textContent;
                    if (jsonContent) {
                      const parsedData = JSON.parse(jsonContent);
                      jsonLdData.push(parsedData);
                    }
                  } catch (error) {
                    console.error("Failed to parse JSON-LD", error);
                  }
                });
                node.content.jsonLd = jsonLdData;
              }
              result.push(node);
            } else {
              const content = escapeMarkdownCharacters(elem.textContent || "");
              switch (elem.tagName.toLowerCase()) {
                case "noscript":
                case "script":
                case "style":
                case "html":
                  break;
                case "strong":
                case "b":
                  if (content) {
                    debugLog(`Bold: '${content}'`);
                    result.push({
                      type: "bold",
                      content: htmlToMarkdownAST2(elem, options, indentLevel + 1)
                    });
                  }
                  break;
                case "em":
                case "i":
                  if (content) {
                    debugLog(`Italic: '${content}'`);
                    result.push({
                      type: "italic",
                      content: htmlToMarkdownAST2(elem, options, indentLevel + 1)
                    });
                  }
                  break;
                case "s":
                case "strike":
                  if (content) {
                    debugLog(`Strikethrough: '${content}'`);
                    result.push({
                      type: "strikethrough",
                      content: htmlToMarkdownAST2(elem, options, indentLevel + 1)
                    });
                  }
                  break;
                case "code":
                  if (content) {
                    const isCodeBlock = elem.parentNode && elem.parentNode.nodeName.toLowerCase() === "pre";
                    debugLog(`${isCodeBlock ? "Code Block" : "Inline Code"}: '${content}'`);
                    const languageClass = elem.className?.split(" ").find((cls) => cls.startsWith("language-"));
                    const language = languageClass ? languageClass.replace("language-", "") : "";
                    result.push({
                      type: "code",
                      content: elem.textContent?.trim() ?? "",
                      language,
                      inline: !isCodeBlock
                    });
                  }
                  break;
                case "blockquote":
                  debugLog(`Blockquote`);
                  result.push({
                    type: "blockquote",
                    content: htmlToMarkdownAST2(elem, options)
                  });
                  break;
                case "article":
                case "aside":
                case "details":
                case "figcaption":
                case "figure":
                case "footer":
                case "header":
                case "main":
                case "mark":
                case "nav":
                case "section":
                case "summary":
                case "time":
                  debugLog(`Semantic HTML Element: '${elem.tagName}'`);
                  result.push({
                    type: "semanticHtml",
                    htmlType: elem.tagName.toLowerCase(),
                    content: htmlToMarkdownAST2(elem, options)
                  });
                  break;
                default:
                  const unhandledElementProcessing = options?.processUnhandledElement?.(elem, options, indentLevel);
                  if (unhandledElementProcessing) {
                    debugLog(`Processing Unhandled Element: '${elem.tagName}'`);
                    result.push(...unhandledElementProcessing);
                  } else {
                    debugLog(`Generic HTMLElement: '${elem.tagName}'`);
                    result.push(...htmlToMarkdownAST2(elem, options, indentLevel + 1));
                  }
                  break;
              }
            }
          }
        });
        return result;
      }
      function escapeMarkdownCharacters(text, isInlineCode = false) {
        if (isInlineCode || !text?.trim()) {
          return text;
        }
        let escapedText = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        escapedText = escapedText.replace(/([\\`*_{}[\]#+!|])/g, "\\$1");
        return escapedText;
      }
    }
  });

  // ../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/markdownASTToString.js
  var require_markdownASTToString = __commonJS({
    "../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/markdownASTToString.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.markdownASTToString = markdownASTToString;
      var index_1 = require_node();
      function aggressiveTrim(str) {
        if (typeof str !== "string")
          return "";
        return str.replace(/^[\s\u00A0\u200B]+|[\s\u00A0\u200B]+$/g, "");
      }
      function renderSimpleMetaObject(obj, indent = "") {
        if (!obj || Object.keys(obj).length === 0)
          return "";
        let metaString = "";
        Object.keys(obj).forEach((key) => {
          const value = String(obj[key] ?? "");
          metaString += `${indent}${key}: "${value.replace(/"/g, '\\"')}"
`;
        });
        return metaString;
      }
      function markdownMetaASTToString(nodes, options) {
        if (!options?.includeMetaData) {
          return "";
        }
        const metaNode = (0, index_1.findInMarkdownAST)(nodes, (_) => _.type === "meta");
        if (!metaNode) {
          return "---\n---\n\n";
        }
        let markdownString = "---\n";
        if (metaNode.content.standard) {
          markdownString += renderSimpleMetaObject(metaNode.content.standard);
        }
        if (options.includeMetaData === "extended") {
          if (metaNode.content.openGraph && Object.keys(metaNode.content.openGraph).length > 0) {
            markdownString += "openGraph:\n";
            markdownString += renderSimpleMetaObject(metaNode.content.openGraph, "  ");
          }
          if (metaNode.content.twitter && Object.keys(metaNode.content.twitter).length > 0) {
            markdownString += "twitter:\n";
            markdownString += renderSimpleMetaObject(metaNode.content.twitter, "  ");
          }
          if (metaNode.content.jsonLd && metaNode.content.jsonLd.length > 0) {
            markdownString += "schema:\n";
            metaNode.content.jsonLd.forEach((item) => {
              if (!item)
                return;
              const { "@context": _jldContext, "@type": jldType, ...semanticData } = item;
              markdownString += `  ${jldType ?? "(unknown type)"}:
`;
              Object.keys(semanticData).forEach((key) => {
                const value = semanticData[key];
                markdownString += `    ${key}: ${JSON.stringify(value ?? null)}
`;
              });
            });
          }
        }
        markdownString += "---\n\n\n";
        return markdownString;
      }
      function processNodeContent(content, renderChildren, options, indentLevel) {
        if (typeof content === "string") {
          return content;
        }
        if (Array.isArray(content)) {
          return renderChildren(content, options, indentLevel);
        }
        return "";
      }
      var nodeRenderers = {
        text: (node) => {
          return typeof node.content === "string" ? node.content : "";
        },
        bold: (node, options, renderChildren, indentLevel) => {
          const contentString = processNodeContent(node.content, renderChildren, options, indentLevel);
          return `**${aggressiveTrim(contentString)}**`;
        },
        italic: (node, options, renderChildren, indentLevel) => {
          const contentString = processNodeContent(node.content, renderChildren, options, indentLevel);
          return `*${aggressiveTrim(contentString)}*`;
        },
        strikethrough: (node, options, renderChildren, indentLevel) => {
          const contentString = processNodeContent(node.content, renderChildren, options, indentLevel);
          return `~~${aggressiveTrim(contentString)}~~`;
        },
        link: (node, options, renderChildren, indentLevel) => {
          const linkNode = node;
          const contentString = processNodeContent(linkNode.content, renderChildren, options, indentLevel);
          const trimmedLinkContent = aggressiveTrim(contentString);
          const href = linkNode.href ? encodeURI(linkNode.href) : "";
          if (trimmedLinkContent && (Array.isArray(linkNode.content) && linkNode.content.length === 1 && linkNode.content[0].type === "text" && linkNode.content[0].content === trimmedLinkContent || typeof linkNode.content === "string" && linkNode.content === trimmedLinkContent || !Array.isArray(linkNode.content) && !trimmedLinkContent.includes("<") && !trimmedLinkContent.includes("\n"))) {
            return `[${trimmedLinkContent}](${href})`;
          }
          return `<a href="${href}">${trimmedLinkContent}</a>`;
        },
        heading: (node, options, renderChildren, indentLevel) => {
          const headingNode = node;
          const contentString = processNodeContent(headingNode.content, renderChildren, options, indentLevel);
          return `${"#".repeat(headingNode.level)} ${contentString.trim()}

`;
        },
        image: (node) => {
          const imageNode = node;
          const altText = aggressiveTrim(imageNode.alt);
          const srcText = imageNode.src ? encodeURI(imageNode.src) : "";
          return `![${altText}](${srcText})
`;
        },
        list: (node, options, renderChildren, indentLevel) => {
          const listNode = node;
          let listString = "";
          const itemIndent = " ".repeat(indentLevel * 2);
          (listNode.items || []).forEach((item, i) => {
            if (!item || !item.content)
              return;
            const listItemPrefix = listNode.ordered ? `${i + 1}.` : "-";
            const itemContentString = renderChildren(item.content, options, indentLevel + 1).trim();
            listString += `${itemIndent}${listItemPrefix} ${itemContentString}
`;
          });
          return listString;
        },
        video: (node) => {
          const videoNode = node;
          let videoString = "";
          const videoSrc = videoNode.src ? encodeURI(videoNode.src) : "";
          videoString += `
![Video](${videoSrc})
`;
          if (videoNode.poster) {
            const posterSrc = typeof videoNode.poster === "string" ? encodeURI(videoNode.poster) : "";
            videoString += `![Poster](${posterSrc})
`;
          }
          if (videoNode.controls !== void 0) {
            videoString += `Controls: ${videoNode.controls}
`;
          }
          return videoString;
        },
        table: (node, options, renderChildren, indentLevel) => {
          const tableNode = node;
          const rows = tableNode.rows || [];
          if (rows.length === 0)
            return "";
          const maxColumns = Math.max(0, ...rows.map((row) => (row.cells || []).reduce((sum, cell) => sum + Math.max(1, cell?.colspan || 1), 0)));
          if (maxColumns === 0)
            return "";
          let tableString = "";
          rows.forEach((row, rowIndex) => {
            if (!row || !row.cells)
              return;
            let currentColumn = 0;
            let rowString = "";
            row.cells.forEach((cell) => {
              if (!cell)
                return;
              let cellContent = processNodeContent(cell.content, renderChildren, options, indentLevel + 1).trim();
              cellContent = cellContent.replace(/\|/g, "\\|");
              if (cell.colId)
                cellContent += ` <!-- ${cell.colId} -->`;
              const colspan = Math.max(1, cell.colspan || 1);
              const rowspan = Math.max(1, cell.rowspan || 1);
              if (colspan > 1)
                cellContent += ` <!-- colspan: ${colspan} -->`;
              if (rowspan > 1)
                cellContent += ` <!-- rowspan: ${rowspan} -->`;
              rowString += `| ${cellContent} `;
              currentColumn += colspan;
              for (let i = 1; i < colspan; i++) {
                rowString += "| ";
              }
            });
            while (currentColumn < maxColumns) {
              rowString += "|  ";
              currentColumn++;
            }
            tableString += rowString + "|\n";
          });
          return tableString;
        },
        code: (node) => {
          const codeNode = node;
          const codeContent = codeNode.content || "";
          if (codeNode.inline) {
            return `\`${codeContent}\``;
          } else {
            return `\`\`\`${codeNode.language || ""}
${codeContent}
\`\`\`
`;
          }
        },
        blockquote: (node, options, renderChildren, indentLevel) => {
          const rawBqContent = renderChildren(node.content, options, indentLevel);
          const processedBqContent = rawBqContent.trim().split("\n").map((line) => `> ${line.trim()}`).join("\n");
          if (processedBqContent.length > 0 && processedBqContent !== ">") {
            return processedBqContent + "\n";
          }
          return "> \n";
        },
        semanticHtml: (node, options, renderChildren, indentLevel) => {
          const htmlNode = node;
          const contentString = renderChildren(htmlNode.content, options, indentLevel);
          switch (htmlNode.htmlType) {
            case "article":
              return contentString;
            case "section":
              return `---

${contentString}

---
`;
            case "summary":
            case "time":
            case "aside":
            case "nav":
            case "figcaption":
            case "main":
            case "mark":
            case "header":
            case "footer":
            case "details":
            case "figure":
              return `<!-- <${htmlNode.htmlType}> -->
${contentString}
<!-- </${htmlNode.htmlType}> -->
`;
            default:
              return void 0;
          }
        }
        // 'meta' is handled by markdownMetaASTToString, not here.
        // 'custom' is handled by options.renderCustomNode in the main loop.
      };
      var INLINE_NODE_TYPES = /* @__PURE__ */ new Set(["text", "bold", "italic", "strikethrough", "link", "code"]);
      var BLOCK_NODE_TYPES = /* @__PURE__ */ new Set(["heading", "image", "list", "video", "table", "code", "blockquote", "semanticHtml"]);
      function markdownContentASTToStringRecursive(nodes, options, indentLevel = 0) {
        let markdownString = "";
        const renderChildren = (childNodes, childOptions = options, childIndent = indentLevel) => {
          if (typeof childNodes === "string")
            return childNodes;
          if (!childNodes || childNodes.length === 0)
            return "";
          return markdownContentASTToStringRecursive(childNodes, childOptions, childIndent);
        };
        nodes.forEach((node, index) => {
          if (node.type === "meta")
            return;
          const nodeRenderingOverride = options?.overrideNodeRenderer?.(node, options, indentLevel);
          if (nodeRenderingOverride !== void 0) {
            markdownString += nodeRenderingOverride;
            return;
          }
          let renderedNodeString;
          if (nodeRenderers[node.type]) {
            renderedNodeString = nodeRenderers[node.type]?.(node, options, renderChildren, indentLevel);
          } else if (node.type === "custom" && options?.renderCustomNode) {
            renderedNodeString = options.renderCustomNode(node, options, indentLevel);
          } else {
            console.warn(`Unhandled Markdown AST node type: ${node.type}`);
            renderedNodeString = "";
          }
          if (renderedNodeString === void 0 || renderedNodeString === null) {
            renderedNodeString = "";
          }
          const isCurrentNodeInline = INLINE_NODE_TYPES.has(node.type) && !(node.type === "code" && !node.inline);
          const isCurrentNodeBlock = BLOCK_NODE_TYPES.has(node.type) && !(node.type === "code" && node.inline);
          if (isCurrentNodeInline) {
            let addSpaceBeforeCurrentNode = false;
            if (markdownString.length > 0 && renderedNodeString.length > 0) {
              const lastCharOfPrevOutput = markdownString.slice(-1);
              const firstCharOfCurrentRenderedNode = renderedNodeString.charAt(0);
              const prevEndsWithSpace = /\s/.test(lastCharOfPrevOutput);
              const currentStartsWithSpace = /\s/.test(firstCharOfCurrentRenderedNode);
              const currentStartsWithClingingPunctuation = /^[.,!?;:)]/.test(firstCharOfCurrentRenderedNode);
              const prevEndsWithOpeningBracket = /[([]$/.test(lastCharOfPrevOutput);
              if (!prevEndsWithSpace && !currentStartsWithSpace && !currentStartsWithClingingPunctuation && !prevEndsWithOpeningBracket) {
                addSpaceBeforeCurrentNode = true;
              }
            }
            if (addSpaceBeforeCurrentNode) {
              markdownString += " ";
            }
            markdownString += renderedNodeString;
          } else if (isCurrentNodeBlock) {
            if (markdownString.length > 0 && !markdownString.endsWith("\n")) {
              markdownString += "\n";
            }
            if (renderedNodeString.length > 0 && markdownString.length > 0 && !markdownString.endsWith("\n\n") && !renderedNodeString.startsWith("\n")) {
              if (!markdownString.endsWith("\n"))
                markdownString += "\n";
            }
            markdownString += renderedNodeString;
            if (renderedNodeString.length > 0 && index < nodes.length - 1) {
              const nextNode = nodes[index + 1];
              const isNextNodeBlock = BLOCK_NODE_TYPES.has(nextNode.type) && !(nextNode.type === "code" && nextNode.inline);
              if (isNextNodeBlock || nextNode.type === "code" && !nextNode.inline) {
                if (!renderedNodeString.endsWith("\n\n")) {
                  if (!renderedNodeString.endsWith("\n")) {
                    markdownString += "\n\n";
                  } else {
                    markdownString += "\n";
                  }
                }
              } else if (!renderedNodeString.endsWith("\n")) {
                markdownString += "\n";
              }
            }
          } else {
            markdownString += renderedNodeString;
          }
        });
        return markdownString;
      }
      function markdownASTToString(nodes, options, indentLevel = 0) {
        if (!Array.isArray(nodes)) {
          console.warn("markdownASTToString received non-array input for nodes:", nodes);
          return "";
        }
        const metaOutput = markdownMetaASTToString(nodes, options);
        const contentOutput = markdownContentASTToStringRecursive(nodes, options, indentLevel);
        if (!metaOutput && !contentOutput) {
          return "";
        }
        if (contentOutput) {
          return (metaOutput + contentOutput).trimEnd();
        } else {
          return metaOutput;
        }
      }
    }
  });

  // ../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/domUtils.js
  var require_domUtils = __commonJS({
    "../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/domUtils.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.findMainContent = findMainContent;
      exports.wrapMainContent = wrapMainContent;
      exports.calculateScore = calculateScore;
      var enableDebug = false;
      var debugMessage = (message) => {
        if (enableDebug) {
          console.log(message);
        }
      };
      function findMainContent(document2) {
        debugMessage("Entering findMainContent function");
        const mainElement = document2.querySelector("main") || document2.querySelector('[role="main"]');
        if (mainElement) {
          debugMessage("Existing <main> element found");
          return mainElement;
        }
        debugMessage("No <main> element found. Detecting main content.");
        if (!document2.body) {
          debugMessage("No body element found, returning document.documentElement");
          return document2.documentElement;
        }
        return detectMainContent(document2.body);
      }
      function wrapMainContent(mainContentElement, document2) {
        if (mainContentElement.tagName.toLowerCase() !== "main") {
          debugMessage("Wrapping main content in <main> element");
          const mainElement = document2.createElement("main");
          mainContentElement.before(mainElement);
          mainElement.appendChild(mainContentElement);
          mainElement.id = "detected-main-content";
          debugMessage("Main content wrapped successfully");
        } else {
          debugMessage("Main content already wrapped");
        }
      }
      function detectMainContent(rootElement) {
        const candidates = [];
        const minScore = 20;
        debugMessage(`Collecting candidates with minimum score: ${minScore}`);
        collectCandidates(rootElement, candidates, minScore);
        debugMessage(`Total candidates found: ${candidates.length}`);
        if (candidates.length === 0) {
          debugMessage("No suitable candidates found, returning root element");
          return rootElement;
        }
        candidates.sort((a, b) => calculateScore(b) - calculateScore(a));
        debugMessage("Candidates sorted by score");
        let bestIndependentCandidate = candidates[0];
        for (let i = 1; i < candidates.length; i++) {
          if (!candidates.some((otherCandidate, j) => j !== i && otherCandidate.contains(candidates[i]))) {
            if (calculateScore(candidates[i]) > calculateScore(bestIndependentCandidate)) {
              bestIndependentCandidate = candidates[i];
              debugMessage(`New best independent candidate found: ${elementToString(bestIndependentCandidate)}`);
            }
          }
        }
        debugMessage(`Final main content candidate: ${elementToString(bestIndependentCandidate)}`);
        return bestIndependentCandidate;
      }
      function elementToString(element) {
        if (!element) {
          return "No element";
        }
        return `${element.tagName}#${element.id || "no-id"}.${Array.from(element.classList).join(".")}`;
      }
      function collectCandidates(element, candidates, minScore) {
        const score = calculateScore(element);
        if (score >= minScore) {
          candidates.push(element);
          debugMessage(`Candidate found: ${elementToString(element)}, score: ${score}`);
        }
        Array.from(element.children).forEach((child) => {
          collectCandidates(child, candidates, minScore);
        });
      }
      function calculateScore(element) {
        let score = 0;
        let scoreLog = [];
        const highImpactAttributes = ["article", "content", "main-container", "main", "main-content"];
        highImpactAttributes.forEach((attr) => {
          if (element.classList.contains(attr) || element.id === attr) {
            score += 10;
            scoreLog.push(`High impact attribute found: [${attr}] [${[...element.classList.values()].join(",")}], score increased by 10`);
          }
        });
        const highImpactTags = ["article", "main", "section"];
        if (highImpactTags.includes(element.tagName.toLowerCase())) {
          score += 5;
          scoreLog.push(`High impact tag found: [${element.tagName}], score increased by 5`);
        }
        const paragraphCount = element.getElementsByTagName("p").length;
        const paragraphScore = Math.min(paragraphCount, 5);
        if (paragraphScore > 0) {
          score += paragraphScore;
          scoreLog.push(`Paragraph count: ${paragraphCount}, score increased by ${paragraphScore}`);
        }
        const textContentLength = element.textContent?.trim().length || 0;
        if (textContentLength > 200) {
          const textScore = Math.min(Math.floor(textContentLength / 200), 5);
          score += textScore;
          scoreLog.push(`Text content length: ${textContentLength}, score increased by ${textScore}`);
        }
        const linkDensity = calculateLinkDensity(element);
        if (linkDensity < 0.3) {
          score += 5;
          scoreLog.push(`Link density: ${linkDensity.toFixed(2)}, score increased by 5`);
        }
        if (element.hasAttribute("data-main") || element.hasAttribute("data-content")) {
          score += 10;
          scoreLog.push("Data attribute for main content found, score increased by 10");
        }
        if (element.getAttribute("role")?.includes("main")) {
          score += 10;
          scoreLog.push("Role attribute indicating main content found, score increased by 10");
        }
        if (scoreLog.length > 0) {
          debugMessage(`Scoring for ${elementToString(element)}:`);
          scoreLog.forEach((log) => debugMessage("  " + log));
          debugMessage(`  Final score: ${score}`);
        }
        return score;
      }
      function calculateLinkDensity(element) {
        const linkLength = Array.from(element.getElementsByTagName("a")).reduce((sum, link) => sum + (link.textContent?.length || 0), 0);
        const textLength = element.textContent?.length || 1;
        return linkLength / textLength;
      }
    }
  });

  // ../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/urlUtils.js
  var require_urlUtils = __commonJS({
    "../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/urlUtils.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.refifyUrls = refifyUrls;
      var mediaSuffixes = [
        "jpeg",
        "jpg",
        "png",
        "gif",
        "bmp",
        "tiff",
        "tif",
        "svg",
        "webp",
        "ico",
        "avi",
        "mov",
        "mp4",
        "mkv",
        "flv",
        "wmv",
        "webm",
        "mpeg",
        "mpg",
        "mp3",
        "wav",
        "aac",
        "ogg",
        "flac",
        "m4a",
        "pdf",
        "doc",
        "docx",
        "ppt",
        "pptx",
        "xls",
        "xlsx",
        "txt",
        "css",
        "js",
        "xml",
        "json",
        "html",
        "htm"
      ];
      var addRefPrefix = (prefix, prefixesToRefs) => {
        if (!prefixesToRefs[prefix]) {
          prefixesToRefs[prefix] = "ref" + Object.values(prefixesToRefs).length;
        }
        return prefixesToRefs[prefix];
      };
      var processUrl = (url, prefixesToRefs) => {
        if (!url.startsWith("http")) {
          return url;
        } else {
          const mediaSuffix = url.split(".").slice(-1)[0];
          if (mediaSuffix && mediaSuffixes.includes(mediaSuffix)) {
            const parts = url.split("/");
            const prefix = parts.slice(0, -1).join("/");
            const refPrefix = addRefPrefix(prefix, prefixesToRefs);
            return `${refPrefix}://${parts.slice(-1).join("")}`;
          } else {
            if (url.split("/").length > 4) {
              return addRefPrefix(url, prefixesToRefs);
            } else {
              return url;
            }
          }
        }
      };
      function refifyUrls(markdownElement, prefixesToRefs = {}) {
        if (Array.isArray(markdownElement)) {
          markdownElement.forEach((element) => refifyUrls(element, prefixesToRefs));
        } else {
          switch (markdownElement.type) {
            case "link":
              markdownElement.href = processUrl(markdownElement.href, prefixesToRefs);
              refifyUrls(markdownElement.content, prefixesToRefs);
              break;
            case "image":
            case "video":
              markdownElement.src = processUrl(markdownElement.src, prefixesToRefs);
              break;
            case "list":
              markdownElement.items.forEach((item) => item.content.forEach((_) => refifyUrls(_, prefixesToRefs)));
              break;
            case "table":
              markdownElement.rows.forEach((row) => row.cells.forEach((cell) => typeof cell.content === "string" ? null : refifyUrls(cell.content, prefixesToRefs)));
              break;
            case "blockquote":
            case "semanticHtml":
              refifyUrls(markdownElement.content, prefixesToRefs);
              break;
          }
        }
        return prefixesToRefs;
      }
    }
  });

  // ../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/astUtils.js
  var require_astUtils = __commonJS({
    "../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/core/astUtils.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.isNot = exports.getMainContent = void 0;
      exports.findInAST = findInAST;
      exports.findAllInAST = findAllInAST;
      var getMainContent = (markdownStr) => {
        if (markdownStr.includes("<-main->")) {
          const regex = /(?<=<-main->)[\s\S]*?(?=<\/-main->)/;
          const match = markdownStr.match(regex);
          return match?.[0] ?? "";
        } else {
          const removeSectionsRegex = /(<-nav->[\s\S]*?<\/-nav->)|(<-footer->[\s\S]*?<\/-footer->)|(<-header->[\s\S]*?<\/-header->)|(<-aside->[\s\S]*?<\/-aside->)/g;
          return markdownStr.replace(removeSectionsRegex, "");
        }
      };
      exports.getMainContent = getMainContent;
      var isNot = (tPred) => (t) => !tPred(t);
      exports.isNot = isNot;
      var isString = (x) => typeof x === "string";
      function findInAST(markdownElement, checker) {
        const loopCheck = (z) => {
          for (const element of z) {
            const found = findInAST(element, checker);
            if (found) {
              return found;
            }
          }
          return void 0;
        };
        if (Array.isArray(markdownElement)) {
          return loopCheck(markdownElement);
        } else {
          if (checker(markdownElement)) {
            return markdownElement;
          }
          switch (markdownElement.type) {
            case "link":
              return loopCheck(markdownElement.content);
            case "list":
              return loopCheck(markdownElement.items.map((_) => _.content).flat());
            case "table":
              return loopCheck(markdownElement.rows.map((row) => row.cells.map((_) => _.content).filter((0, exports.isNot)(isString))).flat());
            case "blockquote":
            case "semanticHtml":
              return loopCheck(markdownElement.content);
          }
          return void 0;
        }
      }
      function findAllInAST(markdownElement, checker) {
        const loopCheck = (z) => {
          let out = [];
          for (const element of z) {
            const found = findAllInAST(element, checker);
            out = [...out, ...found];
          }
          return out;
        };
        if (Array.isArray(markdownElement)) {
          return loopCheck(markdownElement);
        } else {
          if (checker(markdownElement)) {
            return [markdownElement];
          }
          switch (markdownElement.type) {
            case "link":
              return loopCheck(markdownElement.content);
            case "list":
              return loopCheck(markdownElement.items.map((_) => _.content).flat());
            case "table":
              return loopCheck(markdownElement.rows.map((row) => row.cells.map((_) => _.content).filter((0, exports.isNot)(isString))).flat());
            case "blockquote":
            case "semanticHtml":
              return loopCheck(markdownElement.content);
          }
          return [];
        }
      }
    }
  });

  // ../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/index.js
  var require_node = __commonJS({
    "../../node_modules/.pnpm/dom-to-semantic-markdown@1.5.0/node_modules/dom-to-semantic-markdown/dist/node/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.wrapMainContent = exports.refifyUrls = exports.findMainContent = exports.markdownASTToString = exports.htmlToMarkdownAST = void 0;
      exports.convertHtmlToMarkdown = convertHtmlToMarkdown;
      exports.convertElementToMarkdown = convertElementToMarkdown;
      exports.findInMarkdownAST = findInMarkdownAST;
      exports.findAllInMarkdownAST = findAllInMarkdownAST;
      var htmlToMarkdownAST_1 = require_htmlToMarkdownAST();
      Object.defineProperty(exports, "htmlToMarkdownAST", { enumerable: true, get: function() {
        return htmlToMarkdownAST_1.htmlToMarkdownAST;
      } });
      var markdownASTToString_1 = require_markdownASTToString();
      Object.defineProperty(exports, "markdownASTToString", { enumerable: true, get: function() {
        return markdownASTToString_1.markdownASTToString;
      } });
      var domUtils_1 = require_domUtils();
      Object.defineProperty(exports, "findMainContent", { enumerable: true, get: function() {
        return domUtils_1.findMainContent;
      } });
      Object.defineProperty(exports, "wrapMainContent", { enumerable: true, get: function() {
        return domUtils_1.wrapMainContent;
      } });
      var urlUtils_1 = require_urlUtils();
      Object.defineProperty(exports, "refifyUrls", { enumerable: true, get: function() {
        return urlUtils_1.refifyUrls;
      } });
      var astUtils_1 = require_astUtils();
      function convertHtmlToMarkdown(html, options) {
        const parser = options?.overrideDOMParser ?? (typeof DOMParser !== "undefined" ? new DOMParser() : null);
        if (!parser) {
          throw new Error("DOMParser is not available. Please provide an overrideDOMParser in options.");
        }
        const doc = parser.parseFromString(html, "text/html");
        let element;
        if (options?.extractMainContent) {
          element = (0, domUtils_1.findMainContent)(doc);
          if (options.includeMetaData && !!doc.querySelector("head")?.innerHTML && !element.querySelector("head")) {
            element = parser.parseFromString(`<html>${doc.head.outerHTML}${element.outerHTML}`, "text/html").documentElement;
          }
        } else {
          if (options?.includeMetaData && !!doc.querySelector("head")?.innerHTML) {
            element = doc.documentElement;
          } else {
            element = doc.body || doc.documentElement;
          }
        }
        return convertElementToMarkdown(element, options);
      }
      function convertElementToMarkdown(element, options) {
        let ast = (0, htmlToMarkdownAST_1.htmlToMarkdownAST)(element, options);
        if (options?.refifyUrls) {
          options.urlMap = (0, urlUtils_1.refifyUrls)(ast);
        }
        return (0, markdownASTToString_1.markdownASTToString)(ast, options);
      }
      function findInMarkdownAST(ast, predicate) {
        return (0, astUtils_1.findInAST)(ast, predicate);
      }
      function findAllInMarkdownAST(ast, predicate) {
        return (0, astUtils_1.findAllInAST)(ast, predicate);
      }
    }
  });

  // src/content/capture/TriggerManager.ts
  function copyUsingExecCommand(document2, text) {
    const textarea = document2.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "true");
    Object.assign(textarea.style, {
      position: "fixed",
      top: "-9999px",
      left: "-9999px"
    });
    document2.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    const copied = document2.execCommand?.("copy") ?? false;
    textarea.remove();
    return copied;
  }
  async function copyWithClipboardApi(text) {
    if (!navigator.clipboard?.writeText) {
      return false;
    }
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      return false;
    }
  }
  var TriggerManager = class {
    constructor(session, browserCapture, regionHighlighter, snapshotIndicator, onSelectionStateChange) {
      this.session = session;
      this.browserCapture = browserCapture;
      this.regionHighlighter = regionHighlighter;
      this.snapshotIndicator = snapshotIndicator;
      this.onSelectionStateChange = onSelectionStateChange;
      this.regionHighlighter.setSelectionHandler((target, element) => {
        this.selectedTarget = target ? this.session.refineSelectionTarget(target) : null;
        this.browserCapture.setSelectedElement(element);
        const state = this.getSelectionState();
        const capture = this.selectedTarget ? this.session.captureSnapshot(this.browserCapture.buildResolveFocusInput("sidepanel")) : void 0;
        this.onSelectionStateChange?.(state, capture);
      });
      this.sessionDocument.addEventListener("keydown", this.handleKeydown, true);
    }
    selectionModeEnabled = false;
    selectedTarget = null;
    async captureSnapshot(source) {
      const result = this.session.captureSnapshot(this.browserCapture.buildResolveFocusInput(source));
      if (!result.snapshot) {
        return result;
      }
      const copied = await this.copySnapshot(result.snapshot);
      this.snapshotIndicator.showCapture(
        this.session.getRegionElement(result.snapshot.focus.region),
        this.session.getRegionCategory(result.snapshot.focus.region),
        copied
      );
      return result;
    }
    toggleSelectionMode() {
      this.selectionModeEnabled = this.regionHighlighter.toggle();
      if (!this.selectionModeEnabled) {
        this.selectedTarget = null;
        this.browserCapture.clearSelectedElement();
      }
      const state = {
        enabled: this.selectionModeEnabled,
        selectedTarget: this.selectedTarget
      };
      this.onSelectionStateChange?.(state);
      return state;
    }
    getSelectionState() {
      return {
        enabled: this.selectionModeEnabled,
        selectedTarget: this.selectedTarget
      };
    }
    clearSelection() {
      this.selectedTarget = null;
      this.browserCapture.clearSelectedElement();
      this.regionHighlighter.clearSelection();
      const state = {
        enabled: this.selectionModeEnabled,
        selectedTarget: null
      };
      this.onSelectionStateChange?.(state);
      return state;
    }
    dispose() {
      this.sessionDocument.removeEventListener("keydown", this.handleKeydown, true);
      this.browserCapture.dispose();
      this.regionHighlighter.dispose();
      this.snapshotIndicator.dispose();
    }
    get sessionDocument() {
      return document;
    }
    async copySnapshot(snapshot) {
      const json = JSON.stringify(snapshot, null, 2);
      if (copyUsingExecCommand(document, json)) {
        return true;
      }
      return copyWithClipboardApi(json);
    }
    handleKeydown = (event) => {
      if (!event.altKey || !event.shiftKey || event.metaKey || event.ctrlKey) {
        return;
      }
      if (event.key.toLowerCase() !== "d") {
        return;
      }
      event.preventDefault();
      this.dumpObservability();
    };
    dumpObservability() {
      const dump2 = this.session.dumpObservability();
      if (!dump2) {
        console.warn("[ThreadAtlas] Region dump unavailable on this page.");
        this.snapshotIndicator.showMessage("Region dump unavailable");
        return;
      }
      console.groupCollapsed(`[ThreadAtlas] RegionDump ${dump2.url}`);
      console.table(
        dump2.regions.map((region) => ({
          id: region.id,
          primitive: region.primitive,
          subtype: region.subtype ?? "",
          layoutRole: region.layoutRole,
          roleRank: region.roleRank,
          autoSuppressed: region.autoSuppressed,
          nodeCount: region.nodeCount,
          textLength: region.textLength,
          confidence: region.confidence
        }))
      );
      console.log("decisions", dump2.decisions);
      console.log("dump", dump2);
      console.groupEnd();
      this.snapshotIndicator.showMessage("Region dump logged to console");
    }
  };

  // src/content/capture/BrowserCapture.ts
  var BrowserCapture = class {
    constructor(document2, window2) {
      this.document = document2;
      this.window = window2;
    }
    lastHoveredElement = null;
    contextMenuTarget = null;
    selectedElement = null;
    initialize() {
      this.document.addEventListener("mousemove", this.handleMouseMove, { passive: true });
      this.document.addEventListener("contextmenu", this.handleContextMenu);
    }
    dispose() {
      this.document.removeEventListener("mousemove", this.handleMouseMove);
      this.document.removeEventListener("contextmenu", this.handleContextMenu);
    }
    setSelectedElement(element) {
      this.selectedElement = element;
    }
    clearSelectedElement() {
      this.selectedElement = null;
    }
    buildResolveFocusInput(source) {
      return {
        source,
        activeElement: this.selectedElement ?? this.document.activeElement,
        selection: this.window.getSelection(),
        triggerTarget: source === "context-menu" ? this.contextMenuTarget ?? this.selectedElement ?? this.lastHoveredElement ?? this.document.activeElement : this.selectedElement ?? this.lastHoveredElement ?? this.document.activeElement,
        selectedElement: this.selectedElement,
        lastHoveredElement: this.lastHoveredElement
      };
    }
    handleMouseMove = (event) => {
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      this.lastHoveredElement = target;
    };
    handleContextMenu = (event) => {
      const target = event.target;
      this.contextMenuTarget = target instanceof Element ? target : null;
    };
  };

  // src/content/semantic/text.ts
  var BLOCK_TAGS = /* @__PURE__ */ new Set([
    "ARTICLE",
    "ASIDE",
    "BLOCKQUOTE",
    "BR",
    "CODE",
    "DIV",
    "FIGCAPTION",
    "FIGURE",
    "FOOTER",
    "H1",
    "H2",
    "H3",
    "H4",
    "H5",
    "H6",
    "HEADER",
    "LI",
    "MAIN",
    "NAV",
    "OL",
    "P",
    "PRE",
    "SECTION",
    "TABLE",
    "TD",
    "TH",
    "TR",
    "UL"
  ]);
  function collapseWhitespace(value) {
    return value.replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ");
  }
  function normalizeText(value, options = {}) {
    const { preserveLineBreaks = false } = options;
    const collapsed = preserveLineBreaks ? collapseWhitespace(value).replace(/[ \t]*\n[ \t]*/g, "\n").replace(/\n{3,}/g, "\n\n") : collapseWhitespace(value).replace(/\s+/g, " ");
    return collapsed.trim();
  }
  function extractReadableText(root, options = {}) {
    const chunks = [];
    const walk = (node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const value = node.textContent ?? "";
        if (value.trim()) {
          chunks.push(value);
        }
        return;
      }
      if (!(node instanceof root.ownerDocument.defaultView.Element)) {
        return;
      }
      if (node.tagName === "BR") {
        chunks.push("\n");
        return;
      }
      const isBlock = BLOCK_TAGS.has(node.tagName);
      if (isBlock && chunks.length > 0) {
        chunks.push("\n");
      }
      for (const child of node.childNodes) {
        walk(child);
      }
      if (isBlock) {
        chunks.push("\n");
      }
    };
    walk(root);
    return normalizeText(chunks.join(""), options);
  }

  // src/content/overlay/RegionHighlighter.ts
  function createBox(document2, style) {
    const element = document2.createElement("div");
    element.setAttribute("data-threadatlas-overlay", "true");
    document2.documentElement.appendChild(element);
    Object.assign(element.style, {
      position: "fixed",
      pointerEvents: "none",
      display: "none",
      transition: "all 0.05s linear"
    });
    Object.assign(element.style, style);
    return element;
  }
  function createLabel(document2, style) {
    return createBox(document2, {
      padding: "2px 6px",
      borderRadius: "999px",
      color: "#f8fafc",
      fontSize: "11px",
      fontFamily: "system-ui, sans-serif",
      lineHeight: "1.4",
      width: "auto",
      height: "auto",
      ...style
    });
  }
  function createOverlay(document2) {
    return {
      hoverCurrent: createBox(document2, {
        zIndex: "2147483647",
        border: "1px solid rgba(59, 130, 246, 0.5)",
        background: "rgba(59, 130, 246, 0.08)"
      }),
      hoverParent: createBox(document2, {
        zIndex: "2147483646",
        border: "1px solid rgba(34, 197, 94, 0.4)",
        background: "rgba(34, 197, 94, 0.06)"
      }),
      hoverLabel: createLabel(document2, {
        zIndex: "2147483647",
        background: "rgba(15, 23, 42, 0.82)"
      }),
      selectedCurrent: createBox(document2, {
        zIndex: "2147483645",
        border: "2px solid rgba(249, 115, 22, 0.9)",
        background: "rgba(249, 115, 22, 0.08)"
      }),
      selectedParent: createBox(document2, {
        zIndex: "2147483644",
        border: "1px solid rgba(245, 158, 11, 0.55)",
        background: "rgba(245, 158, 11, 0.06)"
      }),
      selectedLabel: createLabel(document2, {
        zIndex: "2147483645",
        background: "rgba(124, 45, 18, 0.92)"
      })
    };
  }
  function applyRect(element, rect) {
    if (rect.width <= 0 || rect.height <= 0) {
      element.style.display = "none";
      return;
    }
    element.style.display = "block";
    element.style.top = `${rect.top}px`;
    element.style.left = `${rect.left}px`;
    element.style.width = `${rect.width}px`;
    element.style.height = `${rect.height}px`;
  }
  function applyLabel(element, rect, text) {
    element.textContent = text;
    element.style.display = "block";
    element.style.top = `${Math.max(0, rect.top - 22)}px`;
    element.style.left = `${rect.left}px`;
  }
  function hideElements(elements) {
    for (const element of elements) {
      element.style.display = "none";
    }
  }
  function summarizeText(value) {
    return normalizeText(value).slice(0, 140);
  }
  function applySuppressedAppearance(handles, suppressed) {
    handles.hoverCurrent.style.opacity = suppressed ? "0.45" : "1";
    handles.hoverParent.style.opacity = suppressed ? "0.35" : "1";
    handles.hoverLabel.style.opacity = suppressed ? "0.7" : "1";
  }
  function resolveHighlightTarget(document2, leaf) {
    const currentElement = leaf?.closest("[data-semantic-node-id]");
    if (!currentElement) {
      return null;
    }
    const regionId = currentElement.getAttribute("data-semantic-region") ?? "semantic-region";
    const nodeId = currentElement.getAttribute("data-semantic-node-id");
    if (!nodeId) {
      return null;
    }
    const primitive = currentElement.getAttribute("data-semantic-primitive") ?? "authored-block";
    const scopeRootId = currentElement.getAttribute("data-semantic-scope-root-id");
    const parentElement = scopeRootId && scopeRootId !== nodeId ? document2.querySelector(
      `[data-semantic-region="${regionId}"][data-semantic-node-id="${scopeRootId}"]`
    ) : null;
    const selectionElement = primitive === "interactive-block" && parentElement ? parentElement : currentElement;
    const selectionNodeId = primitive === "interactive-block" && scopeRootId ? scopeRootId : nodeId;
    const displayLabel = selectionElement.getAttribute("data-semantic-display-label") ?? selectionElement.getAttribute("data-semantic-category") ?? "Semantic item";
    return {
      currentElement,
      currentKey: `${regionId}:${nodeId}`,
      parentElement,
      parentKey: parentElement?.getAttribute("data-semantic-node-id") ?? null,
      autoSuppressed: currentElement.getAttribute("data-semantic-auto-suppressed") === "true",
      selectionTarget: {
        regionId,
        primitive,
        category: selectionElement.getAttribute("data-semantic-category") ?? "content.article",
        nodeKind: selectionElement.getAttribute("data-semantic-node-kind") ?? "content",
        nodeId: selectionNodeId,
        rootNodeId: scopeRootId,
        scopeRootId,
        label: displayLabel,
        displayLabel,
        text: summarizeText(
          selectionElement.getAttribute("data-semantic-text-preview") ?? selectionElement.textContent ?? ""
        ),
        ...selectionElement.getAttribute("data-semantic-subtype") ? { subtype: selectionElement.getAttribute("data-semantic-subtype") } : {}
      }
    };
  }
  var RegionHighlighter = class {
    constructor(document2, window2) {
      this.document = document2;
      this.window = window2;
      this.overlays = createOverlay(document2);
    }
    overlays;
    enabled = false;
    pendingTimer = null;
    lastPoint = { x: 0, y: 0 };
    hasPointerPosition = false;
    lastCurrentKey = null;
    lastParentKey = null;
    selectedTarget = null;
    onSelect = null;
    setSelectionHandler(handler) {
      this.onSelect = handler;
    }
    enable() {
      if (this.enabled) {
        return this.enabled;
      }
      this.enabled = true;
      this.document.addEventListener("mousemove", this.handleMouseMove, { passive: true });
      this.document.addEventListener("click", this.handleClick, true);
      this.window.addEventListener("scroll", this.handleViewportChange, { passive: true, capture: true });
      this.window.addEventListener("resize", this.handleViewportChange);
      return this.enabled;
    }
    disable() {
      if (!this.enabled) {
        return this.enabled;
      }
      this.enabled = false;
      this.document.removeEventListener("mousemove", this.handleMouseMove);
      this.document.removeEventListener("click", this.handleClick, true);
      this.window.removeEventListener("scroll", this.handleViewportChange, true);
      this.window.removeEventListener("resize", this.handleViewportChange);
      this.clearSelection();
      this.hideHover();
      return this.enabled;
    }
    toggle() {
      return this.enabled ? this.disable() : this.enable();
    }
    isEnabled() {
      return this.enabled;
    }
    getSelectedTarget() {
      return this.selectedTarget?.selectionTarget ?? null;
    }
    clearSelection() {
      this.selectedTarget = null;
      hideElements([
        this.overlays.selectedCurrent,
        this.overlays.selectedParent,
        this.overlays.selectedLabel
      ]);
      this.onSelect?.(null, null);
    }
    dispose() {
      this.disable();
      for (const element of Object.values(this.overlays)) {
        element.remove();
      }
    }
    handleMouseMove = (event) => {
      if (!this.enabled) {
        return;
      }
      this.lastPoint = { x: event.clientX, y: event.clientY };
      this.hasPointerPosition = true;
      if (this.pendingTimer !== null) {
        return;
      }
      this.pendingTimer = this.window.setTimeout(() => {
        this.pendingTimer = null;
        this.updateHoverAtPoint(this.lastPoint.x, this.lastPoint.y);
      }, 50);
    };
    handleClick = (event) => {
      if (!this.enabled) {
        return;
      }
      const target = resolveHighlightTarget(this.document, event.target instanceof Element ? event.target : null);
      if (!target) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      this.selectedTarget = target;
      this.renderSelected(target);
      this.onSelect?.(target.selectionTarget, target.currentElement);
    };
    handleViewportChange = () => {
      if (!this.enabled) {
        return;
      }
      if (this.selectedTarget?.currentElement?.isConnected) {
        const refreshedSelection = resolveHighlightTarget(this.document, this.selectedTarget.currentElement);
        if (refreshedSelection) {
          this.selectedTarget = refreshedSelection;
          this.renderSelected(refreshedSelection);
        } else {
          this.clearSelection();
        }
      } else if (this.selectedTarget) {
        this.clearSelection();
      }
      if (this.hasPointerPosition) {
        this.updateHoverAtPoint(this.lastPoint.x, this.lastPoint.y, { force: true });
      }
    };
    updateHoverAtPoint(x, y, options = {}) {
      const leaf = this.document.elementFromPoint(x, y);
      const target = resolveHighlightTarget(this.document, leaf);
      if (!options.force && target?.currentKey === this.lastCurrentKey && target?.parentKey === this.lastParentKey) {
        return;
      }
      this.lastCurrentKey = target?.currentKey ?? null;
      this.lastParentKey = target?.parentKey ?? null;
      if (!target) {
        this.hideHover();
        return;
      }
      if (target.parentElement && target.parentKey !== target.currentKey) {
        applyRect(this.overlays.hoverParent, target.parentElement.getBoundingClientRect());
      } else {
        this.overlays.hoverParent.style.display = "none";
      }
      applySuppressedAppearance(this.overlays, target.autoSuppressed);
      const rect = target.currentElement.getBoundingClientRect();
      applyRect(this.overlays.hoverCurrent, rect);
      applyLabel(this.overlays.hoverLabel, rect, target.selectionTarget.displayLabel);
    }
    renderSelected(target) {
      applySuppressedAppearance(this.overlays, false);
      if (target.parentElement && target.parentKey !== target.currentKey) {
        applyRect(this.overlays.selectedParent, target.parentElement.getBoundingClientRect());
      } else {
        this.overlays.selectedParent.style.display = "none";
      }
      const rect = target.currentElement.getBoundingClientRect();
      applyRect(this.overlays.selectedCurrent, rect);
      applyLabel(this.overlays.selectedLabel, rect, `selected \xB7 ${target.selectionTarget.displayLabel}`);
    }
    hideHover() {
      this.lastCurrentKey = null;
      this.lastParentKey = null;
      hideElements([
        this.overlays.hoverCurrent,
        this.overlays.hoverParent,
        this.overlays.hoverLabel
      ]);
    }
  };

  // src/content/overlay/SnapshotIndicator.ts
  function ensureIndicatorElement(document2, id, styles) {
    const existing = document2.getElementById(id);
    if (existing) {
      return existing;
    }
    const element = document2.createElement("div");
    element.id = id;
    Object.assign(element.style, styles);
    document2.documentElement.appendChild(element);
    return element;
  }
  var SnapshotIndicator = class {
    constructor(document2, window2) {
      this.document = document2;
      this.window = window2;
      this.flashElement = ensureIndicatorElement(document2, "threadatlas-snapshot-flash", {
        position: "fixed",
        pointerEvents: "none",
        zIndex: "2147483647",
        borderRadius: "12px",
        border: "2px solid rgba(34, 197, 94, 0.95)",
        boxShadow: "0 0 0 8px rgba(34, 197, 94, 0.18)",
        opacity: "0",
        transition: "opacity 0.2s linear",
        display: "none"
      });
      this.toastElement = ensureIndicatorElement(document2, "threadatlas-snapshot-toast", {
        position: "fixed",
        top: "12px",
        right: "12px",
        pointerEvents: "none",
        zIndex: "2147483647",
        padding: "10px 12px",
        borderRadius: "10px",
        background: "rgba(15, 23, 42, 0.92)",
        color: "#f8fafc",
        fontFamily: "system-ui, sans-serif",
        fontSize: "12px",
        lineHeight: "1.5",
        opacity: "0",
        transition: "opacity 0.2s linear"
      });
    }
    flashElement;
    toastElement;
    hideTimer = null;
    showCapture(regionElement, category, copiedToClipboard) {
      if (regionElement) {
        const rect = regionElement.getBoundingClientRect();
        this.flashElement.style.display = "block";
        this.flashElement.style.top = `${rect.top}px`;
        this.flashElement.style.left = `${rect.left}px`;
        this.flashElement.style.width = `${rect.width}px`;
        this.flashElement.style.height = `${rect.height}px`;
        this.flashElement.style.opacity = "1";
        this.window.setTimeout(() => {
          this.flashElement.style.opacity = "0";
          this.window.setTimeout(() => {
            this.flashElement.style.display = "none";
          }, 200);
        }, 16);
      }
      this.toastElement.textContent = copiedToClipboard ? `Snapshot captured (${category ?? "semantic.region"}) and copied` : `Snapshot captured (${category ?? "semantic.region"})`;
      this.toastElement.style.opacity = "1";
      if (this.hideTimer !== null) {
        this.window.clearTimeout(this.hideTimer);
      }
      this.hideTimer = this.window.setTimeout(() => {
        this.toastElement.style.opacity = "0";
        this.hideTimer = null;
      }, 2e3);
    }
    showMessage(message) {
      this.toastElement.textContent = message;
      this.toastElement.style.opacity = "1";
      if (this.hideTimer !== null) {
        this.window.clearTimeout(this.hideTimer);
      }
      this.hideTimer = this.window.setTimeout(() => {
        this.toastElement.style.opacity = "0";
        this.hideTimer = null;
      }, 2e3);
    }
    dispose() {
      this.flashElement.remove();
      this.toastElement.remove();
      if (this.hideTimer !== null) {
        this.window.clearTimeout(this.hideTimer);
        this.hideTimer = null;
      }
    }
  };

  // src/common/semantic-url.ts
  function isSemanticCaptureSupportedUrl(url) {
    return /^https?:\/\//.test(url ?? "");
  }

  // src/content/semantic/context-slice.ts
  function isCommentNode(node) {
    return node.kind === "comment";
  }
  function isContentNode(node) {
    return node.kind === "content";
  }
  function buildNodeIndex(nodes) {
    return new Map(nodes.map((node) => [node.id, node]));
  }
  function buildChildIndex(nodes) {
    const index = /* @__PURE__ */ new Map();
    for (const node of nodes) {
      const { parentId } = node;
      if (!parentId) {
        continue;
      }
      index.set(parentId, [...index.get(parentId) ?? [], node]);
    }
    return index;
  }
  function findThreadRootId(focusNode, nodeIndex) {
    let currentNode = focusNode;
    while (currentNode.parentId) {
      const parent = nodeIndex.get(currentNode.parentId);
      if (!parent || !isCommentNode(parent)) {
        break;
      }
      currentNode = parent;
    }
    return currentNode.id;
  }
  function belongsToScope(node, rootId, nodeIndex) {
    let current = node;
    while (current) {
      if (current.id === rootId) {
        return true;
      }
      const parentId = current.parentId;
      current = parentId ? nodeIndex.get(parentId) : void 0;
    }
    return false;
  }
  function distanceToAncestor(node, ancestorId, nodeIndex) {
    let distance = 0;
    let current = node;
    while (current?.parentId) {
      distance += 1;
      if (current.parentId === ancestorId) {
        return distance;
      }
      current = nodeIndex.get(current.parentId);
    }
    return null;
  }
  function getContentScopeRoot(focusNode, region, nodeIndex) {
    if (isContentNode(focusNode) && focusNode.type === "heading") {
      return focusNode.id;
    }
    let currentParentId = focusNode.parentId;
    let nearestHeading = null;
    while (currentParentId) {
      const parent = nodeIndex.get(currentParentId);
      if (!parent) {
        break;
      }
      if (isContentNode(parent) && parent.type === "heading") {
        nearestHeading = parent;
        break;
      }
      currentParentId = parent.parentId;
    }
    if (nearestHeading) {
      return nearestHeading.id;
    }
    let current = focusNode;
    while (current.parentId) {
      const parent = nodeIndex.get(current.parentId);
      if (!parent) {
        break;
      }
      current = parent;
    }
    if (current.id !== focusNode.id) {
      return current.id;
    }
    return region.structure?.rootIds?.[0] ?? focusNode.id;
  }
  function buildAncestorSlices(focusNode, rootId, nodeIndex) {
    const slices = [];
    let distance = 1;
    let parentId = focusNode.parentId;
    while (parentId) {
      const parent = nodeIndex.get(parentId);
      if (!parent || !belongsToScope(parent, rootId, nodeIndex)) {
        break;
      }
      slices.push({
        relation: distance === 1 ? "parent" : "ancestor",
        node: parent,
        distance
      });
      distance += 1;
      parentId = parent.parentId;
    }
    return slices;
  }
  function buildDescendantSlices(focusNode, rootId, nodes, nodeIndex) {
    return nodes.filter((node) => node.id !== focusNode.id && belongsToScope(node, rootId, nodeIndex)).flatMap((node) => {
      const distance = distanceToAncestor(node, focusNode.id, nodeIndex);
      if (distance === null) {
        return [];
      }
      return [{
        relation: "child",
        node,
        distance
      }];
    });
  }
  function buildSiblingSlices(focusNode, rootId, nodes, nodeIndex) {
    const focusParentId = focusNode.parentId;
    return nodes.filter((node) => node.id !== focusNode.id && belongsToScope(node, rootId, nodeIndex)).filter((node) => node.parentId === focusParentId).map((node) => ({
      relation: "sibling",
      node,
      distance: 1
    }));
  }
  function buildCommentContext(focusRegion, focusNode) {
    const nodes = focusRegion.nodes.filter(isCommentNode);
    const nodeIndex = buildNodeIndex(nodes);
    const rootId = findThreadRootId(focusNode, nodeIndex);
    return [
      ...buildAncestorSlices(focusNode, rootId, nodeIndex),
      ...buildDescendantSlices(focusNode, rootId, nodes, nodeIndex),
      ...buildSiblingSlices(focusNode, rootId, nodes, nodeIndex)
    ];
  }
  function buildContentContext(focusRegion, focusNode) {
    const nodes = focusRegion.nodes;
    const nodeIndex = buildNodeIndex(nodes);
    const childIndex = buildChildIndex(nodes);
    const rootId = getContentScopeRoot(focusNode, focusRegion, nodeIndex);
    const scopeNodes = nodes.filter((node) => belongsToScope(node, rootId, nodeIndex));
    const ancestors = buildAncestorSlices(focusNode, rootId, nodeIndex);
    const isWholeRegionPeerScope = focusRegion.primitive === "repeated-item" && focusRegion.subtype !== "nested" || focusRegion.primitive === "navigation-cluster";
    if (isWholeRegionPeerScope) {
      return nodes.filter((node) => node.id !== focusNode.id).map((node) => ({
        relation: "sibling",
        node,
        distance: 1
      }));
    }
    if (isContentNode(focusNode) && focusNode.type === "heading") {
      return [
        ...ancestors,
        ...buildDescendantSlices(focusNode, rootId, scopeNodes, nodeIndex),
        ...buildSiblingSlices(focusNode, rootId, scopeNodes, nodeIndex)
      ];
    }
    if ((childIndex.get(focusNode.id) ?? []).length > 0) {
      return [
        ...ancestors,
        ...buildDescendantSlices(focusNode, rootId, scopeNodes, nodeIndex),
        ...buildSiblingSlices(focusNode, rootId, scopeNodes, nodeIndex)
      ];
    }
    return [
      ...ancestors,
      ...buildSiblingSlices(focusNode, rootId, scopeNodes, nodeIndex)
    ];
  }
  function buildCommentCoverage(focusRegion, focusNode, context) {
    const nodes = focusRegion.nodes.filter(isCommentNode);
    const nodeIndex = buildNodeIndex(nodes);
    const rootNodeId = findThreadRootId(focusNode, nodeIndex);
    const scopedNodes = nodes.filter((node) => belongsToScope(node, rootNodeId, nodeIndex));
    const includedNodeIds = /* @__PURE__ */ new Set([focusNode.id, ...context.map((slice) => slice.node.id)]);
    return {
      kind: "focus-branch",
      rootNodeId,
      capturedNodeCount: includedNodeIds.size,
      omittedNodeCount: scopedNodes.filter((node) => !includedNodeIds.has(node.id)).length,
      omittedRootCount: nodes.filter((node) => !node.parentId && node.id !== rootNodeId).length
    };
  }
  function buildGenericCoverage(focusRegion, focusNode, context) {
    if (focusRegion.primitive === "repeated-item" && focusRegion.subtype !== "nested" || focusRegion.primitive === "navigation-cluster") {
      const includedNodeIds2 = /* @__PURE__ */ new Set([focusNode.id, ...context.map((slice) => slice.node.id)]);
      return {
        kind: "focus-section",
        rootNodeId: `${focusRegion.id}-scope-root`,
        capturedNodeCount: includedNodeIds2.size,
        omittedNodeCount: focusRegion.nodes.filter((node) => !includedNodeIds2.has(node.id)).length,
        omittedRootCount: 0
      };
    }
    const nodeIndex = buildNodeIndex(focusRegion.nodes);
    const rootNodeId = getContentScopeRoot(focusNode, focusRegion, nodeIndex);
    const scopedNodes = focusRegion.nodes.filter((node) => belongsToScope(node, rootNodeId, nodeIndex));
    const includedNodeIds = /* @__PURE__ */ new Set([focusNode.id, ...context.map((slice) => slice.node.id)]);
    const rootIds = focusRegion.structure?.rootIds ?? [];
    const siblingRoots = rootIds.filter((id) => id !== rootNodeId);
    return {
      kind: "focus-section",
      rootNodeId,
      capturedNodeCount: includedNodeIds.size,
      omittedNodeCount: scopedNodes.filter((node) => !includedNodeIds.has(node.id)).length,
      omittedRootCount: siblingRoots.length
    };
  }
  function findRegionNode(region, nodeId) {
    return region?.nodes.find((node) => node.id === nodeId) ?? null;
  }
  function buildContextSlices(args) {
    const focusNode = findRegionNode(args.focusRegion, args.focusNodeId);
    if (!focusNode) {
      return [];
    }
    if (isCommentNode(focusNode)) {
      return buildCommentContext(args.focusRegion, focusNode);
    }
    return buildContentContext(args.focusRegion, focusNode);
  }
  function buildSemanticSnapshot(args) {
    const { page, focusRegion, focusNodeId, extractorId, skeletonVersion } = args;
    const focusNode = findRegionNode(focusRegion, focusNodeId);
    if (!focusNode) {
      return null;
    }
    const context = buildContextSlices({
      focusRegion,
      focusNodeId
    });
    const coverage = isCommentNode(focusNode) ? buildCommentCoverage(focusRegion, focusNode, context) : buildGenericCoverage(focusRegion, focusNode, context);
    return {
      page,
      focus: {
        nodeId: focusNodeId,
        node: focusNode,
        region: focusRegion.id
      },
      context,
      meta: {
        capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
        skeletonVersion,
        extractorId,
        coverage
      }
    };
  }

  // src/content/semantic/focus-resolver.ts
  var FocusResolver = class {
    resolve(extractor, document2, input) {
      return extractor.resolveFocus(document2, input);
    }
  };

  // src/content/semantic/docs-enhancer.ts
  function normalizeText2(value) {
    return (value ?? "").trim().replace(/\s+/g, " ").toLowerCase();
  }
  function isDocsPage(url, document2) {
    if (url.pathname.startsWith("/docs")) {
      return true;
    }
    return Boolean(
      document2.querySelector(".docs-layout, .docs-shell, nav[aria-label*='Docs'], nav[aria-label*='Guide']")
    );
  }
  function getDocsPageKind(url, document2) {
    const pathname = normalizeText2(url.pathname);
    const hasReferenceSignals = pathname.includes("/reference") || pathname.includes("/api") || Boolean(document2.querySelector("[data-docs-kind='reference'], .reference-layout"));
    if (hasReferenceSignals) {
      return "reference";
    }
    const isLandingPath = pathname === "/docs" || pathname === "/docs/" || pathname === "/docs/index";
    const hasLandingSignals = Boolean(document2.querySelector(".docs-card-grid, [data-docs-landing]"));
    if (isLandingPath || hasLandingSignals) {
      return "landing";
    }
    return "guide";
  }
  function getAnchorElement(region) {
    return region.anchor.deref?.() ?? null;
  }
  function isBreadcrumbLike(element, region) {
    const ariaLabel = normalizeText2(element.getAttribute("aria-label"));
    return region.subtype === "breadcrumb" || ariaLabel.includes("breadcrumb");
  }
  function isTableOfContentsLike(element) {
    const ariaLabel = normalizeText2(element.getAttribute("aria-label"));
    const semanticText = normalizeText2(
      `${element.getAttribute("class")} ${element.getAttribute("id")} ${element.textContent ?? ""}`
    );
    return ariaLabel.includes("table of contents") || ariaLabel === "toc" || semanticText.includes("table of contents") || semanticText.includes(" toc ");
  }
  function isRelatedLinksLike(element) {
    const ariaLabel = normalizeText2(element.getAttribute("aria-label"));
    return Boolean(element.closest("footer")) || ariaLabel.includes("footer") || ariaLabel.includes("related") || ariaLabel.includes("resources");
  }
  function labelDocsNavigation(element, region, pageKind) {
    if (isBreadcrumbLike(element, region)) {
      return "Breadcrumb";
    }
    if (isTableOfContentsLike(element)) {
      return "Table of contents";
    }
    if (element.closest("aside")) {
      if (pageKind === "reference") {
        return "Reference sections";
      }
      if (pageKind === "guide") {
        return "Guide sections";
      }
      return "Docs sidebar";
    }
    if (isRelatedLinksLike(element)) {
      return "Related links";
    }
    return null;
  }
  function regionLabelForElement(element, region, pageKind) {
    if (!element) {
      return null;
    }
    if (region.primitive === "navigation-cluster") {
      return labelDocsNavigation(element, region, pageKind);
    }
    if (region.primitive === "authored-block") {
      if (pageKind === "landing") {
        return "Documentation overview";
      }
      if (pageKind === "reference") {
        return "API reference";
      }
      return "Guide article";
    }
    if (region.primitive === "repeated-item" && region.subtype === "grid") {
      return pageKind === "reference" ? "Reference entries" : "Documentation cards";
    }
    if (region.primitive === "interactive-block" && region.subtype === "search") {
      return "Docs search";
    }
    return null;
  }
  function toRegionDescriptor(region) {
    return region.subtype ? { primitive: region.primitive, subtype: region.subtype } : { primitive: region.primitive };
  }
  function resolveDocsCategory(region) {
    if (region.primitive === "authored-block" || region.primitive === "repeated-item") {
      return "content.article";
    }
    if (region.primitive === "navigation-cluster" && region.subtype === "breadcrumb") {
      return "navigation.breadcrumb";
    }
    return region.category;
  }
  function mapSkeletonRegion(region, pageKind) {
    const anchor = getAnchorElement(region);
    const displayLabel = regionLabelForElement(anchor, toRegionDescriptor(region), pageKind);
    if (!displayLabel) {
      return region;
    }
    return {
      ...region,
      category: resolveDocsCategory(region),
      displayLabel
    };
  }
  function mapExpandedRegion(region, ctx, pageKind) {
    const anchor = ctx.document.querySelector(`[data-semantic-region="${region.id}"]`);
    const displayLabel = regionLabelForElement(anchor, toRegionDescriptor(region), pageKind);
    if (!displayLabel) {
      return region;
    }
    return {
      ...region,
      category: resolveDocsCategory(region),
      displayLabel
    };
  }
  function findSelectionElement(ctx, selection) {
    const candidateIds = [selection.nodeId, selection.scopeRootId, selection.rootNodeId].filter(
      (value) => Boolean(value)
    );
    for (const nodeId of candidateIds) {
      const element = ctx.document.querySelector(
        `[data-semantic-region="${selection.regionId}"][data-semantic-node-id="${nodeId}"]`
      );
      if (element) {
        return element;
      }
    }
    return ctx.document.querySelector(`[data-semantic-region="${selection.regionId}"]`);
  }
  function resolveSelectionScope(element, input) {
    if (input.primitive === "repeated-item" && input.nodeId) {
      return {
        rootNodeId: input.rootNodeId ?? input.nodeId,
        scopeRootId: input.scopeRootId ?? input.nodeId
      };
    }
    const scopeRootId = input.scopeRootId ?? element?.getAttribute("data-semantic-scope-root-id") ?? input.rootNodeId ?? input.nodeId;
    const rootNodeId = input.rootNodeId ?? scopeRootId ?? input.nodeId;
    return {
      rootNodeId,
      scopeRootId
    };
  }
  function resolveSelectionLabel(input, displayLabel, pageKind) {
    if (input.primitive === "repeated-item") {
      return pageKind === "reference" ? "Reference entry" : "Documentation card";
    }
    if (input.primitive === "authored-block") {
      if (pageKind === "reference") {
        return "Reference section";
      }
      if (pageKind === "landing") {
        return "Documentation section";
      }
      return "Guide section";
    }
    return displayLabel;
  }
  var DocsEnhancer = class {
    id = "docs";
    match(url, document2) {
      return isDocsPage(url, document2);
    }
    refineSkeleton(input, ctx) {
      const pageKind = getDocsPageKind(ctx.url, ctx.document);
      return {
        ...input,
        regions: input.regions.map((region) => mapSkeletonRegion(region, pageKind))
      };
    }
    refineRegion(input, ctx) {
      return mapExpandedRegion(input, ctx, getDocsPageKind(ctx.url, ctx.document));
    }
    refineSelection(input, ctx) {
      const element = findSelectionElement(ctx, input);
      const pageKind = getDocsPageKind(ctx.url, ctx.document);
      const displayLabel = regionLabelForElement(element, toRegionDescriptor(input), pageKind);
      if (!displayLabel) {
        return input;
      }
      const scope = resolveSelectionScope(element, input);
      const label = resolveSelectionLabel(input, displayLabel, pageKind);
      return {
        ...input,
        ...scope,
        category: resolveDocsCategory(input),
        label,
        displayLabel: label
      };
    }
  };

  // src/content/semantic/hacker-news-enhancer.ts
  function isHackerNewsItemUrl(url) {
    return url.hostname === "news.ycombinator.com" && url.pathname === "/item";
  }
  function findSelectedNodeElement(ctx, selection) {
    if (!selection.nodeId) {
      return null;
    }
    return ctx.document.querySelector(
      `[data-semantic-region="${selection.regionId}"][data-semantic-node-id="${selection.nodeId}"]`
    );
  }
  function findCommentAuthor(element) {
    if (!element) {
      return null;
    }
    const author = normalizeText(
      element.closest("tr")?.querySelector(".hnuser")?.textContent ?? element.querySelector(".hnuser")?.textContent ?? ""
    );
    return author || null;
  }
  var HackerNewsEnhancer = class {
    id = "hacker-news";
    match(url) {
      return isHackerNewsItemUrl(url);
    }
    refineSkeleton(input) {
      return {
        ...input,
        regions: input.regions.map((region) => {
          if (region.primitive === "repeated-item" && region.subtype === "nested") {
            return {
              ...region,
              category: "discussion.thread",
              displayLabel: "Thread branch"
            };
          }
          if (region.primitive === "authored-block") {
            return {
              ...region,
              category: "content.post",
              displayLabel: "Story"
            };
          }
          return region;
        })
      };
    }
    refineRegion(input) {
      if (input.primitive === "repeated-item" && input.subtype === "nested") {
        return {
          ...input,
          category: "discussion.thread",
          displayLabel: "Thread branch"
        };
      }
      if (input.primitive === "authored-block") {
        return {
          ...input,
          category: "content.post",
          displayLabel: "Story"
        };
      }
      return input;
    }
    refineSelection(input, ctx) {
      if (input.primitive === "repeated-item" && input.subtype === "nested") {
        const author = findCommentAuthor(findSelectedNodeElement(ctx, input));
        return {
          ...input,
          category: "discussion.comment",
          label: author ? `Comment by ${author}` : "Comment",
          displayLabel: author ? `Comment by ${author}` : "Comment"
        };
      }
      if (input.primitive === "authored-block") {
        return {
          ...input,
          category: "content.post",
          label: "Story",
          displayLabel: "Story"
        };
      }
      return input;
    }
  };

  // src/content/semantic/search-enhancer.ts
  function normalizeText3(value) {
    return (value ?? "").trim().replace(/\s+/g, " ").toLowerCase();
  }
  function isSearchPage(url, document2) {
    if (url.pathname.includes("search")) {
      return true;
    }
    return Boolean(document2.querySelector(".search-layout, .results-grid, [data-search-results]"));
  }
  function isDocsSearchPage(url, document2) {
    const pathname = normalizeText3(url.pathname);
    if (pathname.includes("/docs/search")) {
      return true;
    }
    const searchText = normalizeText3(
      document2.querySelector("form[role='search'], [role='search']")?.textContent ?? document2.querySelector("input[type='search']")?.getAttribute("placeholder")
    );
    return searchText.includes("docs");
  }
  function hasResultGrid(document2) {
    return Boolean(document2.querySelector(".results-grid, [data-search-results], .search-layout"));
  }
  function getAnchorElement2(region) {
    return region.anchor.deref?.() ?? null;
  }
  function getSearchLabel(element, region, docsSearch, hasResults) {
    if (!element) {
      return null;
    }
    if (region.primitive === "repeated-item") {
      return "Search results";
    }
    if (region.primitive === "authored-block" && hasResults) {
      return "Primary result";
    }
    if (region.primitive === "interactive-block" && region.subtype === "search") {
      return docsSearch ? "Docs search" : "Search query";
    }
    if (region.primitive === "interactive-block" && region.subtype === "filter") {
      return "Search filters";
    }
    if (region.primitive === "interactive-block" && region.subtype === "sort") {
      return "Sort results";
    }
    return null;
  }
  function toRegionDescriptor2(region) {
    return region.subtype ? { primitive: region.primitive, subtype: region.subtype } : { primitive: region.primitive };
  }
  function resolveSearchCategory(region, docsSearch) {
    if (docsSearch && (region.primitive === "authored-block" || region.primitive === "repeated-item")) {
      return "content.article";
    }
    return region.category;
  }
  function mapSkeletonRegion2(region, docsSearch, hasResults) {
    const displayLabel = getSearchLabel(
      getAnchorElement2(region),
      toRegionDescriptor2(region),
      docsSearch,
      hasResults
    );
    if (!displayLabel) {
      return region;
    }
    return {
      ...region,
      category: resolveSearchCategory(region, docsSearch),
      displayLabel
    };
  }
  function mapExpandedRegion2(region, ctx, docsSearch, hasResults) {
    const anchor = ctx.document.querySelector(`[data-semantic-region="${region.id}"]`);
    const displayLabel = getSearchLabel(anchor, toRegionDescriptor2(region), docsSearch, hasResults);
    if (!displayLabel) {
      return region;
    }
    return {
      ...region,
      category: resolveSearchCategory(region, docsSearch),
      displayLabel
    };
  }
  function findSelectionElement2(ctx, selection) {
    const candidateIds = [selection.nodeId, selection.scopeRootId, selection.rootNodeId].filter(
      (value) => Boolean(value)
    );
    for (const nodeId of candidateIds) {
      const element = ctx.document.querySelector(
        `[data-semantic-region="${selection.regionId}"][data-semantic-node-id="${nodeId}"]`
      );
      if (element) {
        return element;
      }
    }
    return ctx.document.querySelector(`[data-semantic-region="${selection.regionId}"]`);
  }
  function resolveSelectionScope2(element, input) {
    if (input.primitive === "repeated-item" && input.nodeId) {
      return {
        rootNodeId: input.rootNodeId ?? input.nodeId,
        scopeRootId: input.scopeRootId ?? input.nodeId
      };
    }
    const scopeRootId = input.scopeRootId ?? element?.getAttribute("data-semantic-scope-root-id") ?? input.rootNodeId ?? input.nodeId;
    const rootNodeId = input.rootNodeId ?? scopeRootId ?? input.nodeId;
    return {
      rootNodeId,
      scopeRootId
    };
  }
  function resolveSelectionLabel2(input, displayLabel) {
    if (input.primitive === "repeated-item") {
      return "Search result";
    }
    if (input.primitive === "authored-block") {
      return "Primary result";
    }
    return displayLabel;
  }
  var SearchEnhancer = class {
    id = "search";
    match(url, document2) {
      return isSearchPage(url, document2);
    }
    refineSkeleton(input, ctx) {
      const docsSearch = isDocsSearchPage(ctx.url, ctx.document);
      const hasResults = hasResultGrid(ctx.document);
      return {
        ...input,
        regions: input.regions.map((region) => mapSkeletonRegion2(region, docsSearch, hasResults))
      };
    }
    refineRegion(input, ctx) {
      const docsSearch = isDocsSearchPage(ctx.url, ctx.document);
      return mapExpandedRegion2(input, ctx, docsSearch, hasResultGrid(ctx.document));
    }
    refineSelection(input, ctx) {
      const element = findSelectionElement2(ctx, input);
      const docsSearch = isDocsSearchPage(ctx.url, ctx.document);
      const displayLabel = getSearchLabel(
        element,
        toRegionDescriptor2(input),
        docsSearch,
        hasResultGrid(ctx.document)
      );
      if (!displayLabel) {
        return input;
      }
      const scope = resolveSelectionScope2(element, input);
      const label = resolveSelectionLabel2(input, displayLabel);
      return {
        ...input,
        ...scope,
        category: resolveSearchCategory(input, docsSearch),
        label,
        displayLabel: label
      };
    }
  };

  // src/content/semantic/core/detection/recognizers.ts
  var import_readability = __toESM(require_readability());
  var import_browser_runtime = __toESM(require_browser_runtime());

  // src/content/semantic/ast.ts
  var import_dom_to_semantic_markdown = __toESM(require_node());
  var GENERIC_ARTICLE_BLOCK_SELECTOR = [
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "p",
    "blockquote",
    "pre",
    "code",
    "ul",
    "ol",
    "img",
    "figure"
  ].join(",");
  function flattenContent(content) {
    if (typeof content === "string") {
      return content;
    }
    return content.map((node) => semanticAstToText(node)).filter(Boolean).join(" ");
  }
  function inferNodeTypeFromTag(element) {
    const tag = element.tagName.toLowerCase();
    if (/^h[1-6]$/.test(tag)) {
      return "heading";
    }
    if (tag === "blockquote") {
      return "quote";
    }
    if (tag === "pre" || tag === "code") {
      return "code";
    }
    if (tag === "ul" || tag === "ol") {
      return "list";
    }
    if (tag === "img" || tag === "figure") {
      return "image";
    }
    if (tag === "a") {
      return "link";
    }
    return "paragraph";
  }
  function inferNodeTypeFromAst(ast, element) {
    const primaryNode = ast[0];
    if (!primaryNode) {
      return inferNodeTypeFromTag(element);
    }
    switch (primaryNode.type) {
      case "heading":
        return "heading";
      case "blockquote":
        return "quote";
      case "code":
        return "code";
      case "list":
        return "list";
      case "image":
        return "image";
      case "link":
        return "link";
      default:
        return inferNodeTypeFromTag(element);
    }
  }
  var SemanticASTBuilder = class {
    build(element, options = {}) {
      return buildSemanticAst(element, options);
    }
    toContentNodes(ast) {
      const nodes = [];
      for (const [index, node] of ast.entries()) {
        const text = semanticAstToText(node);
        const normalized = normalizeText(text, { preserveLineBreaks: true });
        if (!normalized) {
          continue;
        }
        nodes.push({
          kind: "content",
          id: `ast-node-${index + 1}`,
          type: node.type === "heading" ? "heading" : node.type === "blockquote" ? "quote" : "paragraph",
          text: normalized,
          ...node.type === "heading" ? { level: node.level } : {}
        });
      }
      return nodes;
    }
  };
  function buildSemanticAst(element, options = {}) {
    return (0, import_dom_to_semantic_markdown.htmlToMarkdownAST)(element, {
      extractMainContent: false,
      ...options
    });
  }
  function semanticAstToText(node) {
    if (Array.isArray(node)) {
      return normalizeText(node.map((item) => semanticAstToText(item)).filter(Boolean).join("\n"), {
        preserveLineBreaks: true
      });
    }
    switch (node.type) {
      case "text":
        return node.content;
      case "heading":
      case "bold":
      case "italic":
      case "strikethrough":
        return flattenContent(node.content);
      case "link":
        return semanticAstToText(node.content);
      case "list":
        return node.items.map((item) => semanticAstToText(item.content)).join("\n");
      case "blockquote":
      case "semanticHtml":
        return node.content.map((item) => semanticAstToText(item)).join("\n");
      case "code":
        return node.content;
      case "image":
        return node.alt ?? "";
      case "video":
        return node.poster ?? node.src;
      case "table":
        return node.rows.map(
          (row) => row.cells.map(
            (cell) => typeof cell.content === "string" ? cell.content : semanticAstToText(cell.content)
          ).join(" | ")
        ).join("\n");
      case "custom":
        return typeof node.content === "string" ? node.content : "";
      case "meta":
        return "";
      default:
        return "";
    }
  }
  function mapElementToContentNode(element, nodeId) {
    const ast = buildSemanticAst(element);
    const textFromAst = semanticAstToText(ast);
    const text = textFromAst || extractReadableText(element, { preserveLineBreaks: true });
    const normalized = normalizeText(text, { preserveLineBreaks: true });
    if (!normalized && element.tagName.toLowerCase() !== "img") {
      return null;
    }
    const type = inferNodeTypeFromAst(ast, element);
    const node = {
      kind: "content",
      id: nodeId,
      type,
      text: normalized || element.getAttribute("alt") || ""
    };
    if (type === "heading") {
      node.level = Number.parseInt(element.tagName.slice(1), 10);
    }
    if (type === "code") {
      const className = element.getAttribute("class") ?? "";
      const languageMatch = className.match(/language-([\w-]+)/i);
      if (languageMatch?.[1]) {
        node.language = languageMatch[1];
      }
    }
    if (type === "image") {
      const imageElement = element.tagName.toLowerCase() === "img" ? element : element.querySelector("img");
      const src = imageElement?.getAttribute("src");
      const alt = imageElement?.getAttribute("alt");
      if (src || alt) {
        node.attributes = {
          ...src ? { src } : {},
          ...alt ? { alt } : {}
        };
      }
    }
    if (type === "link") {
      const href = element.getAttribute("href") ?? element.querySelector("a")?.getAttribute("href");
      if (href) {
        node.attributes = { href };
      }
    }
    return node;
  }
  function collectArticleBlockElements(root) {
    const blocks = root.matches(GENERIC_ARTICLE_BLOCK_SELECTOR) ? [root] : [];
    blocks.push(...Array.from(root.querySelectorAll(GENERIC_ARTICLE_BLOCK_SELECTOR)));
    return blocks.filter((element, index, all) => {
      if (index === 0) {
        return true;
      }
      return !all.some((candidate, candidateIndex) => {
        return candidateIndex < index && candidate !== element && candidate.contains(element);
      });
    });
  }
  function annotateContentNodes(root, prefix) {
    const blocks = collectArticleBlockElements(root);
    blocks.forEach((element, index) => {
      element.setAttribute("data-semantic-node-id", `${prefix}-${index + 1}`);
    });
    return blocks;
  }

  // src/content/semantic/signals.ts
  function signatureForElement(element) {
    const classes = [...element.classList].sort().join(".");
    const role = element.getAttribute("role");
    const childSignature = Array.from(element.children).map((child) => {
      const childClasses = [...child.classList].slice(0, 2).sort().join(".");
      const attrNames = [...child.attributes].map((attribute) => attribute.name).slice(0, 3).sort().join(",");
      return [child.tagName.toLowerCase(), childClasses, attrNames].join(":");
    }).join("/");
    const depthHint = element.querySelector("[indent],[data-depth],[aria-level]") ? "depth" : "";
    return [element.tagName.toLowerCase(), classes, role ?? "", String(element.children.length), childSignature, depthHint].join("|");
  }
  function scoreSignal(strength) {
    switch (strength) {
      case "strong":
        return 5;
      case "medium":
        return 3;
      case "weak":
        return 1;
    }
  }
  function scoreCandidate(signals) {
    return signals.reduce((total, signal) => total + scoreSignal(signal.strength), 0);
  }
  function detectSemanticElementCandidates(document2) {
    const elements = Array.from(
      document2.querySelectorAll(
        "article,main,nav,aside,section,header,footer,[role='main'],[role='navigation'],[role='complementary'],[role='contentinfo']"
      )
    );
    return elements.map((element, index) => {
      const isRole = element.hasAttribute("role");
      const signals = [
        {
          type: isRole ? "aria-landmark" : "semantic-element",
          strength: "strong",
          detail: isRole ? element.getAttribute("role") ?? "" : element.tagName.toLowerCase()
        }
      ];
      return {
        id: `semantic-${index + 1}`,
        kind: element.tagName.toLowerCase(),
        element,
        signals,
        score: scoreCandidate(signals)
      };
    });
  }
  function detectRepeatedStructureCandidates(document2) {
    const candidates = [];
    let candidateIndex = 0;
    for (const parent of Array.from(document2.querySelectorAll("*"))) {
      const children = Array.from(parent.children);
      if (children.length < 3) {
        continue;
      }
      const grouped = /* @__PURE__ */ new Map();
      for (const child of children) {
        const signature = signatureForElement(child);
        grouped.set(signature, [...grouped.get(signature) ?? [], child]);
      }
      for (const [signature, items] of grouped) {
        if (items.length < 3) {
          continue;
        }
        const signals = [
          {
            type: "repetition",
            strength: "medium",
            detail: signature
          }
        ];
        const hasDepthChange = new Set(
          items.map((item) => item.getAttribute("indent")).filter((value) => Boolean(value))
        ).size > 1;
        if (hasDepthChange) {
          signals.push({
            type: "depth-change",
            strength: "medium",
            detail: "indent-variation"
          });
        }
        const classHint = items.some(
          (item) => /comment|reply|thread|post|article|content/i.test(`${item.id} ${item.className}`)
        );
        if (classHint) {
          signals.push({
            type: "class-hint",
            strength: "weak",
            detail: "semantic-keyword"
          });
        }
        candidateIndex += 1;
        candidates.push({
          id: `repeat-${candidateIndex}`,
          kind: hasDepthChange ? "thread" : "list",
          element: parent,
          itemElements: items,
          signals,
          score: scoreCandidate(signals)
        });
      }
    }
    return candidates.sort((left, right) => right.score - left.score);
  }
  function detectHeadingClusterCandidates(document2) {
    const headingLikeElements = Array.from(
      document2.querySelectorAll("h1,h2,h3,h4,h5,h6,[role='heading'],.titleline")
    );
    return headingLikeElements.map((element, index) => {
      const container = element.closest("article,main,section,table,tbody,div") ?? element;
      const signals = [
        {
          type: "heading-boundary",
          strength: element.matches(".titleline") ? "medium" : "strong",
          detail: element.tagName.toLowerCase()
        }
      ];
      if (/title|story|content|article/i.test(`${container.id} ${container.className}`)) {
        signals.push({
          type: "class-hint",
          strength: "weak",
          detail: "heading-container"
        });
      }
      return {
        id: `heading-${index + 1}`,
        kind: "content",
        element: container,
        signals,
        score: scoreCandidate(signals)
      };
    });
  }

  // src/content/semantic/core/detection/recognizers.ts
  var TITLE_SELECTOR = "h1,h2,h3,h4,h5,h6,[role='heading'],a,strong";
  var AUTHOR_SELECTOR = "[rel='author'],[itemprop*='author' i],[class*='author' i],[class*='user' i]";
  var TIMESTAMP_SELECTOR = "time,[datetime],[class*='time' i],[class*='date' i],[class*='age' i]";
  var METADATA_SELECTOR = "time,[datetime],[class*='meta' i],[class*='byline' i],[class*='info' i],[class*='subtext' i]";
  var PRIMARY_TEXT_SELECTOR = "article,section,p,blockquote,pre,code,div,td,li,a,span";
  function splitTitleParts(title) {
    return title.split(/\s+[|\-–—:]\s+/).map((part) => normalizeText(part)).filter((part) => part.length >= 8);
  }
  function getTitleHint(document2) {
    const [first] = splitTitleParts(document2.title);
    return first ?? null;
  }
  function signatureForElement2(element) {
    const classes = [...element.classList].slice(0, 4).sort().join(".");
    const childSignature = Array.from(element.children).map((child) => {
      const childClasses = [...child.classList].slice(0, 2).sort().join(".");
      const attrNames = [...child.attributes].map((attribute) => attribute.name).slice(0, 3).sort().join(",");
      return [child.tagName.toLowerCase(), childClasses, attrNames].join(":");
    }).join("/");
    const depthHint = element.querySelector("[indent],[data-depth],[aria-level]") ? "depth" : "";
    return [element.tagName.toLowerCase(), classes, String(element.children.length), childSignature, depthHint].join("|");
  }
  function signatureSimilarity(left, right) {
    if (left === right) {
      return 1;
    }
    const leftParts = new Set(left.split("|"));
    const rightParts = new Set(right.split("|"));
    const shared = [...leftParts].filter((part) => rightParts.has(part)).length;
    return shared / Math.max(leftParts.size, rightParts.size, 1);
  }
  function roleHintForElement(element) {
    if (element.querySelector(".titleline,h1,h2,h3,h4,h5,h6,[role='heading'],strong")) {
      return "title";
    }
    if (element.querySelector(".subtext,.meta,.byline,.age,time,[class*='subtext'],[class*='meta']")) {
      return "metadata";
    }
    return "body";
  }
  function buildScopeRootId(regionId) {
    return `${regionId}-scope-root`;
  }
  function annotateRegionNodes(region) {
    for (const blueprint of region.nodeBlueprints) {
      blueprint.element.setAttribute("data-semantic-region", region.id);
      blueprint.element.setAttribute("data-semantic-primitive", region.primitive);
      if (region.subtype) {
        blueprint.element.setAttribute("data-semantic-subtype", region.subtype);
      } else {
        blueprint.element.removeAttribute("data-semantic-subtype");
      }
      blueprint.element.setAttribute("data-semantic-category", blueprint.category ?? region.category);
      blueprint.element.setAttribute("data-semantic-node-id", blueprint.nodeId);
      blueprint.element.setAttribute("data-semantic-node-kind", blueprint.kind);
      blueprint.element.setAttribute("data-semantic-scope-root-id", blueprint.scopeRootId);
      blueprint.element.setAttribute("data-semantic-display-label", blueprint.displayLabel);
      if (blueprint.textPreview) {
        blueprint.element.setAttribute("data-semantic-text-preview", blueprint.textPreview);
      } else {
        blueprint.element.removeAttribute("data-semantic-text-preview");
      }
    }
  }
  function getElementDepth(element, root) {
    if (element.tagName.toLowerCase() === "li") {
      let depth = 0;
      let current = element.parentElement;
      while (current && current !== root) {
        if (current.tagName.toLowerCase() === "li") {
          depth += 1;
        }
        current = current.parentElement;
      }
      return depth;
    }
    const candidates = [
      element.getAttribute("aria-level"),
      element.getAttribute("data-depth"),
      element.getAttribute("depth"),
      element.getAttribute("level"),
      element.querySelector("[indent]")?.getAttribute("indent"),
      element.querySelector("[data-depth]")?.getAttribute("data-depth"),
      element.querySelector("[aria-level]")?.getAttribute("aria-level")
    ];
    for (const candidate of candidates) {
      const parsed = Number.parseInt(candidate ?? "", 10);
      if (Number.isFinite(parsed)) {
        return parsed;
      }
    }
    const descendantWithSpacing = element.querySelector("[style*='padding-left'],[style*='margin-left']");
    if (descendantWithSpacing) {
      const style = descendantWithSpacing.getAttribute("style") ?? "";
      const match = style.match(/(?:padding-left|margin-left)\s*:\s*(\d+)/i);
      if (match?.[1]) {
        const spacing = Number.parseInt(match[1], 10);
        if (Number.isFinite(spacing) && spacing > 0) {
          return Math.round(spacing / 40);
        }
      }
    }
    return 0;
  }
  function findTitleElement(root, titleHint) {
    const candidates = Array.from(root.querySelectorAll(TITLE_SELECTOR));
    if (titleHint) {
      for (const candidate of candidates) {
        const text = normalizeText(candidate.textContent ?? "");
        if (!text) {
          continue;
        }
        if (text.includes(titleHint) || titleHint.includes(text)) {
          return candidate;
        }
      }
    }
    return candidates[0] ?? null;
  }
  function findMetadataElement(root) {
    return root.querySelector(METADATA_SELECTOR);
  }
  function findAuthor(root) {
    const author = normalizeText(root.querySelector(AUTHOR_SELECTOR)?.textContent ?? "");
    return author || void 0;
  }
  function findTimestamp(root) {
    const timestamp = normalizeText(
      root.querySelector(TIMESTAMP_SELECTOR)?.getAttribute("datetime") ?? root.querySelector(TIMESTAMP_SELECTOR)?.textContent ?? ""
    );
    return timestamp || void 0;
  }
  function scorePrimaryCandidate(root, candidate) {
    const text = normalizeText(candidate.textContent ?? "");
    if (!text) {
      return -1;
    }
    let score = text.length;
    if (candidate.matches("p,blockquote,pre,code,article,section,div")) {
      score += 40;
    }
    if (candidate.matches("a")) {
      score += 15;
    }
    if (candidate.matches(AUTHOR_SELECTOR) || candidate.matches(TIMESTAMP_SELECTOR)) {
      score -= 50;
    }
    let depth = 0;
    let current = candidate;
    while (current && current !== root) {
      depth += 1;
      current = current.parentElement;
    }
    return score + depth;
  }
  function findPrimaryContentElement(root) {
    const candidates = [root, ...Array.from(root.querySelectorAll(PRIMARY_TEXT_SELECTOR))];
    const best = candidates.map((candidate) => ({
      candidate,
      score: scorePrimaryCandidate(root, candidate)
    })).filter((entry) => entry.score >= 0).sort((left, right) => right.score - left.score)[0];
    return best?.candidate ?? root;
  }
  function findBestRepeatedChildGroup(root) {
    const directChildren = Array.from(root.children);
    if (directChildren.length < 3) {
      return [];
    }
    const groups = /* @__PURE__ */ new Map();
    for (const child of directChildren) {
      const signature = signatureForElement2(child);
      groups.set(signature, [...groups.get(signature) ?? [], child]);
    }
    const group = [...groups.values()].sort((left, right) => right.length - left.length)[0];
    return group && group.length >= 3 ? group : [];
  }
  function uniqueElements(elements) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const element of elements) {
      if (seen.has(element)) {
        continue;
      }
      seen.add(element);
      result.push(element);
    }
    return result;
  }
  function textForElement(element) {
    return normalizeText(extractReadableText(element, { preserveLineBreaks: true }));
  }
  function buildRegionId(primitive, index) {
    return `${primitive}-${index + 1}`;
  }
  function describeRegionLabel(primitive, subtype, nodeKind) {
    if (primitive === "repeated-item" && subtype === "nested") {
      return nodeKind === "comment" ? "Comment" : "Thread branch";
    }
    if (primitive === "repeated-item" && subtype === "grid") {
      return "Result card";
    }
    if (primitive === "repeated-item") {
      return "Feed item";
    }
    if (primitive === "navigation-cluster") {
      if (subtype === "breadcrumb") {
        return "Breadcrumb";
      }
      if (subtype === "pagination") {
        return "Pagination";
      }
      return "Menu";
    }
    if (primitive === "authored-block") {
      return "Article section";
    }
    if (primitive === "interactive-block") {
      if (subtype === "search") {
        return "Search";
      }
      if (subtype === "filter") {
        return "Filter controls";
      }
      if (subtype === "sort") {
        return "Sort controls";
      }
      if (subtype === "form") {
        return "Form";
      }
      return "Action group";
    }
    return "Semantic item";
  }
  function applyHeadingHierarchy(nodes) {
    const stack = [];
    return nodes.map((node) => {
      const nextNode = { ...node };
      if (nextNode.type === "heading" && nextNode.level) {
        while (stack.length > 0 && stack[stack.length - 1].level >= nextNode.level) {
          stack.pop();
        }
        if (stack.length > 0) {
          nextNode.parentId = stack[stack.length - 1].id;
        }
        stack.push({
          id: nextNode.id,
          level: nextNode.level
        });
        return nextNode;
      }
      if (stack.length > 0) {
        nextNode.parentId = stack[stack.length - 1].id;
      }
      return nextNode;
    });
  }
  function getSemanticRootFallback(document2, titleHint) {
    const titleMatch = titleHint ? Array.from(document2.querySelectorAll(TITLE_SELECTOR)).find((candidate) => {
      const text = normalizeText(candidate.textContent ?? "");
      return text.includes(titleHint) || titleHint.includes(text);
    }) ?? null : null;
    return document2.querySelector("article") ?? document2.querySelector("main") ?? document2.querySelector("[role='main']") ?? titleMatch?.closest("article,main,section,table,tbody,div") ?? detectSemanticElementCandidates(document2)[0]?.element ?? detectHeadingClusterCandidates(document2)[0]?.element ?? null;
  }
  function detectReaderableArticle(document2) {
    const titleHint = getTitleHint(document2);
    const fallbackRoot = getSemanticRootFallback(document2, titleHint);
    const readerable = (0, import_readability.isProbablyReaderable)(document2, {
      minContentLength: 80,
      minScore: 16
    });
    if (!readerable) {
      return {
        root: fallbackRoot,
        title: titleHint ?? document2.title ?? null,
        byline: null,
        excerpt: null,
        siteName: null,
        publishedTime: null
      };
    }
    const clone = document2.cloneNode(true);
    const reader = new import_readability.Readability(clone, {
      charThreshold: 80,
      serializer: (node) => node
    });
    const article = reader.parse();
    return {
      root: fallbackRoot,
      title: article?.title ?? titleHint ?? document2.title ?? null,
      byline: article?.byline ?? null,
      excerpt: article?.excerpt ?? null,
      siteName: article?.siteName ?? null,
      publishedTime: article?.publishedTime ?? null
    };
  }
  function buildAuthoredRegion(regionId, root, subtype, metadata) {
    const nodes = [];
    const blueprints = [];
    const titleHint = getTitleHint(root.ownerDocument);
    const titleElement = findTitleElement(root, titleHint);
    const metadataElement = findMetadataElement(root);
    const titleText = normalizeText(
      titleElement?.textContent ?? titleHint ?? root.ownerDocument.title ?? extractReadableText(root)
    );
    let index = 0;
    let titleNodeId = null;
    if (titleText) {
      index += 1;
      titleNodeId = `${regionId}-node-${index}`;
      nodes.push({
        kind: "content",
        id: titleNodeId,
        type: "heading",
        text: titleText,
        level: 1
      });
      if (titleElement) {
        blueprints.push({
          nodeId: titleNodeId,
          element: titleElement,
          kind: "content",
          scopeRootId: titleNodeId,
          displayLabel: describeRegionLabel("authored-block", subtype, "content")
        });
      }
    }
    const metadataText = metadataElement ? textForElement(metadataElement) : "";
    if (metadataElement && metadataText) {
      index += 1;
      const nodeId = `${regionId}-node-${index}`;
      nodes.push({
        kind: "content",
        id: nodeId,
        type: "metadata",
        text: metadataText,
        ...titleNodeId ? { parentId: titleNodeId } : {}
      });
      blueprints.push({
        nodeId,
        element: metadataElement,
        kind: "content",
        scopeRootId: titleNodeId ?? nodeId,
        displayLabel: describeRegionLabel("authored-block", subtype, "content")
      });
    }
    if (titleElement instanceof HTMLAnchorElement && titleElement.href) {
      index += 1;
      const nodeId = `${regionId}-node-${index}`;
      nodes.push({
        kind: "content",
        id: nodeId,
        type: "link",
        text: titleElement.href,
        attributes: {
          href: titleElement.href
        },
        ...titleNodeId ? { parentId: titleNodeId } : {}
      });
      blueprints.push({
        nodeId,
        element: titleElement,
        kind: "content",
        scopeRootId: titleNodeId ?? nodeId,
        displayLabel: describeRegionLabel("authored-block", subtype, "content")
      });
    }
    const annotatedBlocks = annotateContentNodes(root, `${regionId}-content`);
    const remainingBlocks = annotatedBlocks.filter((element) => element !== titleElement && element !== metadataElement);
    const contentNodes = applyHeadingHierarchy(
      remainingBlocks.map((element, blockIndex) => {
        const nodeId = `${regionId}-node-${index + blockIndex + 1}`;
        return mapElementToContentNode(element, nodeId);
      }).filter((node) => node !== null && Boolean(node.text))
    );
    for (const node of contentNodes) {
      if (titleNodeId && !node.parentId && node.type !== "heading") {
        node.parentId = titleNodeId;
      }
      nodes.push(node);
      const element = remainingBlocks.find((candidate) => candidate.getAttribute("data-semantic-node-id") === node.id);
      if (element) {
        const scopeRootId = node.type === "heading" ? node.id : node.parentId ?? titleNodeId ?? node.id;
        blueprints.push({
          nodeId: node.id,
          element,
          kind: "content",
          scopeRootId,
          displayLabel: describeRegionLabel("authored-block", subtype, "content")
        });
      }
    }
    const region = {
      id: regionId,
      kind: "authored-block",
      primitive: "authored-block",
      subtype,
      category: subtype === "post" ? "content.post" : "content.article",
      displayLabel: describeRegionLabel("authored-block", subtype),
      nodes,
      structure: {
        type: "sequence",
        rootIds: nodes.filter((node) => !node.parentId).map((node) => node.id)
      }
    };
    if (metadata && region.nodes.length > 0 && "text" in region.nodes[0]) {
      const firstNode = region.nodes[0];
      region.nodes[0] = {
        ...firstNode,
        attributes: metadata
      };
    }
    return {
      region,
      blueprints
    };
  }
  var AuthoredBlockRecognizer = class {
    primitive = "authored-block";
    detectDetailed(document2) {
      const signal = detectReaderableArticle(document2);
      const root = signal.root;
      if (!root || textForElement(root).length < 80) {
        return [];
      }
      const isFeedLikeTable = root.matches("table,tbody") && document2.querySelectorAll("tr").length >= 5 && !document2.querySelector("[indent],[data-depth],[aria-level]");
      const repeatedStructureAtRoot = detectRepeatedStructureCandidates(document2).some((candidate) => {
        const itemCount = candidate.itemElements?.length ?? 0;
        const hasDepthChange = candidate.signals.some((signal2) => signal2.type === "depth-change");
        return candidate.element === root && itemCount >= 3 && !hasDepthChange;
      });
      if (isFeedLikeTable || root.matches("table,tbody") && repeatedStructureAtRoot) {
        return [];
      }
      const subtype = root.querySelector("h2,h3,h4,h5,h6") ? "article" : "post";
      const regionId = buildRegionId(this.primitive, 0);
      const metadata = {
        ...signal.byline ? { byline: signal.byline } : {},
        ...signal.excerpt ? { excerpt: signal.excerpt } : {},
        ...signal.siteName ? { siteName: signal.siteName } : {},
        ...signal.publishedTime ? { publishedTime: signal.publishedTime } : {}
      };
      const { region, blueprints } = buildAuthoredRegion(regionId, root, subtype, metadata);
      return [
        {
          id: regionId,
          element: root,
          primitive: this.primitive,
          confidence: signal.byline || signal.excerpt ? 0.95 : 0.82,
          signals: signal.byline || signal.excerpt ? ["readability", "semantic-root"] : ["semantic-root", "heading-cluster"],
          subtype,
          category: region.category,
          kind: region.kind,
          displayLabel: region.displayLabel ?? "Article section",
          ...Object.keys(metadata).length > 0 ? { metadata } : {},
          ...signal.title ? { pageTitle: signal.title } : {},
          pageKindHint: subtype === "post" ? "post" : "article",
          nodeBlueprints: blueprints,
          ...region.structure ? { structure: region.structure } : {}
        }
      ];
    }
    extractDetailed(region, document2) {
      const root = region.element ?? detectReaderableArticle(document2).root ?? document2.body;
      const { region: authoredRegion, blueprints } = buildAuthoredRegion(
        region.id,
        root,
        region.subtype ?? "article"
      );
      annotateRegionNodes({
        id: region.id,
        element: root,
        primitive: this.primitive,
        confidence: 1,
        signals: [],
        ...region.subtype ? { subtype: region.subtype } : {},
        category: authoredRegion.category,
        kind: authoredRegion.kind,
        displayLabel: authoredRegion.displayLabel ?? "Article section",
        nodeBlueprints: blueprints,
        ...authoredRegion.structure ? { structure: authoredRegion.structure } : {}
      });
      return authoredRegion;
    }
  };
  function computeNavigationSubtype(element) {
    const linkTexts = Array.from(element.querySelectorAll("a[href]")).map(
      (link) => normalizeText(link.textContent ?? "")
    );
    const fullText = normalizeText(element.textContent ?? "");
    const hasBreadcrumbSeparators = /›|»|\/|>/.test(fullText);
    const numericLinks = linkTexts.filter((text) => /^\d+$/.test(text)).length;
    const prevNextLinks = linkTexts.filter((text) => /\b(prev|next|previous)\b/i.test(text)).length;
    if (hasBreadcrumbSeparators || /breadcrumb/i.test(element.getAttribute("aria-label") ?? "")) {
      return "breadcrumb";
    }
    if (numericLinks >= 2 || prevNextLinks >= 1) {
      return "pagination";
    }
    if (element.closest("aside")) {
      return "local";
    }
    return "global";
  }
  function buildNavigationRegion(regionId, root, subtype) {
    const links = uniqueElements(Array.from(root.querySelectorAll("a[href]"))).filter(
      (link) => normalizeText(link.textContent ?? "").length > 0
    );
    const category = subtype === "breadcrumb" ? "navigation.breadcrumb" : subtype === "pagination" ? "navigation.pagination" : "navigation.menu";
    const nodes = [];
    const blueprints = [];
    links.forEach((link, index) => {
      const nodeId = `${regionId}-link-${index + 1}`;
      const text = normalizeText(link.textContent ?? link.href);
      nodes.push({
        kind: "content",
        id: nodeId,
        type: "link",
        text,
        attributes: {
          href: link.href
        }
      });
      blueprints.push({
        nodeId,
        element: link,
        kind: "content",
        scopeRootId: nodeId,
        displayLabel: describeRegionLabel("navigation-cluster", subtype, "content")
      });
    });
    return {
      region: {
        id: regionId,
        kind: "navigation-cluster",
        primitive: "navigation-cluster",
        subtype,
        category,
        displayLabel: describeRegionLabel("navigation-cluster", subtype),
        nodes,
        structure: {
          type: "flat",
          rootIds: nodes.map((node) => node.id)
        }
      },
      blueprints
    };
  }
  var NavigationClusterRecognizer = class {
    primitive = "navigation-cluster";
    detectDetailed(document2) {
      const candidates = uniqueElements([
        ...Array.from(document2.querySelectorAll("nav,[role='navigation'],header,footer,aside")),
        ...Array.from(document2.querySelectorAll("ul,ol")).filter((list) => {
          const links = Array.from(list.querySelectorAll(":scope > li > a[href]"));
          return links.length >= 2 && links.length === list.querySelectorAll(":scope > li").length;
        })
      ]);
      return candidates.flatMap((element, index) => {
        const links = Array.from(element.querySelectorAll("a[href]"));
        if (links.length < 2) {
          return [];
        }
        const text = normalizeText(element.textContent ?? "");
        const linkText = normalizeText(links.map((link) => link.textContent ?? "").join(" "));
        const density = text.length === 0 ? 1 : linkText.length / text.length;
        if (!element.matches("nav,[role='navigation']") && density < 0.7) {
          return [];
        }
        const subtype = computeNavigationSubtype(element);
        const regionId = buildRegionId(this.primitive, index);
        const { region, blueprints } = buildNavigationRegion(regionId, element, subtype);
        return {
          id: regionId,
          element,
          primitive: this.primitive,
          confidence: element.matches("nav,[role='navigation']") ? 0.94 : 0.76,
          signals: element.matches("nav,[role='navigation']") ? ["semantic-nav"] : ["link-density"],
          subtype,
          category: region.category,
          kind: region.kind,
          displayLabel: region.displayLabel ?? "Menu",
          pageKindHint: "generic",
          nodeBlueprints: blueprints,
          ...region.structure ? { structure: region.structure } : {}
        };
      });
    }
    extractDetailed(region, _document) {
      const root = region.element;
      if (!root) {
        return {
          id: region.id,
          kind: region.kind,
          primitive: region.primitive,
          ...region.subtype ? { subtype: region.subtype } : {},
          category: region.category,
          nodes: []
        };
      }
      const { region: navRegion, blueprints } = buildNavigationRegion(region.id, root, region.subtype ?? "global");
      annotateRegionNodes({
        id: region.id,
        element: root,
        primitive: this.primitive,
        confidence: 1,
        signals: [],
        ...region.subtype ? { subtype: region.subtype } : {},
        category: navRegion.category,
        kind: navRegion.kind,
        displayLabel: navRegion.displayLabel ?? "Menu",
        nodeBlueprints: blueprints,
        ...navRegion.structure ? { structure: navRegion.structure } : {}
      });
      return navRegion;
    }
  };
  function buildCommentNodeFromElement(element, nodeId, parentId, depth) {
    const primary = findPrimaryContentElement(element);
    let text = textForElement(primary);
    if (!text) {
      text = textForElement(element);
    }
    if (!text) {
      return null;
    }
    const author = findAuthor(element);
    const timestamp = findTimestamp(element);
    return {
      kind: "comment",
      id: nodeId,
      text,
      depth,
      ...author ? { author } : {},
      ...timestamp ? { timestamp } : {},
      ...parentId ? { parentId } : {},
      ...element.id ? { metadata: { sourceElementId: element.id } } : {}
    };
  }
  function buildContentNodeFromElement(element, nodeId) {
    const primary = findPrimaryContentElement(element);
    return mapElementToContentNode(primary, nodeId) ?? mapElementToContentNode(element, nodeId);
  }
  function hasInteractiveAffordance(element) {
    return Boolean(element.querySelector("button,input,select,textarea,[role='button'],[role='tab']"));
  }
  function hasStructuredContent(element) {
    return Boolean(
      element.querySelector("h1,h2,h3,h4,h5,h6,[role='heading'],a[href],img,picture,video,strong,blockquote,time")
    );
  }
  function countSelfAndDescendants(element, selector) {
    return (element.matches(selector) ? 1 : 0) + element.querySelectorAll(selector).length;
  }
  function isGridContainer(element, items) {
    const semanticText = `${element.className} ${element.id} ${element.getAttribute("style") ?? ""}`.toLowerCase();
    if (/\bgrid\b|\bcard\b|\bresult\b|\bgallery\b|\btiles?\b/.test(semanticText)) {
      return true;
    }
    const itemWidths = items.map((item) => item.getBoundingClientRect().width).filter((width) => Number.isFinite(width) && width > 0);
    if (itemWidths.length >= 3) {
      const uniqueWidths = new Set(itemWidths.map((width) => Math.round(width / 10)));
      if (uniqueWidths.size <= 2 && items.length >= 4) {
        return true;
      }
    }
    return false;
  }
  function semanticTextForElement(element) {
    return [
      element.tagName.toLowerCase(),
      element.className,
      element.id,
      element.getAttribute("role") ?? "",
      element.getAttribute("aria-label") ?? ""
    ].join(" ").toLowerCase();
  }
  function combinedTextForElements(elements) {
    return normalizeText(elements.map((element) => element.textContent ?? "").join(" ")).toLowerCase();
  }
  function hasCardLikeHint(element) {
    return /\bcard\b|\bgrid\b|\bresult\b|\bgallery\b|\btiles?\b|\bfeed\b|\bitemlist\b|\bresults\b|\bmasonry\b|\bcatalog\b/.test(
      semanticTextForElement(element)
    );
  }
  function isUtilityContainer(element) {
    if (element.closest("nav,footer,header,aside")) {
      return true;
    }
    return /\bnav\b|\bmenu\b|\bfooter\b|\bsidebar\b|\bbreadcrumb\b|\bpagination\b|\btoolbar\b|\butility\b|\bresource\b|\bsections\b|\brelated\b|\btoc\b/.test(
      semanticTextForElement(element)
    );
  }
  function hasCommentBody(element) {
    return Boolean(element.querySelector(".commtext,.comment,[class*='comment' i],[data-comment-id]"));
  }
  function hasCommentMetadata(element) {
    return Boolean(
      element.querySelector(".hnuser,[rel='author'],[itemprop*='author' i],[class*='author' i],[class*='user' i]") || element.querySelector(".age,time,[datetime],[class*='time' i],[class*='date' i],[class*='age' i]")
    );
  }
  function hasCollapsedThreadHint(text) {
    return /\[\s*\d+\s+more\s*\]|show more|more replies|collapsed/i.test(text);
  }
  function hasExplicitThreadHint(text) {
    return /\b(parent|root|next|prev)\b/i.test(text);
  }
  function looksLikeThreadItem(element) {
    const text = normalizeText(element.textContent ?? "");
    if (!text) {
      return false;
    }
    if (element.querySelector("textarea") && !hasCommentBody(element)) {
      return false;
    }
    return Boolean(
      hasCommentBody(element) || hasCommentMetadata(element) || element.matches("[indent],[data-depth],[aria-level]") || element.querySelector("[indent],[data-depth],[aria-level]") || /\breply\b/i.test(text) || hasCollapsedThreadHint(text) || hasExplicitThreadHint(text)
    );
  }
  function scoreThreadStructure(root, items) {
    const semanticText = `${semanticTextForElement(root)} ${items.map((item) => semanticTextForElement(item)).join(" ")}`;
    const flattenedText = combinedTextForElements([root, ...items]);
    let score = 0;
    if (items.some((item) => item.matches("[indent],[aria-level],[data-depth]") || item.querySelector("[indent],[aria-level],[data-depth]"))) {
      score += 2;
    }
    if (items.some(hasCommentBody)) {
      score += 3;
    }
    if (items.some(hasCommentMetadata)) {
      score += 2;
    }
    if (/\b(comment|comments|thread|discussion|commtext|hnuser)\b/.test(semanticText)) {
      score += 2;
    }
    if (/\breply\b/.test(flattenedText)) {
      score += 1;
    }
    if (hasCollapsedThreadHint(flattenedText)) {
      score += 2;
    }
    if (hasExplicitThreadHint(flattenedText)) {
      score += 2;
    }
    if (items.filter(looksLikeThreadItem).length >= Math.max(2, Math.floor(items.length / 2))) {
      score += 1;
    }
    return score;
  }
  function looksLikeThreadStructure(root, items) {
    return scoreThreadStructure(root, items) >= 3;
  }
  function looksLikeNavigationTree(root, items) {
    const semanticText = `${semanticTextForElement(root)} ${items.map((item) => semanticTextForElement(item)).join(" ")}`;
    const anchors = items.flatMap((item) => Array.from(item.querySelectorAll("a[href]")));
    const fragmentLinkRatio = anchors.length === 0 ? 0 : anchors.filter((link) => (link.getAttribute("href") ?? "").startsWith("#")).length / anchors.length;
    const mostlyLinkItems = items.filter((item) => {
      const links = countSelfAndDescendants(item, "a[href]");
      const controls = countSelfAndDescendants(item, "button,input,select,textarea,[role='button'],[role='tab']");
      const prose = countSelfAndDescendants(item, "p,blockquote,pre,code");
      return links >= 1 && controls === 0 && prose === 0 && !looksLikeThreadItem(item);
    }).length / Math.max(1, items.length);
    return root.matches("nav,[role='navigation'],aside") || /\b(toc|table of contents|contents|sidebar|breadcrumb|menu|sections?|chapters?|outline)\b/.test(semanticText) || mostlyLinkItems >= 0.8 && fragmentLinkRatio >= 0.6;
  }
  function filterNestedRepeatedItems(items) {
    const filtered = items.filter(looksLikeThreadItem);
    return filtered.length >= 3 ? filtered : items;
  }
  function normalizeRepeatedItems(root, items, subtype) {
    if (subtype !== "nested") {
      return items;
    }
    if (looksLikeNavigationTree(root, items)) {
      return items;
    }
    return filterNestedRepeatedItems(items);
  }
  function computeRepeatedConfidence(root, items, subtype, approximate = false) {
    if (subtype === "nested") {
      return Math.min(0.96, (approximate ? 0.84 : 0.88) + Math.min(scoreThreadStructure(root, items), 4) * 0.02);
    }
    if (subtype === "grid") {
      return approximate ? 0.76 : 0.8;
    }
    const allRows = items.every((item) => item.tagName.toLowerCase() === "tr");
    return approximate ? 0.74 : allRows ? 0.84 : 0.78;
  }
  function classifyRepeatedSubtype(root, items) {
    const depths = items.map((item) => getElementDepth(item, root));
    const hasDepthVariation = new Set(depths).size > 1 || depths.some((depth) => depth > 0);
    if (hasDepthVariation) {
      return "nested";
    }
    if (isGridContainer(root, items)) {
      return "grid";
    }
    return "flat";
  }
  function isSimpleTextItem(element) {
    const links = countSelfAndDescendants(element, "a[href]");
    const controls = countSelfAndDescendants(
      element,
      "button,input,select,textarea,[role='button'],[role='tab']"
    );
    const media = countSelfAndDescendants(element, "img,picture,video,svg");
    const headings = countSelfAndDescendants(element, "h1,h2,h3,h4,h5,h6,[role='heading'],strong");
    const prose = countSelfAndDescendants(element, "p,blockquote,pre,code");
    const textLength = textForElement(element).length;
    return links <= 1 && controls === 0 && media === 0 && headings === 0 && prose === 0 && textLength < 140;
  }
  function looksLikeAuthoredProseList(root, items, subtype) {
    if (subtype !== "flat") {
      return false;
    }
    if (!root.matches("ul,ol")) {
      return false;
    }
    if (!root.closest("article,main,section") || root.closest("nav,aside,footer")) {
      return false;
    }
    if (hasCardLikeHint(root)) {
      return false;
    }
    if (!items.every((item) => item.tagName.toLowerCase() === "li")) {
      return false;
    }
    const averageLength = items.reduce((sum, item) => sum + textForElement(item).length, 0) / Math.max(1, items.length);
    const simpleItemCount = items.filter((item) => isSimpleTextItem(item)).length;
    return simpleItemCount / Math.max(1, items.length) >= 0.8 && averageLength < 120;
  }
  function looksLikeUtilityLinkCluster(root, items, subtype) {
    if (subtype === "nested" || !isUtilityContainer(root) || hasCardLikeHint(root)) {
      return false;
    }
    const averageLength = items.reduce((sum, item) => sum + textForElement(item).length, 0) / Math.max(1, items.length);
    const mostlyLinkItems = items.filter((item) => {
      const links = countSelfAndDescendants(item, "a[href]");
      const controls = countSelfAndDescendants(item, "button,input,select,textarea,[role='button'],[role='tab']");
      const media = countSelfAndDescendants(item, "img,picture,video,svg");
      return links >= 1 && controls === 0 && media === 0;
    }).length;
    return mostlyLinkItems / Math.max(1, items.length) >= 0.8 && averageLength < 100;
  }
  function isLowQualityRepeatedCandidate(root, items, subtype) {
    if (subtype === "nested") {
      if (looksLikeNavigationTree(root, items)) {
        return true;
      }
      return !looksLikeThreadStructure(root, items);
    }
    const textLengths = items.map((item) => textForElement(item).length);
    const nonEmptyCount = textLengths.filter((length) => length > 0).length;
    if (nonEmptyCount < 3) {
      return true;
    }
    const averageLength = textLengths.reduce((sum, length) => sum + length, 0) / Math.max(1, textLengths.length);
    const insideAuthoredBlock = Boolean(root.closest("article,main,section"));
    const hasStructure = items.some((item) => hasStructuredContent(item) || hasInteractiveAffordance(item));
    if (looksLikeUtilityLinkCluster(root, items, subtype)) {
      return true;
    }
    if (looksLikeAuthoredProseList(root, items, subtype)) {
      return true;
    }
    return insideAuthoredBlock && !hasStructure && averageLength < 60;
  }
  function resolveRepeatedItemElements(root, preferredItems) {
    if (preferredItems && preferredItems.length > 0) {
      return preferredItems;
    }
    const tag = root.tagName.toLowerCase();
    if (tag === "ul" || tag === "ol") {
      return Array.from(root.querySelectorAll("li"));
    }
    if (tag === "table") {
      const tbody = root.querySelector("tbody");
      if (tbody) {
        return resolveRepeatedItemElements(tbody);
      }
      return findBestRepeatedChildGroup(root);
    }
    return findBestRepeatedChildGroup(root);
  }
  function findApproximateRepeatedChildGroup(root) {
    const children = Array.from(root.children);
    if (children.length < 3 || children.length > 40) {
      return [];
    }
    const signatures = children.map((child) => ({
      child,
      signature: signatureForElement2(child),
      roleHint: roleHintForElement(child)
    }));
    let best = [];
    for (const seed of signatures) {
      const family = signatures.filter(
        (candidate) => signatureSimilarity(seed.signature, candidate.signature) >= 0.7 && candidate.roleHint === seed.roleHint
      ).map((candidate) => candidate.child);
      if (family.length > best.length) {
        best = family;
      }
    }
    return best.length >= 3 && best.length / children.length >= 0.5 ? best : [];
  }
  function findTitleRowGroup(root) {
    const children = Array.from(root.children).filter((child) => child.tagName.toLowerCase() === "tr");
    if (children.length < 3) {
      return [];
    }
    const titleRows = children.filter(
      (child) => roleHintForElement(child) === "title" && Boolean(child.querySelector("a[href],h1,h2,h3,h4,h5,h6,[role='heading'],.titleline,strong"))
    );
    return titleRows.length >= 3 ? titleRows : [];
  }
  function looksLikeCardChild(element) {
    const links = countSelfAndDescendants(element, "a[href]");
    const headings = countSelfAndDescendants(element, "h1,h2,h3,h4,h5,h6,[role='heading'],strong");
    const media = countSelfAndDescendants(element, "img,picture,video,svg");
    const controls = countSelfAndDescendants(element, "button,[role='button']");
    const textLength = textForElement(element).length;
    return links >= 1 && textLength >= 24 && (headings >= 1 || media >= 1 || controls >= 1);
  }
  function findLooseCardChildGroup(root) {
    if (!hasCardLikeHint(root)) {
      return [];
    }
    const children = Array.from(root.children);
    if (children.length < 3 || children.length > 20) {
      return [];
    }
    const cards = children.filter((child) => looksLikeCardChild(child));
    return cards.length >= 3 && cards.length / children.length >= 0.6 ? cards : [];
  }
  function buildRepeatedFlatNode(item, nodeId) {
    const node = buildContentNodeFromElement(item.primaryElement, nodeId) ?? buildContentNodeFromElement(item.element, nodeId);
    if (!node || !node.text) {
      return null;
    }
    const attributes = {
      ...node.attributes ?? {},
      ...item.links?.primary ?? node.attributes?.href ? { primaryHref: item.links?.primary ?? node.attributes?.href } : {},
      ...item.links?.discussion ? { discussionHref: item.links.discussion } : {},
      ...item.metadata?.author ? { author: item.metadata.author } : {},
      ...item.metadata?.timestamp ? { timestamp: item.metadata.timestamp } : {},
      ...item.metadata?.score ? { score: item.metadata.score } : {},
      ...item.metadata?.commentCount ? { commentCount: item.metadata.commentCount } : {}
    };
    if (item.links?.primary && !attributes.href) {
      attributes.href = item.links.primary;
    }
    return {
      ...node,
      ...Object.keys(attributes).length > 0 ? { attributes } : {}
    };
  }
  function buildRepeatedRegion(regionId, root, subtype, preferredItems, assembledItems) {
    const itemElements = resolveRepeatedItemElements(root, preferredItems);
    const isNested = subtype === "nested";
    if (isNested) {
      const nodes2 = [];
      const blueprints2 = [];
      const stack = [];
      itemElements.forEach((element, index) => {
        const depth = getElementDepth(element, root);
        while (stack.length > 0 && stack[stack.length - 1].depth >= depth) {
          stack.pop();
        }
        const parentId = stack[stack.length - 1]?.id;
        const nodeId = `${regionId}-item-${index + 1}`;
        const node = buildCommentNodeFromElement(element, nodeId, parentId, depth);
        if (!node) {
          return;
        }
        const rootId = stack[0]?.rootId ?? node.id;
        nodes2.push(node);
        blueprints2.push({
          nodeId: node.id,
          element: findPrimaryContentElement(element),
          kind: "comment",
          scopeRootId: rootId,
          displayLabel: node.author ? `Comment by ${node.author}` : describeRegionLabel("repeated-item", subtype, "comment"),
          category: "discussion.comment",
          textPreview: node.text
        });
        stack.push({
          depth,
          id: node.id,
          rootId
        });
      });
      return {
        region: {
          id: regionId,
          kind: "repeated-item",
          primitive: "repeated-item",
          subtype,
          category: "discussion.thread",
          displayLabel: describeRegionLabel("repeated-item", subtype),
          nodes: nodes2,
          structure: {
            type: "tree",
            rootIds: nodes2.filter((node) => !node.parentId).map((node) => node.id)
          }
        },
        blueprints: blueprints2
      };
    }
    const nodes = [];
    const blueprints = [];
    const itemLabel = subtype === "grid" ? "Result card" : "Feed item";
    const builtItems = assembledItems && assembledItems.length > 0 ? assembledItems : itemElements.map((element, index) => ({
      nodeId: `${regionId}-item-${index + 1}`,
      element,
      primaryElement: findPrimaryContentElement(element),
      kind: "content",
      companions: [],
      scopeRootId: buildScopeRootId(regionId),
      displayLabel: itemLabel,
      category: "content.post",
      textPreview: textForElement(element)
    }));
    builtItems.forEach((item, index) => {
      const nodeId = item.nodeId || `${regionId}-item-${index + 1}`;
      const node = buildRepeatedFlatNode(item, nodeId);
      if (!node || !node.text) {
        return;
      }
      nodes.push(node);
      const blueprintElements = uniqueElements([item.element, item.primaryElement, ...item.companions]);
      for (const element of blueprintElements) {
        blueprints.push({
          nodeId,
          element,
          kind: "content",
          scopeRootId: item.scopeRootId || buildScopeRootId(regionId),
          displayLabel: item.displayLabel || itemLabel,
          category: item.category ?? "content.post",
          textPreview: item.textPreview ?? node.text
        });
      }
    });
    return {
      region: {
        id: regionId,
        kind: "repeated-item",
        primitive: "repeated-item",
        subtype,
        category: "content.post",
        displayLabel: itemLabel,
        nodes,
        structure: {
          type: "flat",
          rootIds: nodes.map((node) => node.id)
        }
      },
      blueprints
    };
  }
  var RepeatedItemRecognizer = class {
    primitive = "repeated-item";
    detectDetailed(document2) {
      const listRegions = Array.from(document2.querySelectorAll("ul,ol")).filter((list) => list.querySelectorAll(":scope > li").length >= 3 || list.querySelectorAll("li").length >= 3).map((element) => {
        const subtype = element.querySelector("li ul, li ol") ? "nested" : "flat";
        const itemElements = normalizeRepeatedItems(element, Array.from(element.querySelectorAll("li")), subtype);
        return {
          element,
          itemElements,
          subtype,
          confidence: computeRepeatedConfidence(element, itemElements, subtype),
          signals: [subtype === "nested" ? "list-thread-structure" : "list-structure"]
        };
      }).filter((candidate) => !isLowQualityRepeatedCandidate(candidate.element, candidate.itemElements, candidate.subtype));
      const repeatedCandidates = detectRepeatedStructureCandidates(document2).filter((candidate) => {
        const items = candidate.itemElements ?? [];
        return items.length >= 3;
      }).map((candidate) => {
        const rawItems = candidate.itemElements ?? [];
        const subtype = classifyRepeatedSubtype(candidate.element, rawItems);
        const itemElements = normalizeRepeatedItems(candidate.element, rawItems, subtype);
        return {
          element: candidate.element,
          itemElements,
          subtype,
          confidence: computeRepeatedConfidence(candidate.element, itemElements, subtype),
          signals: subtype === "nested" ? ["repeated-rows", "depth-variation", "thread-signals"] : subtype === "grid" ? ["repeated-rows", "layout-regularity"] : ["repeated-rows"]
        };
      }).filter((candidate) => !isLowQualityRepeatedCandidate(candidate.element, candidate.itemElements, candidate.subtype));
      const approximateCandidates = Array.from(document2.querySelectorAll("tbody,table,section,div")).map((element) => {
        const items = findApproximateRepeatedChildGroup(element);
        const resolvedItems = items.length >= 3 ? items : findTitleRowGroup(element).length >= 3 ? findTitleRowGroup(element) : findLooseCardChildGroup(element);
        if (resolvedItems.length < 3) {
          return null;
        }
        const subtype = classifyRepeatedSubtype(element, resolvedItems);
        const itemElements = normalizeRepeatedItems(element, resolvedItems, subtype);
        return {
          element,
          itemElements,
          subtype,
          confidence: computeRepeatedConfidence(element, itemElements, subtype, true),
          signals: subtype === "nested" ? ["approximate-repetition", "depth-variation", "thread-signals"] : subtype === "grid" ? ["approximate-repetition", "layout-regularity"] : ["approximate-repetition"]
        };
      }).filter((candidate) => Boolean(candidate)).filter((candidate) => !repeatedCandidates.some((existing) => existing.element === candidate.element)).filter((candidate) => !isLowQualityRepeatedCandidate(candidate.element, candidate.itemElements, candidate.subtype));
      return uniqueElements(
        [
          ...listRegions.map((region) => region.element),
          ...repeatedCandidates.map((region) => region.element),
          ...approximateCandidates.map((region) => region.element)
        ]
      ).flatMap((element, index) => {
        const config = listRegions.find((region2) => region2.element === element) ?? repeatedCandidates.find((region2) => region2.element === element) ?? approximateCandidates.find((region2) => region2.element === element);
        if (!config) {
          return [];
        }
        const regionId = buildRegionId(this.primitive, index);
        const { region, blueprints } = buildRepeatedRegion(regionId, element, config.subtype, config.itemElements);
        if (region.nodes.length === 0) {
          return [];
        }
        return {
          id: regionId,
          element,
          primitive: this.primitive,
          confidence: config.confidence,
          signals: config.signals,
          subtype: config.subtype,
          category: region.category,
          kind: region.kind,
          displayLabel: describeRegionLabel("repeated-item", config.subtype),
          pageKindHint: config.subtype === "nested" ? "thread" : "generic",
          itemElements: config.itemElements,
          nodeBlueprints: blueprints,
          ...region.structure ? { structure: region.structure } : {}
        };
      });
    }
    extractDetailed(region, _document) {
      const root = region.element;
      if (!root) {
        return {
          id: region.id,
          kind: region.kind,
          primitive: region.primitive,
          ...region.subtype ? { subtype: region.subtype } : {},
          category: region.category,
          nodes: []
        };
      }
      const { region: repeatedRegion, blueprints } = buildRepeatedRegion(
        region.id,
        root,
        region.subtype ?? "flat",
        region.itemElements,
        region.assembledItems
      );
      annotateRegionNodes({
        id: region.id,
        element: root,
        primitive: this.primitive,
        confidence: 1,
        signals: [],
        ...region.subtype ? { subtype: region.subtype } : {},
        category: repeatedRegion.category,
        kind: repeatedRegion.kind,
        displayLabel: repeatedRegion.displayLabel ?? "Feed item",
        nodeBlueprints: blueprints,
        ...repeatedRegion.structure ? { structure: repeatedRegion.structure } : {}
      });
      return repeatedRegion;
    }
  };
  function interactiveCategoryForSubtype(subtype) {
    if (subtype === "search") {
      return "interactive.search";
    }
    if (subtype === "filter") {
      return "interactive.filter";
    }
    if (subtype === "sort") {
      return "interactive.sort";
    }
    if (subtype === "form") {
      return "interactive.form";
    }
    return "interactive.action";
  }
  function rootActionForSubtype(subtype) {
    if (subtype === "search") {
      return "search";
    }
    if (subtype === "filter") {
      return "filter";
    }
    if (subtype === "sort") {
      return "sort";
    }
    if (subtype === "form") {
      return "submit";
    }
    return "unknown";
  }
  function getInteractiveControls(root) {
    const matches = /* @__PURE__ */ new Set();
    if (root instanceof HTMLElement && root.matches("input,select,textarea,button,[role='button'],[role='tab'],[role='searchbox']")) {
      matches.add(root);
    }
    for (const element of Array.from(
      root.querySelectorAll("input,select,textarea,button,[role='button'],[role='tab'],[role='searchbox']")
    )) {
      const inputType = element.getAttribute("type")?.toLowerCase() ?? "";
      if (inputType === "hidden") {
        continue;
      }
      matches.add(element);
    }
    return [...matches];
  }
  function getInteractiveControlType(control) {
    const tag = control.tagName.toLowerCase();
    const role = control.getAttribute("role")?.toLowerCase();
    const inputType = control.getAttribute("type")?.toLowerCase() ?? "";
    if (tag === "select") {
      return "select";
    }
    if (tag === "textarea") {
      return "textarea";
    }
    if (tag === "button") {
      return "button";
    }
    if (role === "button" && tag === "a") {
      return "link-button";
    }
    if (role === "tab") {
      return "chip";
    }
    if (inputType === "checkbox") {
      return "checkbox";
    }
    if (inputType === "radio") {
      return "radio";
    }
    return "input";
  }
  function resolveControlLabel(control, root) {
    const labelledBy = control.getAttribute("aria-labelledby");
    if (labelledBy) {
      const label2 = labelledBy.split(/\s+/).map((id) => normalizeText(root.ownerDocument.getElementById(id)?.textContent ?? "")).filter(Boolean).join(" ");
      if (label2) {
        return label2;
      }
    }
    const label = normalizeText(
      control.getAttribute("aria-label") ?? control.closest("label")?.textContent ?? root.querySelector(`label[for="${control.id}"]`)?.textContent ?? control.getAttribute("title") ?? control.textContent ?? ""
    );
    return label;
  }
  function buildInteractiveSemanticText(root, controls) {
    return normalizeText(
      [
        root.getAttribute("role"),
        root.getAttribute("aria-label"),
        root.getAttribute("id"),
        root.getAttribute("class"),
        ...controls.map(
          (control) => [
            control.getAttribute("role"),
            control.getAttribute("type"),
            control.getAttribute("placeholder"),
            control.getAttribute("name"),
            control.getAttribute("aria-label"),
            control.getAttribute("title"),
            control.textContent
          ].join(" ")
        )
      ].join(" ")
    ).toLowerCase();
  }
  function isSortChoiceText(text) {
    return /\b(relevance|recent|latest|newest|oldest|top|best|popular|price|date|name|rating)\b/.test(text);
  }
  function resolveInteractiveRegionLabel(root, subtype, controls) {
    const semanticText = buildInteractiveSemanticText(root, controls);
    const explicitLabel = normalizeText(
      root.getAttribute("aria-label") ?? root.querySelector("legend,h1,h2,h3,h4,h5,h6,[role='heading']")?.textContent ?? ""
    );
    if (explicitLabel) {
      return explicitLabel;
    }
    if (subtype === "search") {
      if (/\b(command palette|quick search|quick open|cmd\s*k|ctrl\s*k|⌘k)\b/.test(semanticText)) {
        return "Command palette";
      }
      return "Search controls";
    }
    if (subtype === "filter") {
      return controls.some((control) => {
        const type = control.getAttribute("type")?.toLowerCase();
        return type === "checkbox" || type === "radio";
      }) ? "Filter panel" : "Filter controls";
    }
    if (subtype === "sort") {
      return root.matches("[role='tablist']") || controls.filter((control) => getInteractiveControlType(control) === "chip").length >= 2 ? "Sort tabs" : "Sort controls";
    }
    return describeRegionLabel("interactive-block", subtype);
  }
  function resolveInteractiveSubtype(root, controls) {
    const semanticText = buildInteractiveSemanticText(root, controls);
    const checkboxRadioCount = controls.filter((control) => {
      const type = control.getAttribute("type")?.toLowerCase();
      return type === "checkbox" || type === "radio";
    }).length;
    const selectCount = controls.filter((control) => control.tagName.toLowerCase() === "select").length;
    const chipCount = controls.filter((control) => getInteractiveControlType(control) === "chip").length;
    const textInputCount = controls.filter((control) => {
      const controlType = getInteractiveControlType(control);
      const inputType = control.getAttribute("type")?.toLowerCase() ?? "";
      return controlType === "input" && inputType !== "hidden" && inputType !== "checkbox" && inputType !== "radio";
    }).length;
    const searchInputCount = controls.filter((control) => {
      const inputType = control.getAttribute("type")?.toLowerCase() ?? "";
      const labelText = resolveControlLabel(control, root).toLowerCase();
      return inputType === "search" || control.getAttribute("role") === "searchbox" || /\b(search|find|query)\b/.test(
        `${labelText} ${(control.getAttribute("placeholder") ?? "").toLowerCase()} ${(control.getAttribute("name") ?? "").toLowerCase()}`
      );
    }).length;
    const buttonCount = controls.filter((control) => {
      const tag = control.tagName.toLowerCase();
      return tag === "button" || control.getAttribute("role") === "button";
    }).length;
    const labelledChoices = controls.map((control) => resolveControlLabel(control, root).toLowerCase()).filter(Boolean);
    const sortChoiceCount = labelledChoices.filter((label) => isSortChoiceText(label)).length;
    const hasCommandPaletteHint = /\b(command palette|quick search|quick open|cmd\s*k|ctrl\s*k|⌘k)\b/.test(semanticText);
    const hasSearchCue = /\b(search|find|query)\b/.test(semanticText);
    const hasSortCue = /\bsort|order|relevance|recent|latest|newest|oldest|top|best|popular\b/.test(semanticText);
    const hasFilterCue = /\bfilter|facet|facets|category|tag|topic|status|price|date\b/.test(semanticText);
    const hasSearchButtonCue = controls.some((control) => {
      const label = resolveControlLabel(control, root).toLowerCase();
      return getInteractiveControlType(control) !== "input" && /\b(search|find)\b/.test(label);
    });
    if (root.matches("form[role='search'],[role='search']") || hasSearchCue || controls.some((control) => control.getAttribute("role") === "searchbox") || searchInputCount >= 1 || hasSearchButtonCue || hasCommandPaletteHint && buttonCount >= 1) {
      return "search";
    }
    if (hasSortCue || root.matches("[role='tablist']") && sortChoiceCount >= 2 || sortChoiceCount >= Math.max(2, Math.floor(controls.length / 2))) {
      return "sort";
    }
    if (hasFilterCue || checkboxRadioCount >= 2 || selectCount >= 1 && buttonCount >= 1 && !hasSortCue || chipCount >= 3 && !hasSortCue) {
      return "filter";
    }
    if (root.matches("form,fieldset") || textInputCount >= 2 || controls.some((control) => control.tagName.toLowerCase() === "textarea") || textInputCount >= 1 && selectCount >= 1 || textInputCount >= 1 && buttonCount >= 1 && controls.length >= 3) {
      return "form";
    }
    return "action-group";
  }
  function resolveInteractiveAction(control, subtype) {
    if (subtype === "search" || subtype === "filter" || subtype === "sort") {
      return subtype;
    }
    const semanticText = normalizeText(
      `${control.getAttribute("aria-label") ?? ""} ${control.getAttribute("name") ?? ""} ${control.textContent ?? ""}`
    ).toLowerCase();
    if (/\bsubmit|save|apply\b/.test(semanticText)) {
      return "submit";
    }
    if (/\btoggle|show|hide|expand|collapse\b/.test(semanticText)) {
      return "toggle";
    }
    if (control.tagName.toLowerCase() === "a") {
      return "navigate";
    }
    return "unknown";
  }
  function resolveInteractiveState(control) {
    if (control.hasAttribute("disabled")) {
      return "disabled";
    }
    if ("checked" in control) {
      return control.checked ? "checked" : "unchecked";
    }
    if (control.getAttribute("aria-selected") === "true") {
      return "selected";
    }
    if (control.getAttribute("aria-expanded") === "true") {
      return "expanded";
    }
    if (control.getAttribute("aria-expanded") === "false") {
      return "collapsed";
    }
    return void 0;
  }
  function buildInteractiveMetadata(control) {
    const metadata = {};
    const tag = control.tagName.toLowerCase();
    const inputType = control.getAttribute("type");
    const placeholder = control.getAttribute("placeholder");
    const autocomplete = control.getAttribute("autocomplete");
    const name = control.getAttribute("name");
    const rawValue = "value" in control ? String(control.value ?? "") : "";
    if (tag) {
      metadata.tag = tag;
    }
    if (inputType) {
      metadata.inputType = inputType;
    }
    if (placeholder) {
      metadata.placeholder = placeholder;
    }
    if (autocomplete) {
      metadata.autocomplete = autocomplete;
    }
    if (name) {
      metadata.name = name;
    }
    if (rawValue) {
      metadata.rawValue = rawValue;
    }
    return metadata;
  }
  function collectInteractiveRoots(document2) {
    const strongRoots = Array.from(
      document2.querySelectorAll("form,fieldset,[role='search'],[role='toolbar'],[role='tablist']")
    );
    const inferredRoots = Array.from(document2.querySelectorAll("div,section,aside,header")).filter((element) => {
      const controls = getInteractiveControls(element);
      if (controls.length < 2 || controls.length > 8) {
        return false;
      }
      const semanticText = `${element.className} ${element.id} ${element.getAttribute("aria-label") ?? ""}`.toLowerCase();
      const hasKeyword = /\bsearch|filter|sort|toolbar|actions?|controls?\b/.test(semanticText);
      const hasMultipleControlKinds = new Set(controls.map((control) => getInteractiveControlType(control))).size >= 2;
      return hasKeyword || hasMultipleControlKinds;
    });
    const accepted = [];
    const candidates = uniqueElements([...strongRoots, ...inferredRoots]).map((root) => ({ root, controls: getInteractiveControls(root) })).filter(({ controls }) => controls.length > 0).sort((left, right) => left.controls.length - right.controls.length);
    for (const candidate of candidates) {
      const overlaps = accepted.some(
        (acceptedCandidate) => candidate.controls.some((control) => acceptedCandidate.controls.includes(control))
      );
      if (overlaps) {
        continue;
      }
      accepted.push(candidate);
    }
    return accepted.map((candidate) => candidate.root);
  }
  function buildInteractiveRegion(regionId, root, subtype) {
    const controls = getInteractiveControls(root);
    const category = interactiveCategoryForSubtype(subtype);
    const regionLabel = resolveInteractiveRegionLabel(root, subtype, controls);
    const rootAction = rootActionForSubtype(subtype);
    const rootNodeId = `${regionId}-cluster`;
    const nodes = [
      {
        kind: "interactive",
        id: rootNodeId,
        controlType: "group",
        label: regionLabel,
        action: rootAction,
        metadata: {
          controlCount: String(controls.length),
          subtype
        }
      }
    ];
    const blueprints = [
      {
        nodeId: rootNodeId,
        element: root,
        kind: "interactive",
        scopeRootId: rootNodeId,
        displayLabel: regionLabel,
        category,
        textPreview: regionLabel
      }
    ];
    controls.forEach((control, index) => {
      const label = resolveControlLabel(control, root);
      const node = (0, import_browser_runtime.sanitizeInteractiveNode)({
        kind: "interactive",
        id: `${regionId}-control-${index + 1}`,
        controlType: getInteractiveControlType(control),
        ...label ? { label } : {},
        ...control.getAttribute("role") ? { role: control.getAttribute("role") } : {},
        action: resolveInteractiveAction(control, subtype),
        ...resolveInteractiveState(control) ? { state: resolveInteractiveState(control) } : {},
        ...control.tagName.toLowerCase() === "select" ? { options: Array.from(control.options).map((option) => normalizeText(option.text)) } : {},
        parentId: rootNodeId,
        metadata: buildInteractiveMetadata(control)
      });
      const labelText = node.label ?? regionLabel;
      nodes.push(node);
      blueprints.push({
        nodeId: node.id,
        element: control,
        kind: "interactive",
        scopeRootId: rootNodeId,
        displayLabel: labelText,
        category,
        textPreview: node.valuePreview ?? labelText
      });
    });
    return {
      region: {
        id: regionId,
        kind: "interactive-block",
        primitive: "interactive-block",
        subtype,
        category,
        displayLabel: regionLabel,
        nodes,
        structure: {
          type: "sequence",
          rootIds: [rootNodeId]
        }
      },
      blueprints
    };
  }
  var InteractiveBlockRecognizer = class {
    primitive = "interactive-block";
    detectDetailed(document2) {
      return collectInteractiveRoots(document2).flatMap((element, index) => {
        const controls = getInteractiveControls(element);
        if (controls.length === 0) {
          return [];
        }
        const subtype = resolveInteractiveSubtype(element, controls);
        const regionId = buildRegionId(this.primitive, index);
        const { region, blueprints } = buildInteractiveRegion(regionId, element, subtype);
        if (region.nodes.length <= 1) {
          return [];
        }
        return {
          id: regionId,
          element,
          primitive: this.primitive,
          confidence: element.matches("form,[role='search'],[role='toolbar'],[role='tablist']") ? 0.9 : 0.78,
          signals: [subtype === "search" ? "search-controls" : "interactive-controls"],
          subtype,
          category: region.category,
          kind: region.kind,
          displayLabel: region.displayLabel ?? "Form",
          nodeBlueprints: blueprints,
          ...region.structure ? { structure: region.structure } : {}
        };
      });
    }
    extractDetailed(region, _document) {
      const root = region.element;
      if (!root) {
        return {
          id: region.id,
          kind: region.kind,
          primitive: region.primitive,
          ...region.subtype ? { subtype: region.subtype } : {},
          category: region.category,
          nodes: []
        };
      }
      const { region: interactiveRegion, blueprints } = buildInteractiveRegion(region.id, root, region.subtype ?? "form");
      annotateRegionNodes({
        id: region.id,
        element: root,
        primitive: this.primitive,
        confidence: 1,
        signals: [],
        ...region.subtype ? { subtype: region.subtype } : {},
        category: interactiveRegion.category,
        kind: interactiveRegion.kind,
        displayLabel: interactiveRegion.displayLabel ?? "Form",
        nodeBlueprints: blueprints,
        ...interactiveRegion.structure ? { structure: interactiveRegion.structure } : {}
      });
      return interactiveRegion;
    }
  };
  function compareRegionPriority(left, right) {
    if (right.confidence !== left.confidence) {
      return right.confidence - left.confidence;
    }
    const leftArea = left.element.getBoundingClientRect().width * left.element.getBoundingClientRect().height;
    const rightArea = right.element.getBoundingClientRect().width * right.element.getBoundingClientRect().height;
    if (leftArea !== rightArea) {
      return leftArea - rightArea;
    }
    const position = left.element.compareDocumentPosition(right.element);
    if (position & Node.DOCUMENT_POSITION_FOLLOWING) {
      return -1;
    }
    if (position & Node.DOCUMENT_POSITION_PRECEDING) {
      return 1;
    }
    return 0;
  }
  function dedupeRegions(regions) {
    const accepted = [];
    for (const region of [...regions].sort(compareRegionPriority)) {
      const duplicate = accepted.find((acceptedRegion) => acceptedRegion.element === region.element);
      if (duplicate) {
        continue;
      }
      accepted.push(region);
    }
    return accepted;
  }
  function assignContainment(regions) {
    for (const region of regions) {
      const parent = regions.filter((candidate) => candidate !== region && candidate.element.contains(region.element)).sort((left, right) => {
        const leftContainsRight = left.element.contains(right.element);
        const rightContainsLeft = right.element.contains(left.element);
        if (leftContainsRight && !rightContainsLeft) {
          return 1;
        }
        if (rightContainsLeft && !leftContainsRight) {
          return -1;
        }
        return 0;
      })[0];
      if (parent) {
        region.parentId = parent.id;
      }
    }
  }
  function createDefaultRecognizers() {
    return [
      new AuthoredBlockRecognizer(),
      new NavigationClusterRecognizer(),
      new RepeatedItemRecognizer(),
      new InteractiveBlockRecognizer()
    ];
  }

  // src/content/semantic/core/helpers.ts
  function buildWeakRef(element, fallback) {
    return new WeakRef(element ?? fallback);
  }
  function clearSemanticNodeAttributes(root) {
    const attributes = [
      "data-semantic-region",
      "data-semantic-primitive",
      "data-semantic-subtype",
      "data-semantic-category",
      "data-semantic-node-id",
      "data-semantic-node-kind",
      "data-semantic-scope-root-id",
      "data-semantic-display-label",
      "data-semantic-text-preview",
      "data-semantic-layout-role",
      "data-semantic-role-rank",
      "data-semantic-auto-suppressed"
    ];
    for (const element of Array.from(root.querySelectorAll("[data-semantic-region],[data-semantic-node-id]"))) {
      for (const attribute of attributes) {
        element.removeAttribute(attribute);
      }
    }
  }
  function annotateRegionNodes2(region) {
    for (const blueprint of region.nodeBlueprints) {
      blueprint.element.setAttribute("data-semantic-region", region.id);
      blueprint.element.setAttribute("data-semantic-primitive", region.primitive);
      if (region.subtype) {
        blueprint.element.setAttribute("data-semantic-subtype", region.subtype);
      } else {
        blueprint.element.removeAttribute("data-semantic-subtype");
      }
      blueprint.element.setAttribute("data-semantic-category", blueprint.category ?? region.category);
      blueprint.element.setAttribute("data-semantic-node-id", blueprint.nodeId);
      blueprint.element.setAttribute("data-semantic-node-kind", blueprint.kind);
      blueprint.element.setAttribute("data-semantic-scope-root-id", blueprint.scopeRootId);
      blueprint.element.setAttribute("data-semantic-display-label", blueprint.displayLabel);
      if (blueprint.textPreview) {
        blueprint.element.setAttribute("data-semantic-text-preview", blueprint.textPreview);
      } else {
        blueprint.element.removeAttribute("data-semantic-text-preview");
      }
      if (region.layoutRole) {
        blueprint.element.setAttribute("data-semantic-layout-role", region.layoutRole);
      } else {
        blueprint.element.removeAttribute("data-semantic-layout-role");
      }
      if (region.roleRank) {
        blueprint.element.setAttribute("data-semantic-role-rank", region.roleRank);
      } else {
        blueprint.element.removeAttribute("data-semantic-role-rank");
      }
      blueprint.element.setAttribute("data-semantic-auto-suppressed", String(Boolean(region.autoSuppressed)));
    }
  }
  function derivePageId(url) {
    const parsed = new URL(url);
    const pathname = parsed.pathname.replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "");
    return `${parsed.hostname}-${pathname || "root"}`;
  }
  function buildPageKind(regions) {
    if (regions.some((region) => region.primitive === "repeated-item" && region.subtype === "nested")) {
      return "thread";
    }
    const authored = regions.find((region) => region.primitive === "authored-block");
    if (authored?.subtype === "post") {
      return "post";
    }
    if (authored) {
      return "article";
    }
    return "generic";
  }
  function buildPageDescription(document2, url, regions) {
    const authoredRegion = regions.find((region) => region.primitive === "authored-block");
    const metadata = authoredRegion?.metadata && Object.keys(authoredRegion.metadata).length > 0 ? authoredRegion.metadata : void 0;
    return {
      id: derivePageId(url),
      url,
      title: authoredRegion?.pageTitle ?? document2.title,
      kind: buildPageKind(regions),
      ...metadata ? { metadata } : {}
    };
  }
  function elementToNodeTarget(element) {
    if (!element) {
      return null;
    }
    const nodeElement = element.closest("[data-semantic-node-id]");
    if (nodeElement) {
      const primitive = nodeElement.getAttribute("data-semantic-primitive");
      const scopeRootId = nodeElement.getAttribute("data-semantic-scope-root-id");
      return {
        regionId: nodeElement.getAttribute("data-semantic-region") ?? "",
        nodeId: primitive === "interactive-block" && scopeRootId ? scopeRootId : nodeElement.getAttribute("data-semantic-node-id")
      };
    }
    const regionElement = element.closest("[data-semantic-region]");
    if (!regionElement) {
      return null;
    }
    return {
      regionId: regionElement.getAttribute("data-semantic-region") ?? "",
      nodeId: null
    };
  }
  function createRegionRef(region, fallback) {
    return {
      id: region.id,
      kind: region.kind,
      primitive: region.primitive,
      ...region.subtype ? { subtype: region.subtype } : {},
      category: region.category,
      anchor: buildWeakRef(region.element.isConnected ? region.element : null, fallback),
      state: "fresh",
      ...region.parentId ? { parentId: region.parentId } : {},
      ...region.displayLabel ? { displayLabel: region.displayLabel } : {}
    };
  }
  function nodeFromRegion(region, nodeId) {
    return region.nodes.find((node) => node.id === nodeId) ?? null;
  }
  function firstMeaningfulNode(region) {
    return region.nodes.find((node) => {
      if ("text" in node) {
        return Boolean(node.text);
      }
      const interactiveNode = node;
      return Boolean(interactiveNode.label || interactiveNode.valuePreview);
    }) ?? region.nodes[0] ?? null;
  }
  function shouldAllowSuppressedFocus(source, mode) {
    if (mode === "selection" || mode === "selected") {
      return true;
    }
    return source === "context-menu" && mode === "trigger";
  }
  function toFocusResult(region, nodeId) {
    const node = (nodeId ? nodeFromRegion(region, nodeId) : null) ?? firstMeaningfulNode(region);
    if (!node) {
      return null;
    }
    return {
      regionId: region.id,
      nodeId: node.id,
      node
    };
  }
  function isRegionSuppressed(region) {
    return Boolean(region.autoSuppressed);
  }

  // src/content/semantic/core/layout/layout-role.ts
  function areaFor(element) {
    const rect = element.getBoundingClientRect();
    return rect.width * rect.height;
  }
  function textLengthFor(region) {
    return region.nodeBlueprints.reduce((sum, blueprint) => sum + (blueprint.textPreview?.length ?? 0), 0);
  }
  function isInFooter(element) {
    return Boolean(element.closest("footer,[role='contentinfo']"));
  }
  function isInHeader(element) {
    return Boolean(element.closest("header"));
  }
  function isInAside(element) {
    return Boolean(element.closest("aside,[role='complementary']"));
  }
  function roleRankScore(rank) {
    if (rank === "primary") {
      return 3;
    }
    if (rank === "supporting") {
      return 2;
    }
    return 1;
  }
  var DominanceScorer = class {
    score(region) {
      let score = 0;
      if (region.primitive === "repeated-item" && region.subtype === "nested") {
        score += 1e3;
      } else if (region.primitive === "authored-block") {
        score += 900;
      } else if (region.primitive === "repeated-item" && region.subtype === "grid") {
        score += 650;
      } else if (region.primitive === "repeated-item") {
        score += 700;
      } else if (region.primitive === "interactive-block") {
        score += 250;
      } else if (region.primitive === "navigation-cluster") {
        score += 150;
      }
      score += Math.min(400, Math.round(areaFor(region.element) / 1e3));
      score += Math.min(300, textLengthFor(region));
      if (isInAside(region.element)) {
        score -= 120;
      }
      if (isInHeader(region.element) || isInFooter(region.element)) {
        score -= 180;
      }
      return score;
    }
  };
  var RoleRanker = class {
    assignPrimary(regions, scorer) {
      const ranked = regions.filter((region) => !isInHeader(region.element) && !isInFooter(region.element)).map((region) => ({ region, score: scorer.score(region) })).sort((left, right) => right.score - left.score)[0];
      return ranked?.region.id ?? null;
    }
  };
  var UtilitySuppressor = class {
    classify(region, primaryRegionId) {
      if (region.id === primaryRegionId) {
        return {
          autoSuppressed: false,
          explicitSelectionAllowed: true
        };
      }
      if (region.primitive === "navigation-cluster") {
        return {
          autoSuppressed: true,
          explicitSelectionAllowed: true
        };
      }
      if (region.primitive === "interactive-block") {
        return {
          autoSuppressed: true,
          explicitSelectionAllowed: true
        };
      }
      return {
        autoSuppressed: false,
        explicitSelectionAllowed: true
      };
    }
  };
  var LayoutRoleAssigner = class {
    scorer = new DominanceScorer();
    ranker = new RoleRanker();
    suppressor = new UtilitySuppressor();
    assign(regions) {
      return this.assignDetailed(regions).regions;
    }
    assignDetailed(regions) {
      const primaryRegionId = this.ranker.assignPrimary(regions, this.scorer);
      const suppressions = [];
      const roled = regions.map((region) => {
        const dominanceScore = this.scorer.score(region);
        const { layoutRole, roleRank } = this.resolveRole(region, primaryRegionId);
        const suppression = this.suppressor.classify(region, primaryRegionId);
        if (suppression.autoSuppressed) {
          suppressions.push(
            `suppressed ${region.id}: ${layoutRole} auto-suppressed as ${roleRank} region`
          );
        }
        return {
          ...region,
          layoutRole,
          roleRank,
          dominanceScore,
          autoSuppressed: suppression.autoSuppressed,
          explicitSelectionAllowed: suppression.explicitSelectionAllowed,
          suppressed: suppression.autoSuppressed || !suppression.explicitSelectionAllowed
        };
      });
      return {
        regions: roled,
        suppressions
      };
    }
    resolveRole(region, primaryRegionId) {
      if (region.id === primaryRegionId) {
        return {
          layoutRole: "main-content",
          roleRank: "primary"
        };
      }
      if (region.primitive === "navigation-cluster") {
        if (isInFooter(region.element)) {
          return {
            layoutRole: "footer-resources",
            roleRank: "peripheral"
          };
        }
        if (isInAside(region.element)) {
          return {
            layoutRole: "section-nav",
            roleRank: "supporting"
          };
        }
        return {
          layoutRole: "global-nav",
          roleRank: "peripheral"
        };
      }
      if (region.primitive === "interactive-block") {
        if (region.subtype === "search") {
          return {
            layoutRole: "search-bar",
            roleRank: "peripheral"
          };
        }
        return {
          layoutRole: isInAside(region.element) ? "sidebar" : "utility",
          roleRank: isInAside(region.element) ? "supporting" : "peripheral"
        };
      }
      if (region.primitive === "authored-block") {
        return {
          layoutRole: "main-content",
          roleRank: "supporting"
        };
      }
      if (region.primitive === "repeated-item") {
        if (region.subtype === "nested") {
          return {
            layoutRole: "main-content",
            roleRank: primaryRegionId === null ? "primary" : "supporting"
          };
        }
        return {
          layoutRole: "main-content",
          roleRank: "supporting"
        };
      }
      return {
        layoutRole: "utility",
        roleRank: "peripheral"
      };
    }
  };
  function sortRegionsForFallback(left, right) {
    const rankDelta = roleRankScore(right.roleRank) - roleRankScore(left.roleRank);
    if (rankDelta !== 0) {
      return rankDelta;
    }
    if (right.dominanceScore !== left.dominanceScore) {
      return right.dominanceScore - left.dominanceScore;
    }
    return 0;
  }

  // src/content/semantic/core/assembly/repeated-item-assembly.ts
  var TITLE_SELECTOR2 = "h1,h2,h3,h4,h5,h6,[role='heading'],a,strong,.titleline";
  var AUTHOR_SELECTOR2 = "[rel='author'],[itemprop*='author' i],[class*='author' i],[class*='user' i]";
  var TIMESTAMP_SELECTOR2 = "time,[datetime],[class*='time' i],[class*='date' i],[class*='age' i]";
  function textForElement2(element) {
    return normalizeText(extractReadableText(element, { preserveLineBreaks: true }));
  }
  function uniqueElements2(elements) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    for (const element of elements) {
      if (seen.has(element)) {
        continue;
      }
      seen.add(element);
      result.push(element);
    }
    return result;
  }
  function buildScopeRootId2(regionId) {
    return `${regionId}-scope-root`;
  }
  function elementSignature(element) {
    const classes = [...element.classList].slice(0, 3).sort().join(".");
    const childTags = Array.from(element.children).slice(0, 4).map((child) => child.tagName.toLowerCase()).join("/");
    return [element.tagName.toLowerCase(), classes, childTags].join("|");
  }
  function signatureSimilarity2(left, right) {
    if (left === right) {
      return 1;
    }
    const leftParts = new Set(left.split("|"));
    const rightParts = new Set(right.split("|"));
    const shared = [...leftParts].filter((part) => rightParts.has(part)).length;
    return shared / Math.max(leftParts.size, rightParts.size, 1);
  }
  function findTitleElement2(root) {
    return root.querySelector(TITLE_SELECTOR2) ?? root.querySelector("a[href]") ?? root;
  }
  function findAuthor2(root) {
    const author = normalizeText(root.querySelector(AUTHOR_SELECTOR2)?.textContent ?? "");
    return author || void 0;
  }
  function findTimestamp2(root) {
    const timestamp = normalizeText(
      root.querySelector(TIMESTAMP_SELECTOR2)?.getAttribute("datetime") ?? root.querySelector(TIMESTAMP_SELECTOR2)?.textContent ?? ""
    );
    return timestamp || void 0;
  }
  function classifyLinkRole(link, isMetadataContext) {
    const text = normalizeText(link.textContent ?? "").toLowerCase();
    const href = link.href.toLowerCase();
    if (/\b(reply|replies|comment|comments|discuss|discussion)\b/.test(text)) {
      return "discussion";
    }
    if (/item\?id=|\/comments\b|#comments\b/.test(href)) {
      return "discussion";
    }
    if (isMetadataContext && /\bhide|past|favorite|reply\b/.test(text)) {
      return "discussion";
    }
    if (link.closest("h1,h2,h3,h4,h5,h6,.titleline")) {
      return "primary";
    }
    if (!isMetadataContext && text.length >= 8) {
      return "primary";
    }
    return null;
  }
  function classifyLinks(primaryElement, companions) {
    const groups = [
      { element: primaryElement, isMetadata: false },
      ...companions.map((element) => ({ element, isMetadata: true }))
    ];
    let primary;
    let discussion;
    for (const group of groups) {
      const links = Array.from(group.element.querySelectorAll("a[href]"));
      for (const link of links) {
        const role = classifyLinkRole(link, group.isMetadata);
        if (role === "discussion" && !discussion) {
          discussion = link.href;
        } else if (role === "primary" && !primary) {
          primary = link.href;
        }
      }
    }
    if (!primary) {
      const fallback = primaryElement.querySelector("a[href]") ?? companions[0]?.querySelector("a[href]");
      primary = fallback?.href;
    }
    return {
      ...primary ? { primary } : {},
      ...discussion ? { discussion } : {}
    };
  }
  function parseMetadata(elements) {
    const text = normalizeText(elements.map((element) => element.textContent ?? "").join(" "));
    if (!text) {
      return void 0;
    }
    const metadata = {};
    const score = text.match(/(\d+)\s+points?/i)?.[1];
    const commentCount = text.match(/(\d+)\s+comments?/i)?.[1];
    const authorMatch = text.match(/\bby\s+([a-z0-9_-]+)/i)?.[1];
    const timestampMatch = text.match(/\b(\d+\s+(?:minute|minutes|hour|hours|day|days)\s+ago|just now)\b/i)?.[1];
    const author = elements.map(findAuthor2).find(Boolean);
    const timestamp = elements.map(findTimestamp2).find(Boolean);
    if (score) {
      metadata.score = score;
    }
    if (commentCount) {
      metadata.commentCount = commentCount;
    }
    const resolvedAuthor = author ?? authorMatch;
    if (resolvedAuthor) {
      metadata.author = resolvedAuthor;
    }
    const resolvedTimestamp = timestamp ?? timestampMatch;
    if (resolvedTimestamp) {
      metadata.timestamp = resolvedTimestamp;
    }
    return Object.keys(metadata).length > 0 ? metadata : void 0;
  }
  function isSpacerRow(element) {
    const text = normalizeText(element.textContent ?? "");
    return text.length === 0 || /\bspacer\b/.test(`${element.className} ${element.id}`.toLowerCase());
  }
  function isMetadataCompanionRow(element) {
    const text = normalizeText(element.textContent ?? "");
    if (!text) {
      return false;
    }
    return Boolean(
      element.querySelector(".subtext,.score,.age,time,[class*='subtext'],[class*='meta'],[class*='age']") || element.querySelector("a[href*='item?id=']") || /\bpoints?\b|\bcomments?\b|\bago\b|\bby\b/.test(text.toLowerCase())
    );
  }
  function createBlueprints(item, category, fallbackLabel) {
    const primaryFocusElement = item.element.querySelector(".titleline,.subtext,[class*='title'],[class*='subtext']") ?? item.element.querySelector("a[href]") ?? item.element.querySelector("span,strong") ?? item.element.querySelector("td,div,p") ?? item.primaryElement;
    const companionFocusElements = item.companions.map(
      (element) => element.querySelector(".subtext,.meta,.byline,.info,[class*='subtext'],[class*='meta'],span") ?? element.querySelector("a[href]") ?? element.querySelector("p,div,strong,td") ?? element
    );
    return uniqueElements2([item.element, primaryFocusElement, item.primaryElement, ...item.companions, ...companionFocusElements]).map((element) => ({
      nodeId: item.nodeId,
      element,
      kind: item.kind,
      scopeRootId: item.scopeRootId,
      displayLabel: item.displayLabel || fallbackLabel,
      category: item.category ?? category,
      ...item.textPreview ? { textPreview: item.textPreview } : {}
    }));
  }
  function assembleFlatOrGridItems(region) {
    const items = region.itemElements ?? [];
    const itemSet = new Set(items);
    const isTableRows = items.length >= 3 && items.every((item) => item.tagName.toLowerCase() === "tr");
    const fallbackLabel = region.subtype === "grid" ? "Result card" : "Feed item";
    const familySignature = items[0] ? elementSignature(items[0]) : "";
    return items.map((element, index) => {
      const companions = [];
      if (isTableRows) {
        let current = element.nextElementSibling;
        while (current && !itemSet.has(current)) {
          if (isSpacerRow(current)) {
            current = current.nextElementSibling;
            continue;
          }
          if (isMetadataCompanionRow(current) && companions.length === 0) {
            companions.push(current);
            current = current.nextElementSibling;
            continue;
          }
          break;
        }
      }
      const primaryElement = findTitleElement2(element);
      const metadataElements = [element, ...companions];
      const title = normalizeText(primaryElement.textContent ?? "");
      const signature = elementSignature(element);
      return {
        nodeId: `${region.id}-item-${index + 1}`,
        element,
        primaryElement,
        kind: "content",
        companions,
        links: classifyLinks(primaryElement, companions),
        ...parseMetadata(metadataElements) ? { metadata: parseMetadata(metadataElements) } : {},
        scopeRootId: buildScopeRootId2(region.id),
        displayLabel: fallbackLabel,
        category: region.category,
        textPreview: title || textForElement2(primaryElement),
        ...familySignature && signatureSimilarity2(familySignature, signature) >= 0.7 ? {} : {}
      };
    });
  }
  var RepeatedItemAssembler = class {
    assembleDetailed(region) {
      const decisions = [];
      if (region.primitive !== "repeated-item") {
        return { region, decisions };
      }
      if (region.subtype === "nested") {
        return { region, decisions };
      }
      const assembledItems = assembleFlatOrGridItems(region);
      if (assembledItems.length === 0) {
        return { region, decisions };
      }
      for (const item of assembledItems) {
        if (item.companions.length > 0) {
          decisions.push(
            `merged ${item.nodeId} into one semantic item with ${item.companions.length} companion row(s)`
          );
        }
      }
      const fallbackLabel = region.subtype === "grid" ? "Result card" : "Feed item";
      const nodeBlueprints = assembledItems.flatMap(
        (item) => createBlueprints(item, region.category, fallbackLabel)
      );
      return {
        region: {
          ...region,
          assembledItems,
          nodeBlueprints
        },
        decisions
      };
    }
    assemble(region) {
      return this.assembleDetailed(region).region;
    }
  };

  // src/content/semantic/core/normalization/helpers.ts
  function buildRegionNodeElementMap(region) {
    const nodeMap = /* @__PURE__ */ new Map();
    for (const blueprint of region.nodeBlueprints) {
      const elements = nodeMap.get(blueprint.nodeId) ?? [];
      if (!elements.includes(blueprint.element)) {
        elements.push(blueprint.element);
      }
      nodeMap.set(blueprint.nodeId, elements);
    }
    return nodeMap;
  }
  function rebuildStructure(region) {
    if (region.structure?.type === "tree") {
      return {
        type: "tree",
        rootIds: region.nodes.filter((node) => !node.parentId).map((node) => node.id)
      };
    }
    if (region.structure?.type === "flat") {
      return {
        type: "flat",
        rootIds: region.nodes.map((node) => node.id)
      };
    }
    return {
      type: "sequence",
      rootIds: region.nodes.filter((node) => !node.parentId).map((node) => node.id)
    };
  }
  function normalizeParentLinks(nodes) {
    const nodeIds = new Set(nodes.map((node) => node.id));
    return nodes.map((node) => {
      if (!node.parentId || nodeIds.has(node.parentId)) {
        return node;
      }
      const nextNode = { ...node };
      delete nextNode.parentId;
      return nextNode;
    });
  }
  function filterRegionNodes(region, keepIds) {
    const filtered = region.nodes.filter((node) => keepIds.has(node.id));
    const normalized = normalizeParentLinks(filtered);
    return {
      ...region,
      nodes: normalized,
      structure: rebuildStructure({
        ...region,
        nodes: normalized
      })
    };
  }
  function applyHeadingHierarchyToContentNodes(nodes) {
    const stack = [];
    return nodes.map((node) => {
      const nextNode = { ...node };
      if (nextNode.type === "heading" && nextNode.level) {
        while (stack.length > 0 && stack[stack.length - 1].level >= nextNode.level) {
          stack.pop();
        }
        if (stack.length > 0) {
          nextNode.parentId = stack[stack.length - 1].id;
        } else {
          delete nextNode.parentId;
        }
        stack.push({
          id: nextNode.id,
          level: nextNode.level
        });
        return nextNode;
      }
      if (stack.length > 0) {
        nextNode.parentId = stack[stack.length - 1].id;
      } else {
        delete nextNode.parentId;
      }
      return nextNode;
    });
  }
  function textForElements(elements) {
    return elements.map((element) => element.textContent ?? "").join(" ").replace(/\s+/g, " ").trim();
  }

  // src/content/semantic/core/normalization/ThreadNormalizer.ts
  var COLLAPSED_BRANCH_PATTERN = /\[\s*\d+\s+more\s*\]|show more|more replies|collapsed/i;
  var REPLY_PATTERN = /\breply\b/i;
  var EXPLICIT_HINT_PATTERN = /\b(parent|root|next|prev)\b/i;
  function resolveHintTarget(href, nodes) {
    if (!href) {
      return void 0;
    }
    const parsed = (() => {
      try {
        return new URL(href, "https://news.ycombinator.com");
      } catch {
        return null;
      }
    })();
    const fragment = parsed?.hash ? parsed.hash.slice(1) : "";
    const idParam = parsed?.searchParams.get("id") ?? "";
    return nodes.find((node) => {
      const sourceId = node.metadata?.sourceElementId;
      return Boolean(sourceId && (sourceId === fragment || sourceId === idParam));
    })?.id;
  }
  function collectThreadMetadata(region, nodes) {
    const nodeElementMap = buildRegionNodeElementMap(region);
    const collapsedBranchIds = /* @__PURE__ */ new Set();
    const explicitHints = [];
    let hasReplyAffordance = false;
    for (const node of nodes) {
      const elements = nodeElementMap.get(node.id) ?? [];
      const rowText = textForElements(elements);
      if (COLLAPSED_BRANCH_PATTERN.test(rowText)) {
        collapsedBranchIds.add(node.id);
      }
      if (REPLY_PATTERN.test(rowText)) {
        hasReplyAffordance = true;
      }
      const links = elements.flatMap((element) => Array.from(element.querySelectorAll("a[href]")));
      for (const link of links) {
        const text = (link.textContent ?? "").trim().toLowerCase();
        const kind = text.match(EXPLICIT_HINT_PATTERN)?.[1];
        if (!kind) {
          continue;
        }
        const targetNodeId = resolveHintTarget(link.getAttribute("href") ?? link.href, nodes);
        const hint = {
          nodeId: node.id,
          kind,
          href: link.getAttribute("href") ?? link.href
        };
        if (targetNodeId) {
          hint.targetNodeId = targetNodeId;
        }
        explicitHints.push(hint);
      }
    }
    return {
      kind: "thread",
      hasCollapsedBranches: collapsedBranchIds.size > 0,
      collapsedBranchIds: [...collapsedBranchIds],
      explicitHints,
      hasReplyAffordance
    };
  }
  function applyExplicitThreadHints(region, metadata) {
    const nodes = region.nodes.map((node) => ({ ...node }));
    const byId = new Map(nodes.map((node) => [node.id, node]));
    for (const hint of metadata.explicitHints) {
      const node = byId.get(hint.nodeId);
      if (!node || !hint.targetNodeId) {
        continue;
      }
      if (hint.kind === "parent") {
        node.parentId = hint.targetNodeId;
        const parent = byId.get(hint.targetNodeId);
        if (parent) {
          node.depth = parent.depth + 1;
        }
      }
      if (hint.kind === "root") {
        if (!node.parentId) {
          node.parentId = hint.targetNodeId;
          const parent = byId.get(hint.targetNodeId);
          if (parent) {
            node.depth = parent.depth + 1;
          }
        }
      }
    }
    const corrected = {
      ...region,
      nodes,
      structure: rebuildStructure({
        ...region,
        nodes
      })
    };
    return corrected;
  }
  var ThreadNormalizer = class {
    canNormalize(region) {
      return region.primitive === "repeated-item" && region.subtype === "nested" && region.layoutRole === "main-content";
    }
    normalize(input) {
      const commentNodes = input.semanticRegion.nodes.filter((node) => node.kind === "comment");
      const metadata = collectThreadMetadata(input.region, commentNodes);
      const correctedRegion = applyExplicitThreadHints(input.semanticRegion, metadata);
      return {
        region: correctedRegion,
        metadata
      };
    }
  };

  // src/content/semantic/core/normalization/ArticleNormalizer.ts
  var RELATED_LABEL_PATTERN = /\brelated|see also|more|further reading\b/i;
  function splitNodeEntries(node) {
    const newlineEntries = node.text.split(/\n+/).map((part) => normalizeText(part)).filter(Boolean);
    if (newlineEntries.length > 1) {
      return newlineEntries;
    }
    if (newlineEntries[0] && newlineEntries[0].length <= 64 && node.type !== "heading" && !/[.!?:]/.test(newlineEntries[0])) {
      const tokenEntries = newlineEntries[0].split(/\s+/).map((part) => normalizeText(part)).filter(Boolean);
      if (tokenEntries.length >= 2 && tokenEntries.length <= 8) {
        return tokenEntries;
      }
    }
    return newlineEntries;
  }
  function collectFilteredNodeIds(nodes) {
    const excludedNodeIds = /* @__PURE__ */ new Set();
    const tags = /* @__PURE__ */ new Set();
    const separatedNavigation = /* @__PURE__ */ new Set();
    for (const [index, node] of nodes.entries()) {
      const entries = splitNodeEntries(node);
      const previousNode = nodes[index - 1];
      if ((node.type === "list" || node.type === "link") && previousNode?.type === "heading" && RELATED_LABEL_PATTERN.test(previousNode.text)) {
        excludedNodeIds.add(previousNode.id);
        excludedNodeIds.add(node.id);
        for (const entry of entries) {
          separatedNavigation.add(entry);
        }
        continue;
      }
      if ((node.type === "list" || node.type === "link") && entries.length >= 2 && entries.length <= 8 && entries.every((entry) => entry.length <= 24)) {
        excludedNodeIds.add(node.id);
        for (const entry of entries) {
          tags.add(entry);
        }
        continue;
      }
      if (node.type === "heading" && RELATED_LABEL_PATTERN.test(node.text)) {
        const nextNode = nodes[index + 1];
        if (nextNode && (nextNode.type === "list" || nextNode.type === "link")) {
          excludedNodeIds.add(node.id);
          excludedNodeIds.add(nextNode.id);
          for (const entry of splitNodeEntries(nextNode)) {
            separatedNavigation.add(entry);
          }
        }
      }
    }
    return {
      excludedNodeIds,
      tags: [...tags],
      separatedNavigation: [...separatedNavigation]
    };
  }
  function buildArticleSections(nodes) {
    const sections = [];
    const headingNodes = nodes.filter((node) => node.type === "heading");
    const byId = new Map(nodes.map((node) => [node.id, node]));
    for (const heading of headingNodes) {
      const nodeIds = nodes.filter((node) => node.id === heading.id || node.parentId === heading.id).map((node) => node.id);
      sections.push({
        id: heading.id,
        title: heading.text,
        ...heading.level ? { level: heading.level } : {},
        ...heading.parentId ? { parentId: heading.parentId } : {},
        nodeIds
      });
    }
    if (sections.length === 0 && nodes.length > 0) {
      sections.push({
        id: nodes[0].id,
        title: nodes[0].text,
        nodeIds: nodes.map((node) => node.id)
      });
    }
    return sections.map((section) => ({
      ...section,
      nodeIds: section.nodeIds.filter((nodeId) => byId.has(nodeId))
    }));
  }
  var ArticleNormalizer = class {
    canNormalize(region) {
      return region.primitive === "authored-block" && region.layoutRole === "main-content";
    }
    normalize(input) {
      const baseNodes = input.semanticRegion.nodes.filter((node) => node.kind === "content");
      const { excludedNodeIds, tags, separatedNavigation } = collectFilteredNodeIds(baseNodes);
      const keepIds = new Set(baseNodes.filter((node) => !excludedNodeIds.has(node.id)).map((node) => node.id));
      const filteredRegion = filterRegionNodes(input.semanticRegion, keepIds);
      const normalizedNodes = applyHeadingHierarchyToContentNodes(
        filteredRegion.nodes.filter((node) => node.kind === "content")
      );
      const region = {
        ...filteredRegion,
        nodes: normalizedNodes,
        structure: {
          type: "sequence",
          rootIds: normalizedNodes.filter((node) => !node.parentId).map((node) => node.id)
        }
      };
      return {
        region,
        metadata: {
          kind: "article",
          sections: buildArticleSections(normalizedNodes),
          tags,
          separatedNavigation
        }
      };
    }
  };

  // src/content/semantic/core/normalization/CardNormalizer.ts
  function learnTemplate(region) {
    const items = (region.assembledItems ?? []).slice(0, 3);
    const title = items.some((item) => item.element.querySelector("h1,h2,h3,h4,h5,h6")) ? "first-heading" : items.some((item) => item.element.querySelector("a[href]")) ? "first-link" : "first-strong";
    const image = items.some((item) => item.element.querySelector("img,picture")) ? "first-image" : "background";
    const metadata = items.some((item) => item.companions.length > 0) ? "bottom" : items.some((item) => item.element.querySelector("time,.meta,.subtext,[class*='meta'],[class*='subtext']")) ? "after-title" : "none";
    const cta = items.some((item) => item.element.querySelector("button")) ? "last-button" : items.some((item) => item.element.querySelector("a[href]")) ? "last-link" : "none";
    return {
      title,
      image,
      metadata,
      cta
    };
  }
  var CardNormalizer = class {
    canNormalize(region) {
      return region.primitive === "repeated-item" && (region.subtype === "flat" || region.subtype === "grid") && (region.assembledItems?.length ?? 0) >= 3;
    }
    normalize(input) {
      const template = learnTemplate(input.region);
      const nodes = input.semanticRegion.nodes.map((node) => {
        if (node.kind !== "content") {
          return node;
        }
        const nextNode = {
          ...node,
          attributes: {
            ...node.attributes ?? {},
            normalizedTitle: template.title,
            normalizedImage: template.image,
            normalizedMetadata: template.metadata,
            normalizedCta: template.cta
          }
        };
        return nextNode;
      });
      return {
        region: {
          ...input.semanticRegion,
          nodes
        },
        metadata: {
          kind: "card",
          fieldTemplate: template
        }
      };
    }
  };

  // src/content/semantic/core/observability/PipelineLogger.ts
  var PipelineLogger = class {
    overlapResolutions = [];
    assemblyMerges = [];
    suppressions = [];
    reset() {
      this.overlapResolutions.length = 0;
      this.assemblyMerges.length = 0;
      this.suppressions.length = 0;
    }
    recordOverlapResolutions(raw, accepted) {
      const winnersByElement = /* @__PURE__ */ new Map();
      for (const region of accepted) {
        winnersByElement.set(region.element, region);
      }
      for (const region of raw) {
        const winner = winnersByElement.get(region.element);
        if (!winner || winner.id === region.id) {
          continue;
        }
        this.overlapResolutions.push(
          `deduped ${region.id} (${region.primitive}) in favor of ${winner.id} (${winner.primitive}) on the same anchor element`
        );
      }
    }
    recordContainment(regions) {
      for (const region of regions) {
        if (!region.parentId) {
          continue;
        }
        this.overlapResolutions.push(
          `kept ${region.id} (${region.primitive}) nested under ${region.parentId} after containment resolution`
        );
      }
    }
    recordAssembly(decisions) {
      this.assemblyMerges.push(...decisions);
    }
    recordSuppressions(decisions) {
      this.suppressions.push(...decisions);
    }
    snapshot() {
      return {
        overlapResolutions: [...this.overlapResolutions],
        assemblyMerges: [...this.assemblyMerges],
        suppressions: [...this.suppressions]
      };
    }
  };

  // src/content/semantic/core/observability/RegionDumper.ts
  function toBoundingRect(rect) {
    return {
      top: rect.top,
      left: rect.left,
      right: rect.right,
      bottom: rect.bottom,
      width: rect.width,
      height: rect.height,
      x: rect.x,
      y: rect.y
    };
  }
  function textLengthForNode(node) {
    if ("text" in node) {
      return node.text.length;
    }
    return (node.label ?? node.valuePreview ?? "").length;
  }
  var RegionDumper = class {
    build(input) {
      return {
        url: input.url,
        timestamp: input.timestamp,
        regions: input.regions.map((region) => {
          const expanded = input.expandRegion(region.id);
          const state = input.getState(region.id);
          const rect = region.element.getBoundingClientRect();
          return {
            id: region.id,
            primitive: region.primitive,
            ...region.subtype ? { subtype: region.subtype } : {},
            category: region.category,
            layoutRole: region.layoutRole,
            dominanceScore: region.dominanceScore,
            roleRank: region.roleRank,
            suppressed: region.suppressed,
            autoSuppressed: region.autoSuppressed,
            explicitSelectionAllowed: region.explicitSelectionAllowed,
            confidence: region.confidence,
            signals: [...region.signals],
            nodeCount: expanded?.nodes.length ?? 0,
            textLength: expanded?.nodes.reduce((sum, node) => sum + textLengthForNode(node), 0) ?? 0,
            assembledItemCount: state?.assembled.assembledItems?.length ?? 0,
            ...state?.normalized?.kind ? { normalizedKind: state.normalized.kind } : {},
            boundingRect: toBoundingRect(rect)
          };
        }),
        decisions: input.decisions
      };
    }
  };

  // src/content/semantic/core/pipeline/SemanticPipeline.ts
  var SemanticPipeline = class {
    constructor(recognizers = createDefaultRecognizers()) {
      this.recognizers = recognizers;
    }
    astBuilder = new SemanticASTBuilder();
    repeatedItemAssembler = new RepeatedItemAssembler();
    layoutRoleAssigner = new LayoutRoleAssigner();
    logger = new PipelineLogger();
    regionDumper = new RegionDumper();
    normalizers = [
      new ThreadNormalizer(),
      new ArticleNormalizer(),
      new CardNormalizer()
    ];
    state = /* @__PURE__ */ new Map();
    reset() {
      this.state.clear();
      this.logger.reset();
    }
    build(document2) {
      this.reset();
      const raw = this.recognizers.flatMap((recognizer) => recognizer.detectDetailed(document2));
      const detected = dedupeRegions(raw);
      this.logger.recordOverlapResolutions(raw, detected);
      assignContainment(detected);
      this.logger.recordContainment(detected);
      const assembled = detected.map((region) => {
        const result = this.repeatedItemAssembler.assembleDetailed(region);
        this.logger.recordAssembly(result.decisions);
        return result.region;
      });
      const layoutResult = this.layoutRoleAssigner.assignDetailed(assembled);
      this.logger.recordSuppressions(layoutResult.suppressions);
      const roled = layoutResult.regions;
      for (const region of roled) {
        this.state.set(region.id, {
          assembled: region,
          layout: region
        });
      }
      return {
        regions: roled
      };
    }
    getRegion(regionId) {
      return this.state.get(regionId)?.layout ?? null;
    }
    getState(regionId) {
      return this.state.get(regionId) ?? null;
    }
    createRegionDump(document2) {
      const regions = [...this.state.values()].map((entry) => entry.layout);
      return this.regionDumper.build({
        url: document2.location.href,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        regions,
        expandRegion: (regionId) => this.expandRegion(regionId, document2),
        getState: (regionId) => this.getState(regionId),
        decisions: this.logger.snapshot()
      });
    }
    expandRegion(regionId, document2) {
      const state = this.state.get(regionId);
      if (!state) {
        return null;
      }
      const recognizer = this.recognizers.find((candidate) => candidate.primitive === state.layout.primitive);
      if (!recognizer) {
        return null;
      }
      const baseRegion = recognizer.extractDetailed(state.layout, document2);
      const ast = this.astBuilder.build(state.layout.element);
      const normalizer = this.normalizers.find((candidate) => candidate.canNormalize(state.layout));
      if (!normalizer) {
        return baseRegion;
      }
      const result = normalizer.normalize({
        region: state.layout,
        semanticRegion: baseRegion,
        ast,
        document: document2
      });
      state.normalized = result.metadata;
      return result.region;
    }
  };

  // src/content/semantic/generic-semantic-extractor.ts
  function annotationPriority(region) {
    if (region.primitive === "authored-block") {
      return 0;
    }
    if (region.primitive === "navigation-cluster") {
      return 1;
    }
    if (region.primitive === "repeated-item") {
      return 2;
    }
    if (region.primitive === "interactive-block") {
      return 3;
    }
    return 0;
  }
  var GenericSemanticExtractor = class {
    id = "generic-semantic";
    recognizers = createDefaultRecognizers();
    pipeline = new SemanticPipeline(this.recognizers);
    enhancers = [new HackerNewsEnhancer(), new DocsEnhancer(), new SearchEnhancer()];
    regionIndex = /* @__PURE__ */ new Map();
    lastPage = null;
    match(_url, _document) {
      return true;
    }
    describePage(document2, url) {
      return this.lastPage ?? buildPageDescription(document2, url, [...this.regionIndex.values()]);
    }
    buildSkeleton(document2) {
      clearSemanticNodeAttributes(document2);
      this.pipeline.reset();
      this.regionIndex.clear();
      const { regions } = this.pipeline.build(document2);
      for (const region of regions) {
        this.regionIndex.set(region.id, region);
      }
      this.lastPage = buildPageDescription(document2, document2.location?.href ?? "https://unknown.local", regions);
      let skeleton = {
        version: 0,
        pageType: this.lastPage.kind,
        regions: regions.map((region) => createRegionRef(region, document2.body)),
        anchors: new Map(regions.map((region) => [region.id, createRegionRef(region, document2.body).anchor]))
      };
      skeleton = this.applySkeletonEnhancers(skeleton, document2);
      const annotationRefs = [...skeleton.regions].sort((left, right) => {
        const leftRegion = this.regionIndex.get(left.id);
        const rightRegion = this.regionIndex.get(right.id);
        const leftPriority = leftRegion ? annotationPriority(leftRegion) : 0;
        const rightPriority = rightRegion ? annotationPriority(rightRegion) : 0;
        return leftPriority - rightPriority;
      });
      for (const regionRef of annotationRefs) {
        const region = this.regionIndex.get(regionRef.id);
        if (!region) {
          continue;
        }
        region.category = regionRef.category;
        if (regionRef.parentId) {
          region.parentId = regionRef.parentId;
        } else {
          delete region.parentId;
        }
        region.displayLabel = regionRef.displayLabel ?? region.displayLabel;
        if (regionRef.subtype) {
          region.subtype = regionRef.subtype;
        } else {
          delete region.subtype;
        }
        annotateRegionNodes2(region);
      }
      return skeleton;
    }
    expandRegion(region, document2) {
      const detected = this.regionIndex.get(region.id);
      if (!detected) {
        return {
          id: region.id,
          kind: region.kind,
          primitive: region.primitive,
          ...region.subtype ? { subtype: region.subtype } : {},
          category: region.category,
          nodes: []
        };
      }
      const expanded = this.pipeline.expandRegion(region.id, document2);
      if (!expanded) {
        return {
          id: region.id,
          kind: region.kind,
          primitive: region.primitive,
          ...region.subtype ? { subtype: region.subtype } : {},
          category: region.category,
          nodes: []
        };
      }
      return this.applyRegionEnhancers(expanded, document2);
    }
    resolveFocus(document2, input) {
      const selectionElement = input.selection?.anchorNode instanceof Element ? input.selection.anchorNode : input.selection?.anchorNode?.parentElement ?? null;
      return this.resolveFromElement(document2, selectionElement, input, "selection") ?? this.resolveFromElement(document2, input.selectedElement ?? null, input, "selected") ?? this.resolveFromElement(document2, input.activeElement, input, "active") ?? this.resolveFromElement(document2, input.triggerTarget, input, "trigger") ?? this.resolveFromElement(document2, input.lastHoveredElement ?? null, input, "hover") ?? this.getFallbackFocus(document2, input);
    }
    isStructuralMutation(mutation) {
      return mutation.type === "childList" && (mutation.addedNodes.length > 0 || mutation.removedNodes.length > 0);
    }
    onNavigate(url, prevUrl) {
      const nextKey = `${url.origin}${url.pathname}${url.search}`;
      const prevKey = `${prevUrl.origin}${prevUrl.pathname}${prevUrl.search}`;
      return nextKey === prevKey ? "ignore" : "rebuild";
    }
    refineSelectionTarget(selection, document2) {
      return this.applySelectionEnhancers(selection, document2);
    }
    dumpObservability(document2) {
      return this.pipeline.createRegionDump(document2);
    }
    resolveFromElement(document2, element, input, mode) {
      const target = elementToNodeTarget(element);
      if (!target?.regionId) {
        return null;
      }
      const detected = this.regionIndex.get(target.regionId);
      if (!detected) {
        return null;
      }
      if (isRegionSuppressed(detected) && !shouldAllowSuppressedFocus(input.source, mode)) {
        return null;
      }
      const regionRef = createRegionRef(detected, document2.body);
      const region = this.expandRegion(regionRef, document2);
      return toFocusResult(region, target.nodeId);
    }
    getFallbackFocus(document2, input) {
      const regions = [...this.regionIndex.values()].filter((region) => !isRegionSuppressed(region) || shouldAllowSuppressedFocus(input.source, "fallback")).sort(sortRegionsForFallback);
      for (const region of regions) {
        const expanded = this.expandRegion(createRegionRef(region, document2.body), document2);
        const node = firstMeaningfulNode(expanded);
        if (!node) {
          continue;
        }
        return {
          regionId: expanded.id,
          nodeId: node.id,
          node
        };
      }
      return null;
    }
    buildEnhancerContext(document2) {
      return {
        url: new URL(document2.location?.href ?? "https://unknown.local"),
        document: document2
      };
    }
    getActiveEnhancers(document2) {
      const context = this.buildEnhancerContext(document2);
      return this.enhancers.filter((enhancer) => enhancer.match(context.url, context.document));
    }
    applySkeletonEnhancers(skeleton, document2) {
      const context = this.buildEnhancerContext(document2);
      return this.getActiveEnhancers(document2).reduce(
        (current, enhancer) => enhancer.refineSkeleton?.(current, context) ?? current,
        skeleton
      );
    }
    applyRegionEnhancers(region, document2) {
      const context = this.buildEnhancerContext(document2);
      return this.getActiveEnhancers(document2).reduce(
        (current, enhancer) => enhancer.refineRegion?.(current, context) ?? current,
        region
      );
    }
    applySelectionEnhancers(selection, document2) {
      const context = this.buildEnhancerContext(document2);
      return this.getActiveEnhancers(document2).reduce(
        (current, enhancer) => enhancer.refineSelection?.(current, context) ?? current,
        selection
      );
    }
  };

  // src/content/semantic/skeleton-builder.ts
  var SkeletonBuilder = class {
    build(extractor, document2, version) {
      const skeleton = extractor.buildSkeleton(document2);
      skeleton.version = version;
      return skeleton;
    }
  };

  // src/content/semantic/skeleton-manager.ts
  var SkeletonManager = class {
    constructor(document2, window2) {
      this.document = document2;
      this.window = window2;
    }
    observer = null;
    invalidateTimer = null;
    applyAnchorAttributes(skeleton) {
      for (const region of skeleton.regions) {
        const anchor = region.anchor.deref();
        if (!anchor) {
          continue;
        }
        anchor.setAttribute("data-semantic-region", region.id);
        anchor.setAttribute("data-semantic-primitive", region.primitive);
        if (region.subtype) {
          anchor.setAttribute("data-semantic-subtype", region.subtype);
        } else {
          anchor.removeAttribute("data-semantic-subtype");
        }
        anchor.setAttribute("data-semantic-category", region.category);
        if (region.displayLabel) {
          anchor.setAttribute("data-semantic-display-label", region.displayLabel);
        } else {
          anchor.removeAttribute("data-semantic-display-label");
        }
      }
    }
    clearAnchorAttributes(skeleton) {
      for (const region of skeleton?.regions ?? []) {
        const anchor = region.anchor.deref();
        if (!anchor) {
          continue;
        }
        anchor.removeAttribute("data-semantic-region");
        anchor.removeAttribute("data-semantic-primitive");
        anchor.removeAttribute("data-semantic-subtype");
        anchor.removeAttribute("data-semantic-category");
        anchor.removeAttribute("data-semantic-display-label");
      }
    }
    clearDocumentSemanticAttributes() {
      const attributes = [
        "data-semantic-region",
        "data-semantic-primitive",
        "data-semantic-subtype",
        "data-semantic-category",
        "data-semantic-node-id",
        "data-semantic-node-kind",
        "data-semantic-scope-root-id",
        "data-semantic-display-label",
        "data-semantic-text-preview",
        "data-semantic-layout-role",
        "data-semantic-role-rank",
        "data-semantic-auto-suppressed"
      ];
      for (const element of Array.from(
        this.document.querySelectorAll("[data-semantic-region],[data-semantic-node-id]")
      )) {
        for (const attribute of attributes) {
          element.removeAttribute(attribute);
        }
      }
    }
    observe(extractor, skeleton, onInvalidate) {
      if (!this.document.body) {
        return;
      }
      this.observer = new MutationObserver((mutations) => {
        const structural = mutations.filter((mutation) => extractor.isStructuralMutation?.(mutation) !== false);
        if (structural.length === 0) {
          return;
        }
        const affected = this.findAffectedRegions(structural);
        if (affected.length === 0) {
          return;
        }
        if (this.invalidateTimer !== null) {
          this.window.clearTimeout(this.invalidateTimer);
        }
        this.invalidateTimer = this.window.setTimeout(() => {
          const validIds = new Set(skeleton.regions.map((region) => region.id));
          onInvalidate(affected.filter((regionId) => validIds.has(regionId)));
          this.invalidateTimer = null;
        }, 300);
      });
      this.observer.observe(this.document.body, {
        childList: true,
        subtree: true
      });
    }
    disconnect() {
      this.observer?.disconnect();
      this.observer = null;
      if (this.invalidateTimer !== null) {
        this.window.clearTimeout(this.invalidateTimer);
        this.invalidateTimer = null;
      }
    }
    findAffectedRegions(mutations) {
      const affected = /* @__PURE__ */ new Set();
      const elementConstructor = this.document.defaultView?.Element;
      if (!elementConstructor) {
        return [];
      }
      for (const mutation of mutations) {
        const candidates = [];
        if (mutation.target instanceof elementConstructor) {
          candidates.push(mutation.target);
        }
        for (const node of [...mutation.addedNodes, ...mutation.removedNodes]) {
          if (node instanceof elementConstructor) {
            candidates.push(node);
          }
        }
        for (const candidate of candidates) {
          const anchor = candidate.closest("[data-semantic-region]");
          const regionId = anchor?.getAttribute("data-semantic-region");
          if (regionId) {
            affected.add(regionId);
          }
          for (const descendant of candidate.querySelectorAll?.("[data-semantic-region]") ?? []) {
            const descendantRegionId = descendant.getAttribute("data-semantic-region");
            if (descendantRegionId) {
              affected.add(descendantRegionId);
            }
          }
        }
      }
      return [...affected];
    }
  };

  // src/content/semantic/session.ts
  var NAVIGATION_EVENT = "threadatlas:semantic-navigation";
  var HISTORY_PATCH_FLAG = "__threadatlasSemanticNavigationPatched__";
  function patchHistoryNavigation(win) {
    const historyWithFlag = win.history;
    if (historyWithFlag[HISTORY_PATCH_FLAG]) {
      return;
    }
    const wrap = (method) => {
      const original = win.history[method].bind(win.history);
      win.history[method] = ((...args) => {
        const result = original(...args);
        win.dispatchEvent(new Event(NAVIGATION_EVENT));
        return result;
      });
    };
    wrap("pushState");
    wrap("replaceState");
    historyWithFlag[HISTORY_PATCH_FLAG] = true;
  }
  function hasMeaningfulRegion(region) {
    return region.nodes.some((node) => {
      if ("text" in node) {
        return Boolean(node.text);
      }
      return Boolean(node.label || node.valuePreview);
    });
  }
  var SemanticCaptureSession = class {
    constructor(document2, window2, extractor) {
      this.document = document2;
      this.window = window2;
      this.extractor = extractor ?? new GenericSemanticExtractor();
      this.skeletonManager = new SkeletonManager(document2, window2);
    }
    focusResolver = new FocusResolver();
    skeletonBuilder = new SkeletonBuilder();
    skeletonManager;
    extractor;
    currentUrl = "";
    regionCache = /* @__PURE__ */ new Map();
    skeleton = null;
    versionCounter = 0;
    initialize() {
      patchHistoryNavigation(this.window);
      this.window.addEventListener("popstate", this.handleNavigation);
      this.window.addEventListener(NAVIGATION_EVENT, this.handleNavigation);
      this.rebuildForCurrentLocation();
    }
    dispose() {
      this.window.removeEventListener("popstate", this.handleNavigation);
      this.window.removeEventListener(NAVIGATION_EVENT, this.handleNavigation);
      this.skeletonManager.disconnect();
      this.skeletonManager.clearAnchorAttributes(this.skeleton);
    }
    getSkeleton() {
      return this.skeleton;
    }
    getRegionState(regionId) {
      return this.skeleton?.regions.find((region) => region.id === regionId)?.state ?? null;
    }
    getRegionElement(regionId) {
      return this.skeleton?.regions.find((region) => region.id === regionId)?.anchor.deref() ?? null;
    }
    getRegionCategory(regionId) {
      return this.skeleton?.regions.find((region) => region.id === regionId)?.category ?? null;
    }
    refineSelectionTarget(target) {
      const extractorWithRefiner = this.extractor;
      return extractorWithRefiner.refineSelectionTarget?.(target, this.document) ?? target;
    }
    captureSnapshot(input) {
      this.ensureNavigationState();
      if (!isSemanticCaptureSupportedUrl(this.window.location.href) || !this.skeleton) {
        return {
          snapshot: null,
          error: "Semantic snapshots are only supported on standard web pages."
        };
      }
      const focus = this.focusResolver.resolve(
        this.extractor,
        this.document,
        input ?? {
          source: "command",
          activeElement: this.document.activeElement,
          selection: this.window.getSelection(),
          triggerTarget: this.document.activeElement,
          selectedElement: null,
          lastHoveredElement: null
        }
      );
      if (!focus) {
        return {
          snapshot: null,
          error: "No semantic focus could be resolved on this page."
        };
      }
      const focusRegion = this.ensureRegion(focus.regionId);
      if (!focusRegion || !hasMeaningfulRegion(focusRegion)) {
        return {
          snapshot: null,
          error: "No meaningful semantic region could be extracted from this page."
        };
      }
      const snapshot = buildSemanticSnapshot({
        page: this.extractor.describePage(this.document, this.window.location.href),
        focusRegion,
        focusNodeId: focus.nodeId,
        extractorId: this.extractor.id,
        skeletonVersion: this.skeleton.version
      });
      return {
        snapshot,
        error: snapshot ? null : `Focus node ${focus.nodeId} could not be found in ${focus.regionId}.`
      };
    }
    dumpObservability() {
      this.ensureNavigationState();
      if (!this.skeleton) {
        return null;
      }
      const extractorWithDump = this.extractor;
      return extractorWithDump.dumpObservability?.(this.document) ?? null;
    }
    handleNavigation = () => {
      this.ensureNavigationState();
    };
    ensureNavigationState() {
      const nextUrl = this.window.location.href;
      if (!this.skeleton) {
        this.rebuildForCurrentLocation();
        return;
      }
      if (nextUrl === this.currentUrl) {
        return;
      }
      const behavior = this.extractor.onNavigate?.(new URL(nextUrl), new URL(this.currentUrl)) ?? "rebuild";
      if (behavior === "ignore") {
        this.currentUrl = nextUrl;
        return;
      }
      if (behavior === "update") {
        this.currentUrl = nextUrl;
        this.markRegionsStale(this.skeleton.regions.map((region) => region.id));
        return;
      }
      this.rebuildForCurrentLocation();
    }
    rebuildForCurrentLocation() {
      const nextUrl = this.window.location.href;
      this.skeletonManager.disconnect();
      this.skeletonManager.clearAnchorAttributes(this.skeleton);
      this.skeletonManager.clearDocumentSemanticAttributes();
      this.regionCache.clear();
      this.currentUrl = nextUrl;
      if (!isSemanticCaptureSupportedUrl(nextUrl)) {
        this.skeleton = null;
        return;
      }
      const skeleton = this.skeletonBuilder.build(this.extractor, this.document, this.versionCounter + 1);
      this.versionCounter += 1;
      this.skeleton = skeleton;
      this.skeletonManager.applyAnchorAttributes(skeleton);
      this.skeletonManager.observe(this.extractor, skeleton, (regionIds) => {
        this.markRegionsStale(regionIds);
      });
    }
    ensureRegion(regionId) {
      const regionRef = this.skeleton?.regions.find((region) => region.id === regionId);
      if (!regionRef) {
        return null;
      }
      const cached = this.regionCache.get(regionId);
      if (cached && regionRef.state === "fresh") {
        return cached;
      }
      const expanded = this.extractor.expandRegion(regionRef, this.document);
      regionRef.state = "fresh";
      regionRef.extractedAt = Date.now();
      this.regionCache.set(regionId, expanded);
      return expanded;
    }
    markRegionsStale(regionIds) {
      const targets = new Set(regionIds);
      for (const region of this.skeleton?.regions ?? []) {
        if (targets.has(region.id)) {
          region.state = "stale";
        }
      }
    }
  };

  // src/content/page-text-selection.ts
  function normalizeSelectionText(text) {
    return text.replace(/\s+/g, " ").trim();
  }
  function toPreview(text, maxLength = 140) {
    const normalized = normalizeSelectionText(text);
    if (normalized.length <= maxLength) {
      return normalized;
    }
    return `${normalized.slice(0, maxLength - 1).trimEnd()}\u2026`;
  }
  var PageTextSelectionBridge = class {
    constructor(document2, window2, onSelection, debounceMs = 120) {
      this.document = document2;
      this.window = window2;
      this.onSelection = onSelection;
      this.debounceMs = debounceMs;
    }
    debounceTimer = null;
    lastSignature = null;
    initialize() {
      this.document.addEventListener("selectionchange", this.handleSelectionChange);
    }
    dispose() {
      this.document.removeEventListener("selectionchange", this.handleSelectionChange);
      if (this.debounceTimer !== null) {
        this.window.clearTimeout(this.debounceTimer);
        this.debounceTimer = null;
      }
    }
    clearSelection() {
      const selection = this.window.getSelection();
      selection?.removeAllRanges();
      this.lastSignature = null;
    }
    handleSelectionChange = () => {
      if (this.debounceTimer !== null) {
        this.window.clearTimeout(this.debounceTimer);
      }
      this.debounceTimer = this.window.setTimeout(() => {
        this.debounceTimer = null;
        this.emitSelection();
      }, this.debounceMs);
    };
    emitSelection() {
      const selection = this.window.getSelection();
      if (!selection || selection.isCollapsed) {
        this.lastSignature = null;
        return;
      }
      const text = normalizeSelectionText(selection.toString());
      if (!text) {
        this.lastSignature = null;
        return;
      }
      const signature = `${text}:${selection.anchorOffset}:${selection.focusOffset}`;
      if (signature === this.lastSignature) {
        return;
      }
      this.lastSignature = signature;
      this.onSelection({
        hasSelection: true,
        textPreview: toPreview(text),
        timestamp: Date.now()
      });
    }
  };

  // src/content/content-semantic.ts
  var SELECTION_SCOPE_STYLE_ID = "threadatlas-selection-scope-style";
  var SELECTION_SCOPE_ROOT_CLASS = "threadatlas-selection-scope-root";
  var SELECTION_SCOPE_FOCUS_CLASS = "threadatlas-selection-scope-focus";
  var selectionScopeRootElement = null;
  var selectionScopeFocusElement = null;
  function nearestSemanticElement(node) {
    if (!node) {
      return null;
    }
    const element = node instanceof Element ? node : node.parentElement;
    return element?.closest("[data-semantic-node-id]") ?? element?.closest("[data-semantic-region]") ?? null;
  }
  function buildSemanticAncestorChain(element) {
    const chain = [];
    let current = element;
    while (current) {
      const semanticElement = current.closest("[data-semantic-node-id],[data-semantic-region]");
      if (!semanticElement || chain.includes(semanticElement)) {
        break;
      }
      chain.push(semanticElement);
      current = semanticElement.parentElement;
    }
    return chain;
  }
  function resolveSelectionCaptureElement(selection) {
    if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
      return null;
    }
    const range = selection.getRangeAt(0);
    const anchorElement = nearestSemanticElement(selection.anchorNode);
    const focusElement = nearestSemanticElement(selection.focusNode);
    if (anchorElement && focusElement) {
      if (anchorElement === focusElement) {
        return anchorElement;
      }
      const focusChain = new Set(buildSemanticAncestorChain(focusElement));
      for (const candidate of buildSemanticAncestorChain(anchorElement)) {
        if (focusChain.has(candidate)) {
          return candidate;
        }
      }
    }
    return nearestSemanticElement(range.commonAncestorContainer) ?? anchorElement ?? focusElement ?? null;
  }
  function capturePageTextSelectionSnapshot(session) {
    const selection = window.getSelection();
    const selectedElement = resolveSelectionCaptureElement(selection);
    if (!selection || selection.isCollapsed || !selectedElement) {
      return {
        snapshot: null,
        error: "No usable page selection could be resolved."
      };
    }
    return session.captureSnapshot({
      source: "sidepanel",
      activeElement: selectedElement,
      selection: null,
      triggerTarget: selectedElement,
      selectedElement,
      lastHoveredElement: selectedElement
    });
  }
  function ensureSelectionScopeStyles(document2) {
    if (document2.getElementById(SELECTION_SCOPE_STYLE_ID)) {
      return;
    }
    const style = document2.createElement("style");
    style.id = SELECTION_SCOPE_STYLE_ID;
    style.textContent = `
    .${SELECTION_SCOPE_ROOT_CLASS},
    .${SELECTION_SCOPE_FOCUS_CLASS} {
      transition:
        box-shadow 160ms ease,
        background-color 160ms ease,
        outline-color 160ms ease;
      scroll-margin-top: 96px;
    }

    .${SELECTION_SCOPE_ROOT_CLASS} {
      outline: 1px solid rgba(90, 114, 238, 0.24);
      background-color: rgba(90, 114, 238, 0.06);
      box-shadow: 0 0 0 6px rgba(90, 114, 238, 0.08);
      border-radius: 10px;
    }

    .${SELECTION_SCOPE_FOCUS_CLASS} {
      outline: 2px solid rgba(90, 114, 238, 0.9);
      background-color: rgba(90, 114, 238, 0.12);
      box-shadow: 0 0 0 8px rgba(90, 114, 238, 0.12);
      border-radius: 12px;
    }
  `;
    document2.head.appendChild(style);
  }
  function clearSelectionScopeHighlight() {
    selectionScopeRootElement?.classList.remove(SELECTION_SCOPE_ROOT_CLASS);
    selectionScopeFocusElement?.classList.remove(SELECTION_SCOPE_FOCUS_CLASS);
    selectionScopeRootElement = null;
    selectionScopeFocusElement = null;
  }
  function findSemanticElement(document2, regionId, nodeId) {
    if (!nodeId) {
      return document2.querySelector(`[data-semantic-region="${regionId}"]`);
    }
    return document2.querySelector(`[data-semantic-region="${regionId}"][data-semantic-node-id="${nodeId}"]`) ?? document2.querySelector(`[data-semantic-node-id="${nodeId}"]`);
  }
  function applySelectionScopeHighlight(payload) {
    clearSelectionScopeHighlight();
    ensureSelectionScopeStyles(document);
    const rootElement = findSemanticElement(document, payload.regionId, payload.rootNodeId);
    const focusElement = findSemanticElement(document, payload.regionId, payload.focusNodeId);
    if (rootElement) {
      rootElement.classList.add(SELECTION_SCOPE_ROOT_CLASS);
      selectionScopeRootElement = rootElement;
    }
    if (focusElement) {
      focusElement.classList.add(SELECTION_SCOPE_FOCUS_CLASS);
      selectionScopeFocusElement = focusElement;
    }
  }
  var pageAudioBridgeReadyPromise = null;
  var resolvePageAudioBridgeReady = null;
  var rejectPageAudioBridgeReady = null;
  function isClearPageTextSelectionMessage(message) {
    return message.type === "CLEAR_PAGE_TEXT_SELECTION";
  }
  function isCapturePageTextSelectionSnapshotMessage(message) {
    if (typeof message !== "object" || message === null) {
      return false;
    }
    return message.type === "CAPTURE_PAGE_TEXT_SELECTION_SNAPSHOT";
  }
  function isClearPageSelectionScopeHighlightMessage(message) {
    if (typeof message !== "object" || message === null) {
      return false;
    }
    return message.type === "CLEAR_PAGE_SELECTION_SCOPE_HIGHLIGHT";
  }
  function toApplyPageSelectionScopeHighlightPayload(message) {
    if (typeof message !== "object" || message === null) {
      return null;
    }
    const candidate = message;
    if (candidate.type !== "APPLY_PAGE_SELECTION_SCOPE_HIGHLIGHT" || typeof candidate.payload?.regionId !== "string" || typeof candidate.payload?.focusNodeId !== "string" || candidate.payload?.rootNodeId !== void 0 && candidate.payload?.rootNodeId !== null && typeof candidate.payload?.rootNodeId !== "string") {
      return null;
    }
    return {
      regionId: candidate.payload.regionId,
      focusNodeId: candidate.payload.focusNodeId,
      ...candidate.payload.rootNodeId !== void 0 ? { rootNodeId: candidate.payload.rootNodeId } : {}
    };
  }
  function toPageTextSelectionPayload(payload) {
    if (typeof payload !== "object" || payload === null) {
      return null;
    }
    const candidate = payload;
    if (typeof candidate.hasSelection !== "boolean" || typeof candidate.textPreview !== "string" || typeof candidate.timestamp !== "number") {
      return null;
    }
    return {
      hasSelection: candidate.hasSelection,
      textPreview: candidate.textPreview,
      timestamp: candidate.timestamp
    };
  }
  async function hydrateSelectionMode(triggerManager) {
    try {
      const state = await chrome.runtime.sendMessage({
        type: "GET_SEMANTIC_SELECTION_STATE"
      });
      if (state?.enabled && !triggerManager.getSelectionState().enabled) {
        triggerManager.toggleSelectionMode();
      }
    } catch {
    }
  }
  function initializeSemanticCapture() {
    if (window.__threadatlasSemanticCaptureInitialized__) {
      return;
    }
    const session = new SemanticCaptureSession(document, window);
    const browserCapture = new BrowserCapture(document, window);
    const regionHighlighter = new RegionHighlighter(document, window);
    const snapshotIndicator = new SnapshotIndicator(document, window);
    const pageTextSelectionBridge = new PageTextSelectionBridge(
      document,
      window,
      (payload) => {
        const normalizedPayload = toPageTextSelectionPayload(payload);
        if (!normalizedPayload) {
          return;
        }
        void chrome.runtime.sendMessage({
          type: "PAGE_TEXT_SELECTION_CHANGED",
          payload: normalizedPayload
        });
      }
    );
    const triggerManager = new TriggerManager(
      session,
      browserCapture,
      regionHighlighter,
      snapshotIndicator,
      (state, capture) => {
        void chrome.runtime.sendMessage({
          type: "SYNC_SEMANTIC_SELECTION_STATE",
          payload: {
            enabled: state.enabled,
            selectedTarget: state.selectedTarget,
            snapshot: capture?.snapshot ?? void 0,
            error: capture?.error ?? void 0
          }
        });
      }
    );
    session.initialize();
    browserCapture.initialize();
    pageTextSelectionBridge.initialize();
    ensurePageAudioBridge();
    window.__threadatlasSemanticCaptureSession__ = session;
    window.__threadatlasSemanticTriggerManager__ = triggerManager;
    window.__threadatlasPageTextSelectionBridge__ = pageTextSelectionBridge;
    window.__threadatlasSemanticCaptureInitialized__ = true;
    void hydrateSelectionMode(triggerManager);
    chrome.runtime.onMessage.addListener(
      (message, _sender, sendResponse) => {
        if (isCapturePageTextSelectionSnapshotMessage(message)) {
          sendResponse(capturePageTextSelectionSnapshot(session));
          return true;
        }
        if (message.type === "CAPTURE_SEMANTIC_SNAPSHOT") {
          void triggerManager.captureSnapshot(message.payload.source).then(sendResponse);
          return true;
        }
        if (message.type === "TOGGLE_SEMANTIC_SELECTION") {
          sendResponse(triggerManager.toggleSelectionMode());
          return true;
        }
        if (message.type === "GET_SEMANTIC_SELECTION_STATE") {
          sendResponse(triggerManager.getSelectionState());
          return true;
        }
        if (message.type === "GET_SEMANTIC_REGION_DUMP") {
          sendResponse({
            dump: session.dumpObservability()
          });
          return true;
        }
        if (message.type === "CLEAR_SEMANTIC_SELECTION") {
          sendResponse(triggerManager.clearSelection());
          return true;
        }
        if (isClearPageTextSelectionMessage(message)) {
          pageTextSelectionBridge.clearSelection();
          sendResponse({ ok: true });
          return true;
        }
        const selectionScopeHighlightPayload = toApplyPageSelectionScopeHighlightPayload(message);
        if (selectionScopeHighlightPayload) {
          applySelectionScopeHighlight(selectionScopeHighlightPayload);
          sendResponse({ ok: true });
          return true;
        }
        if (isClearPageSelectionScopeHighlightMessage(message)) {
          clearSelectionScopeHighlight();
          sendResponse({ ok: true });
          return true;
        }
        if (message.type === "START_PAGE_AUDIO_CAPTURE") {
          void waitForPageAudioBridgeReady().then(() => {
            sendPageAudioBridgeMessage("THREADATLAS_PAGE_AUDIO_START", message.payload);
            sendResponse({ ok: true });
          }).catch((error) => {
            sendResponse({
              ok: false,
              error: error instanceof Error ? error.message : "Voice input bridge failed to load on this page."
            });
          });
          return true;
        }
        if (message.type === "STOP_PAGE_AUDIO_CAPTURE") {
          sendPageAudioBridgeMessage("THREADATLAS_PAGE_AUDIO_STOP", message.payload);
          sendResponse({ ok: true });
          return true;
        }
        if (message.type === "CANCEL_PAGE_AUDIO_CAPTURE") {
          sendPageAudioBridgeMessage("THREADATLAS_PAGE_AUDIO_CANCEL", message.payload);
          sendResponse({ ok: true });
          return true;
        }
        return false;
      }
    );
  }
  function ensurePageAudioBridge() {
    window.removeEventListener("message", handlePageAudioBridgeMessage);
    window.addEventListener("message", handlePageAudioBridgeMessage);
    pageAudioBridgeReadyPromise = new Promise((resolve, reject) => {
      resolvePageAudioBridgeReady = resolve;
      rejectPageAudioBridgeReady = reject;
    });
    window.__threadatlasPageAudioBridgeReady__ = false;
    window.__threadatlasPageAudioBridgeFailed__ = false;
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("page-audio-bridge.js");
    script.async = false;
    script.dataset.threadatlasPageAudioBridge = "true";
    script.addEventListener("load", () => {
      script.remove();
    });
    script.addEventListener("error", () => {
      window.__threadatlasPageAudioBridgeFailed__ = true;
      window.__threadatlasPageAudioBridgeReady__ = false;
      rejectPageAudioBridgeReady?.(new Error("Voice input bridge failed to load on this page."));
      script.remove();
    });
    (document.head ?? document.documentElement).appendChild(script);
  }
  async function waitForPageAudioBridgeReady(timeoutMs = 1500) {
    if (window.__threadatlasPageAudioBridgeFailed__) {
      throw new Error("Voice input bridge failed to load on this page.");
    }
    if (window.__threadatlasPageAudioBridgeReady__) {
      return;
    }
    if (!pageAudioBridgeReadyPromise) {
      ensurePageAudioBridge();
    }
    await Promise.race([
      pageAudioBridgeReadyPromise,
      new Promise((_, reject) => {
        window.setTimeout(() => {
          reject(new Error("Voice input bridge is not ready on this page yet."));
        }, timeoutMs);
      })
    ]);
  }
  function sendPageAudioBridgeMessage(type, payload) {
    window.postMessage(
      {
        source: "threadatlas-content-audio",
        type,
        payload
      },
      "*"
    );
  }
  function handlePageAudioBridgeMessage(event) {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (!data || data.source !== "threadatlas-page-audio") {
      return;
    }
    if (data.type === "THREADATLAS_PAGE_AUDIO_READY") {
      window.__threadatlasPageAudioBridgeReady__ = true;
      window.__threadatlasPageAudioBridgeFailed__ = false;
      resolvePageAudioBridgeReady?.();
      resolvePageAudioBridgeReady = null;
      rejectPageAudioBridgeReady = null;
      void chrome.runtime.sendMessage({
        type: "PAGE_AUDIO_CAPTURE_READY",
        payload: {}
      });
      return;
    }
    if (data.type === "THREADATLAS_PAGE_AUDIO_STATE" && data.payload.state) {
      void chrome.runtime.sendMessage({
        type: "PAGE_AUDIO_CAPTURE_STATE_CHANGED",
        payload: {
          sessionId: data.payload.sessionId,
          state: data.payload.state,
          ...data.payload.detail ? { detail: data.payload.detail } : {}
        }
      });
      return;
    }
    if (data.type === "THREADATLAS_PAGE_AUDIO_CHUNK" && typeof data.payload.chunkBase64 === "string") {
      void chrome.runtime.sendMessage({
        type: "PAGE_AUDIO_CAPTURE_CHUNK",
        payload: {
          sessionId: data.payload.sessionId,
          chunkBase64: data.payload.chunkBase64
        }
      });
    }
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
    initializeSemanticCapture();
  }
})();
//# sourceMappingURL=content-semantic.js.map
