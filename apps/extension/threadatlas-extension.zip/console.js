"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../packages/shared/dist/types/api.js
  var require_api = __commonJS({
    "../../packages/shared/dist/types/api.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/auth-session.js
  var require_auth_session = __commonJS({
    "../../packages/shared/dist/types/auth-session.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/article.js
  var require_article = __commonJS({
    "../../packages/shared/dist/types/article.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context.js
  var require_context = __commonJS({
    "../../packages/shared/dist/types/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context-pack.js
  var require_context_pack = __commonJS({
    "../../packages/shared/dist/types/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/intent.js
  var require_intent = __commonJS({
    "../../packages/shared/dist/types/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/memory.js
  var require_memory = __commonJS({
    "../../packages/shared/dist/types/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/projection.js
  var require_projection = __commonJS({
    "../../packages/shared/dist/types/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantic-snapshot.js
  var require_semantic_snapshot = __commonJS({
    "../../packages/shared/dist/types/semantic-snapshot.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantics.js
  var require_semantics = __commonJS({
    "../../packages/shared/dist/types/semantics.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/state.js
  var require_state = __commonJS({
    "../../packages/shared/dist/types/state.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/thread.js
  var require_thread = __commonJS({
    "../../packages/shared/dist/types/thread.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/constants/limits.js
  var require_limits = __commonJS({
    "../../packages/shared/dist/constants/limits.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.MAX_ACTIVE_TOPICS = exports.MAX_CONTEXT_TURNS = exports.TOKEN_RENEWAL_BUFFER_SECONDS = exports.TOKEN_TTL_SECONDS = exports.TOOL_TIMEOUT_MS = exports.LOOP_TIMEOUT_MS = exports.MAX_LOOPS = void 0;
      exports.MAX_LOOPS = 8;
      exports.LOOP_TIMEOUT_MS = 3e4;
      exports.TOOL_TIMEOUT_MS = 1e4;
      exports.TOKEN_TTL_SECONDS = 600;
      exports.TOKEN_RENEWAL_BUFFER_SECONDS = 120;
      exports.MAX_CONTEXT_TURNS = 10;
      exports.MAX_ACTIVE_TOPICS = 10;
    }
  });

  // ../../packages/shared/dist/constants/defaults.js
  var require_defaults = __commonJS({
    "../../packages/shared/dist/constants/defaults.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.CONTEXT_LIMITS = exports.EMPTY_CONVERSATION_CONTEXT = exports.DEFAULT_API_BASE_URL = exports.DEFAULT_USER_ID = void 0;
      var limits_1 = require_limits();
      exports.DEFAULT_USER_ID = "user_sungwoo";
      exports.DEFAULT_API_BASE_URL = "http://localhost:8080";
      exports.EMPTY_CONVERSATION_CONTEXT = {
        turns: [],
        activeTopics: [],
        threadUrl: ""
      };
      exports.CONTEXT_LIMITS = {
        maxTurns: limits_1.MAX_CONTEXT_TURNS,
        maxActiveTopics: limits_1.MAX_ACTIVE_TOPICS
      };
    }
  });

  // ../../packages/shared/dist/utils/context.js
  var require_context2 = __commonJS({
    "../../packages/shared/dist/utils/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.trimTurns = trimTurns;
      exports.appendTurn = appendTurn;
      exports.setActiveTopics = setActiveTopics;
      var defaults_1 = require_defaults();
      function trimTurns(turns) {
        if (turns.length <= defaults_1.CONTEXT_LIMITS.maxTurns) {
          return turns;
        }
        return turns.slice(turns.length - defaults_1.CONTEXT_LIMITS.maxTurns);
      }
      function appendTurn(context, turn) {
        return {
          ...context,
          turns: trimTurns([...context.turns, turn])
        };
      }
      function setActiveTopics(context, topics) {
        return {
          ...context,
          activeTopics: topics.slice(0, defaults_1.CONTEXT_LIMITS.maxActiveTopics)
        };
      }
    }
  });

  // ../../packages/shared/dist/utils/hash.js
  var require_hash = __commonJS({
    "../../packages/shared/dist/utils/hash.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.hashUrl = hashUrl2;
      function intToFixedHex(value) {
        return (value >>> 0).toString(16).padStart(8, "0");
      }
      function hashUrl2(url) {
        let h1 = 2654435769;
        let h2 = 2246822507;
        for (let i = 0; i < url.length; i += 1) {
          const code = url.charCodeAt(i);
          h1 = Math.imul(h1 ^ code, 2246822519);
          h2 = Math.imul(h2 ^ code, 3266489917);
        }
        return `${intToFixedHex(h1)}${intToFixedHex(h2)}`.slice(0, 16);
      }
    }
  });

  // ../../packages/shared/dist/utils/context-pack.js
  var require_context_pack2 = __commonJS({
    "../../packages/shared/dist/utils/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = buildContextPack2;
      exports.selectProjectionView = selectProjectionView;
      exports.renderContextPack = renderContextPack2;
      exports.renderCompactJson = renderCompactJson2;
      exports.renderLinearText = renderLinearText2;
      function isCommentNode2(node) {
        return node.kind === "comment";
      }
      function isInteractiveNode2(node) {
        return node.kind === "interactive";
      }
      function toContextPackNode(node, relation, distance) {
        if (isCommentNode2(node)) {
          return {
            id: node.id,
            kind: "comment",
            relation,
            distance,
            text: node.text,
            ...node.author ? { author: node.author } : {},
            ...node.timestamp ? { timestamp: node.timestamp } : {},
            depth: node.depth,
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        if (isInteractiveNode2(node)) {
          return {
            id: node.id,
            kind: "interactive",
            relation,
            distance,
            text: node.label ?? node.valuePreview ?? "",
            controlType: node.controlType,
            ...node.action ? { action: node.action } : {},
            ...node.state ? { state: node.state } : {},
            ...node.role ? { role: node.role } : {},
            ...node.valuePreview ? { valuePreview: node.valuePreview } : {},
            ...node.label ? { label: node.label } : {},
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        return {
          id: node.id,
          kind: "content",
          relation,
          distance,
          text: node.text,
          contentType: node.type,
          ...node.level ? { level: node.level } : {},
          ...node.parentId ? { parentId: node.parentId } : {},
          ...node.attributes ? { metadata: node.attributes } : {}
        };
      }
      function mapSlices(snapshot, relation) {
        return snapshot.context.map((slice, originalIndex) => ({ slice, originalIndex })).filter(({ slice }) => slice.relation === relation).map(({ slice, originalIndex }) => ({
          ...toContextPackNode(slice.node, relation === "child" ? "descendant" : relation === "container" ? "container" : relation === "sibling" ? "sibling" : "ancestor", slice.distance),
          originalIndex
        }));
      }
      function buildOmitted(snapshot) {
        const coverage = snapshot.meta.coverage;
        if (!coverage) {
          return {
            nodeCount: 0,
            rootCount: 0,
            note: "Coverage metadata unavailable."
          };
        }
        return {
          nodeCount: coverage.omittedNodeCount,
          rootCount: coverage.omittedRootCount,
          note: `Only the ${coverage.kind} semantic scope is included.`
        };
      }
      function buildScope(snapshot) {
        const coverage = snapshot.meta.coverage;
        return {
          kind: coverage?.kind ?? (isCommentNode2(snapshot.focus.node) ? "focus-branch" : "focus-section"),
          rootNodeId: coverage?.rootNodeId ?? snapshot.focus.nodeId,
          focusNodeId: snapshot.focus.nodeId
        };
      }
      function buildProjectionFocusNode(pack) {
        const { metadata: _metadata, relation: _relation, distance: _distance, ...focus } = pack.focus;
        return focus;
      }
      function includeByProfile(node, group, profile) {
        if (group === "containers") {
          return false;
        }
        if (profile === "branch-summary") {
          return true;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        if (group === "ancestors") {
          return node.distance === 1;
        }
        if (group === "descendants") {
          return node.distance === 1;
        }
        if (group === "siblings") {
          return node.distance === 1;
        }
        return false;
      }
      function formatNodeSummary(node) {
        const headerParts = [
          node.author,
          node.timestamp,
          node.kind === "interactive" && node.controlType ? node.controlType : null,
          node.kind === "interactive" && node.action ? node.action : null,
          node.kind === "interactive" && node.state ? node.state : null,
          node.kind === "content" && node.contentType ? node.contentType : null
        ].filter(Boolean);
        if (headerParts.length === 0) {
          return `- ${node.text || node.valuePreview || "(empty)"}`;
        }
        return `- ${headerParts.join(", ")}: ${node.text || node.valuePreview || "(empty)"}`;
      }
      function buildContextPack2(snapshot) {
        const ancestors = [
          ...mapSlices(snapshot, "parent"),
          ...mapSlices(snapshot, "ancestor")
        ].sort((left, right) => right.distance - left.distance || left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const descendants = mapSlices(snapshot, "child").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const siblings = mapSlices(snapshot, "sibling").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const containers = mapSlices(snapshot, "container").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        return {
          version: 1,
          scope: buildScope(snapshot),
          page: {
            id: snapshot.page.id,
            url: snapshot.page.url,
            ...snapshot.page.title ? { title: snapshot.page.title } : {},
            kind: snapshot.page.kind,
            ...snapshot.page.metadata ? { metadata: snapshot.page.metadata } : {}
          },
          focus: toContextPackNode(snapshot.focus.node, "focus", 0),
          groups: {
            ancestors,
            descendants,
            siblings,
            containers
          },
          omitted: buildOmitted(snapshot),
          provenance: {
            extractorId: snapshot.meta.extractorId,
            capturedAt: snapshot.meta.capturedAt,
            skeletonVersion: snapshot.meta.skeletonVersion
          }
        };
      }
      function selectProjectionView(pack, profile) {
        const groups = {
          ancestors: pack.groups.ancestors.filter((node) => includeByProfile(node, "ancestors", profile)),
          descendants: pack.groups.descendants.filter((node) => includeByProfile(node, "descendants", profile)),
          siblings: pack.groups.siblings.filter((node) => includeByProfile(node, "siblings", profile)),
          containers: pack.groups.containers.filter((node) => includeByProfile(node, "containers", profile))
        };
        return {
          scope: pack.scope,
          page: {
            ...pack.page.title ? { title: pack.page.title } : {},
            url: pack.page.url,
            kind: pack.page.kind
          },
          focus: buildProjectionFocusNode(pack),
          groups,
          omitted: pack.omitted,
          provenance: {
            extractorId: pack.provenance.extractorId,
            capturedAt: pack.provenance.capturedAt
          }
        };
      }
      function renderContextPack2(pack) {
        return JSON.stringify(pack, null, 2);
      }
      function renderCompactJson2(pack, profile) {
        return JSON.stringify(selectProjectionView(pack, profile), null, 2);
      }
      function renderLinearText2(pack, profile) {
        const view = selectProjectionView(pack, profile);
        const lines = [
          `Page: ${view.page.title ?? "(untitled)"}`,
          `URL: ${view.page.url}`,
          `Kind: ${view.page.kind}`,
          `Scope: ${view.scope.kind}`,
          ""
        ];
        const sections = [
          ["Ancestors", view.groups.ancestors],
          ["Focus", [pack.focus]],
          ["Descendants", view.groups.descendants],
          ["Siblings", view.groups.siblings]
        ];
        for (const [label, nodes] of sections) {
          const groupKey = label === "Ancestors" ? "ancestors" : label === "Descendants" ? "descendants" : label === "Siblings" ? "siblings" : null;
          if (groupKey && !projectionIncludesGroup(profile, groupKey)) {
            continue;
          }
          lines.push(label);
          if (nodes.length === 0) {
            lines.push("- none");
          } else {
            for (const node of nodes) {
              lines.push(formatNodeSummary(node));
            }
          }
          lines.push("");
        }
        lines.push("Omitted");
        lines.push(`- ${view.omitted.nodeCount} nodes omitted`);
        lines.push(`- ${view.omitted.rootCount} roots omitted`);
        lines.push(`- ${view.omitted.note}`);
        return lines.join("\n");
      }
      function projectionIncludesGroup(profile, group) {
        if (group === "containers") {
          return false;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        return true;
      }
    }
  });

  // ../../packages/shared/dist/factories/intent.js
  var require_intent2 = __commonJS({
    "../../packages/shared/dist/factories/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createUserSpeechIntent = createUserSpeechIntent;
      exports.createUserSelectionIntent = createUserSelectionIntent;
      exports.createPageNavigationIntent = createPageNavigationIntent;
      function createUserSpeechIntent(transcript, intentType = "general") {
        return {
          type: "UserSpeech",
          transcript,
          intentType
        };
      }
      function createUserSelectionIntent(transcript) {
        return {
          type: "UserSelection",
          transcript,
          intentType: "memory_query"
        };
      }
      function createPageNavigationIntent(transcript) {
        return {
          type: "PageNavigation",
          transcript,
          intentType: "navigation_request"
        };
      }
    }
  });

  // ../../packages/shared/dist/factories/memory.js
  var require_memory2 = __commonJS({
    "../../packages/shared/dist/factories/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createEmptyInterestProfile = createEmptyInterestProfile;
      exports.createMemoryDelta = createMemoryDelta;
      exports.mergeTopicDeltas = mergeTopicDeltas;
      function createEmptyInterestProfile() {
        return {
          topics: {},
          updatedAt: Date.now()
        };
      }
      function createMemoryDelta(topicDeltas, highlights = []) {
        return {
          interestProfile: { topicDeltas },
          threadHistory: {
            highlights,
            turnCountDelta: 1
          }
        };
      }
      function mergeTopicDeltas(base, incoming) {
        const merged = { ...base };
        for (const [topic, count] of Object.entries(incoming)) {
          merged[topic] = (merged[topic] ?? 0) + count;
        }
        return merged;
      }
    }
  });

  // ../../packages/shared/dist/factories/projection.js
  var require_projection2 = __commonJS({
    "../../packages/shared/dist/factories/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.respond = respond;
      exports.focus = focus;
      exports.focusMultiple = focusMultiple;
      exports.navigate = navigate;
      exports.present = present;
      exports.notify = notify;
      exports.copy = copy;
      function respond(text, mode = "answer") {
        return { type: "respond", payload: { text, mode } };
      }
      function focus(commentId, options) {
        if (options) {
          return { type: "focus", payload: { commentId, options } };
        }
        return { type: "focus", payload: { commentId } };
      }
      function focusMultiple(targets, options) {
        if (options) {
          return { type: "focusMultiple", payload: { targets, options } };
        }
        return { type: "focusMultiple", payload: { targets } };
      }
      function navigate(url, options) {
        if (options) {
          return { type: "navigate", payload: { url, options } };
        }
        return { type: "navigate", payload: { url } };
      }
      function present(target, content, persistent = false) {
        return {
          type: "present",
          payload: {
            target,
            content,
            options: { persistent }
          }
        };
      }
      function notify(message, level = "info") {
        return {
          type: "notify",
          payload: { message, level }
        };
      }
      function copy(text) {
        return { type: "copy", payload: { text } };
      }
    }
  });

  // ../../packages/shared/dist/domain.js
  var require_domain = __commonJS({
    "../../packages/shared/dist/domain.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = void 0;
      __exportStar(require_api(), exports);
      __exportStar(require_auth_session(), exports);
      __exportStar(require_article(), exports);
      __exportStar(require_context(), exports);
      __exportStar(require_context_pack(), exports);
      __exportStar(require_intent(), exports);
      __exportStar(require_memory(), exports);
      __exportStar(require_projection(), exports);
      __exportStar(require_semantic_snapshot(), exports);
      __exportStar(require_semantics(), exports);
      __exportStar(require_state(), exports);
      __exportStar(require_thread(), exports);
      __exportStar(require_defaults(), exports);
      __exportStar(require_limits(), exports);
      __exportStar(require_context2(), exports);
      __exportStar(require_hash(), exports);
      var context_pack_1 = require_context_pack2();
      Object.defineProperty(exports, "buildContextPack", { enumerable: true, get: function() {
        return context_pack_1.buildContextPack;
      } });
      __exportStar(require_intent2(), exports);
      __exportStar(require_memory2(), exports);
      __exportStar(require_projection2(), exports);
    }
  });

  // ../../packages/shared/dist/index.js
  var require_dist = __commonJS({
    "../../packages/shared/dist/index.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      __exportStar(require_domain(), exports);
    }
  });

  // ../../packages/shared/dist/types/context-projection.js
  var require_context_projection = __commonJS({
    "../../packages/shared/dist/types/context-projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/projection-policy.js
  var require_projection_policy = __commonJS({
    "../../packages/shared/dist/projection-policy.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.selectProjectionView = exports.renderLinearText = exports.renderContextPack = exports.renderCompactJson = void 0;
      __exportStar(require_context_projection(), exports);
      var context_pack_1 = require_context_pack2();
      Object.defineProperty(exports, "renderCompactJson", { enumerable: true, get: function() {
        return context_pack_1.renderCompactJson;
      } });
      Object.defineProperty(exports, "renderContextPack", { enumerable: true, get: function() {
        return context_pack_1.renderContextPack;
      } });
      Object.defineProperty(exports, "renderLinearText", { enumerable: true, get: function() {
        return context_pack_1.renderLinearText;
      } });
      Object.defineProperty(exports, "selectProjectionView", { enumerable: true, get: function() {
        return context_pack_1.selectProjectionView;
      } });
    }
  });

  // src/sidepanel/index.ts
  var import_shared3 = __toESM(require_dist());
  var import_projection_policy = __toESM(require_projection_policy());

  // src/common/semantic-url.ts
  function isSemanticCaptureSupportedUrl(url) {
    return /^https?:\/\//.test(url ?? "");
  }

  // src/sidepanel/projection-router.ts
  function routeProjection(projection, handlers) {
    switch (projection.type) {
      case "respond":
        handlers.respond(projection.payload);
        return;
      case "focus":
      case "focusMultiple":
        handlers.focus(projection);
        return;
      case "navigate":
        handlers.navigate(projection.payload);
        return;
      case "present":
        handlers.present(projection.payload);
        return;
      case "notify":
        handlers.notify(projection.payload);
        return;
      case "copy":
        handlers.copy(projection.payload);
        return;
      default:
        return;
    }
  }

  // src/sidepanel/content-graph.ts
  var import_shared = __toESM(require_dist());
  var ContentGraphManager = class {
    nodes = /* @__PURE__ */ new Map();
    edges = [];
    addThread(threadDoc, articleUrl) {
      const id = (0, import_shared.hashUrl)(threadDoc.url);
      const node = {
        id,
        url: threadDoc.url,
        title: threadDoc.title,
        type: "thread",
        platform: "hn",
        threadDoc,
        semantics: null,
        sourceArticleUrl: articleUrl,
        snapshot: null
      };
      this.nodes.set(id, node);
      if (articleUrl) {
        this.edges.push({
          from: (0, import_shared.hashUrl)(articleUrl),
          to: id,
          relation: "triggers"
        });
      }
      return id;
    }
    setThreadSemantics(threadUrl, semantics) {
      const node = this.nodes.get((0, import_shared.hashUrl)(threadUrl));
      if (!node) {
        return;
      }
      node.semantics = semantics;
    }
    addArticle(url, title, text, structure, extractedAt = Date.now()) {
      const id = (0, import_shared.hashUrl)(url);
      this.nodes.set(id, {
        id,
        url,
        title,
        type: "article",
        snapshot: {
          text,
          structure,
          extractedAt
        }
      });
      return id;
    }
    getSourceArticle(threadId) {
      const thread = this.nodes.get(threadId);
      if (!thread?.sourceArticleUrl) {
        return null;
      }
      const article = this.nodes.get((0, import_shared.hashUrl)(thread.sourceArticleUrl));
      if (!article?.snapshot) {
        return null;
      }
      return {
        url: article.url,
        title: article.title,
        text: article.snapshot.text,
        structure: article.snapshot.structure,
        readAt: article.snapshot.extractedAt
      };
    }
  };

  // src/sidepanel/auth-client.ts
  async function sendRuntimeMessage(message) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
        reject(new Error("chrome.runtime.sendMessage unavailable"));
        return;
      }
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
  }
  function createAuthClient() {
    return {
      async getAuthState() {
        return sendRuntimeMessage({ type: "GET_AUTH_STATE" });
      },
      async signInWithGoogle() {
        return sendRuntimeMessage({ type: "SIGN_IN_WITH_GOOGLE" });
      },
      async signOut() {
        return sendRuntimeMessage({ type: "SIGN_OUT" });
      },
      async issueToken() {
        const response = await sendRuntimeMessage({
          type: "ENSURE_AUTH_SESSION"
        });
        if (!response.ok || !response.token || !response.user || typeof response.expiresAt !== "number") {
          throw new Error(
            response.error ?? response.state.errorMessage ?? "No authenticated ThreadAtlas session is available."
          );
        }
        return {
          token: response.token,
          expiresAt: response.expiresAt,
          user: response.user
        };
      }
    };
  }

  // src/common/extension-config.ts
  var import_shared2 = __toESM(require_dist());
  var API_BASE_URL_KEY = "THREADATLAS_API_BASE_URL";
  var GOOGLE_OAUTH_CLIENT_ID_KEY = "THREADATLAS_GOOGLE_OAUTH_CLIENT_ID";
  var AUTH_GRANT_TYPE_KEY = "THREADATLAS_AUTH_GRANT_TYPE";
  var BOOTSTRAP_SUBJECT_KEY = "THREADATLAS_BOOTSTRAP_SUBJECT";
  var BOOTSTRAP_KEY_KEY = "THREADATLAS_AUTH_BOOTSTRAP_KEY";
  var DISPLAY_NAME_KEY = "THREADATLAS_AUTH_DISPLAY_NAME";
  var PRIMARY_EMAIL_KEY = "THREADATLAS_AUTH_PRIMARY_EMAIL";
  var AVATAR_URL_KEY = "THREADATLAS_AUTH_AVATAR_URL";
  var EXTENSION_CONFIG_KEYS = [
    API_BASE_URL_KEY,
    GOOGLE_OAUTH_CLIENT_ID_KEY,
    AUTH_GRANT_TYPE_KEY,
    BOOTSTRAP_SUBJECT_KEY,
    BOOTSTRAP_KEY_KEY,
    DISPLAY_NAME_KEY,
    PRIMARY_EMAIL_KEY,
    AVATAR_URL_KEY
  ];
  function normalizeText(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }
  function readCompiledApiBaseUrl() {
    if (true) {
      const normalized = normalizeText("http://localhost:8080");
      if (normalized) {
        return normalized;
      }
    }
    return import_shared2.DEFAULT_API_BASE_URL;
  }
  function readCompiledGoogleClientId() {
    if (true) {
      return normalizeText("");
    }
    return null;
  }
  function createChromeLocalStorage(area = chrome.storage.local) {
    return {
      get(keys) {
        return new Promise((resolve, reject) => {
          area.get(keys, (items) => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve(items);
          });
        });
      },
      set(values) {
        return new Promise((resolve, reject) => {
          area.set(values, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      },
      remove(keys) {
        return new Promise((resolve, reject) => {
          area.remove(keys, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      }
    };
  }
  async function loadExtensionConfig(storage = createChromeLocalStorage()) {
    const stored = await storage.get(EXTENSION_CONFIG_KEYS);
    const apiBaseUrl = normalizeText(stored[API_BASE_URL_KEY]) ?? readCompiledApiBaseUrl();
    const googleOAuthClientId = normalizeText(stored[GOOGLE_OAUTH_CLIENT_ID_KEY]) ?? readCompiledGoogleClientId();
    const configuredGrant = normalizeText(stored[AUTH_GRANT_TYPE_KEY]);
    const bootstrapSubject = normalizeText(stored[BOOTSTRAP_SUBJECT_KEY]);
    const bootstrapKey = normalizeText(stored[BOOTSTRAP_KEY_KEY]);
    let devBootstrap = null;
    if (configuredGrant === "dev-bootstrap" && bootstrapSubject && bootstrapKey) {
      const profile = {};
      const displayName = normalizeText(stored[DISPLAY_NAME_KEY]);
      const primaryEmail = normalizeText(stored[PRIMARY_EMAIL_KEY]);
      const avatarUrl = normalizeText(stored[AVATAR_URL_KEY]);
      if (displayName) {
        profile.displayName = displayName;
      }
      if (primaryEmail) {
        profile.primaryEmail = primaryEmail;
      }
      if (avatarUrl) {
        profile.avatarUrl = avatarUrl;
      }
      devBootstrap = {
        bootstrapSubject,
        bootstrapKey,
        ...Object.keys(profile).length > 0 ? { profile } : {}
      };
    }
    return {
      apiBaseUrl,
      googleOAuthClientId,
      devBootstrap
    };
  }

  // src/sidepanel/audio-level.ts
  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }
  function measurePcm16Base64Level(base64) {
    const bytes = base64ToBytes(base64);
    if (bytes.byteLength < 2) {
      return 0;
    }
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const sampleCount = Math.floor(bytes.byteLength / 2);
    let total = 0;
    for (let index = 0; index < sampleCount; index += 1) {
      const sample = view.getInt16(index * 2, true) / 32768;
      total += sample * sample;
    }
    const rms = Math.sqrt(total / sampleCount);
    return Math.max(0, Math.min(1, rms * 4));
  }
  function decodePcm16Base64ToFloat32(base64) {
    const bytes = base64ToBytes(base64);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const sampleCount = Math.floor(bytes.byteLength / 2);
    const output = new Float32Array(sampleCount);
    for (let index = 0; index < sampleCount; index += 1) {
      const sample = view.getInt16(index * 2, true);
      output[index] = sample / 32768;
    }
    return output;
  }

  // src/sidepanel/content-audio-input.ts
  function makeCaptureSessionId() {
    return globalThis.crypto?.randomUUID?.() ?? `page-audio-${Date.now()}`;
  }
  var PageAudioInputProvider = class {
    constructor(args) {
      this.args = args;
      const hasInjectedRuntimeBridge = typeof args.addRuntimeListener === "function" && typeof args.removeRuntimeListener === "function";
      const hasChromeRuntimeBridge = typeof chrome !== "undefined" && Boolean(chrome.runtime?.onMessage);
      this.supported = typeof args.sendToContentScript === "function" && (hasInjectedRuntimeBridge || hasChromeRuntimeBridge);
      this.state = this.supported ? "idle" : "unsupported";
      this.runtimeListener = (message, sender) => {
        this.handleRuntimeMessage(message, sender);
      };
      if (this.supported) {
        ;
        (args.addRuntimeListener ?? this.addChromeRuntimeListener)(this.runtimeListener);
      }
    }
    supported;
    onLevel;
    onChunkBase64;
    onError;
    onStateChange;
    currentSessionId = null;
    currentTabId = null;
    state;
    stopPromise = null;
    resolveStop = null;
    rejectStop = null;
    runtimeListener;
    async start() {
      if (!this.supported) {
        throw new Error("Voice input is unavailable in this browser.");
      }
      const tabId = this.args.getActiveTabId();
      if (tabId === null) {
        throw new Error("No active tab context.");
      }
      await this.cancel();
      const sessionId = makeCaptureSessionId();
      this.currentSessionId = sessionId;
      this.currentTabId = tabId;
      this.clearStopPromise();
      this.emitState("processing");
      const response = await this.args.sendToContentScript(tabId, {
        type: "START_PAGE_AUDIO_CAPTURE",
        payload: {
          sessionId
        }
      });
      if (!response.ok) {
        this.emitError(response.error ?? "Voice input could not be started on the page.");
        throw new Error(response.error ?? "Voice input could not be started on the page.");
      }
    }
    async stop() {
      if (!this.currentSessionId || this.currentTabId === null) {
        return;
      }
      this.emitState("processing");
      this.stopPromise = new Promise((resolve, reject) => {
        this.resolveStop = resolve;
        this.rejectStop = reject;
      });
      const response = await this.args.sendToContentScript(this.currentTabId, {
        type: "STOP_PAGE_AUDIO_CAPTURE",
        payload: {
          sessionId: this.currentSessionId
        }
      });
      if (!response.ok) {
        const error = new Error(response.error ?? "Voice input could not be stopped on the page.");
        this.rejectStop?.(error);
        this.clearStopPromise();
        this.emitError(error.message);
        throw error;
      }
      await Promise.race([
        this.stopPromise,
        new Promise((_, reject) => {
          window.setTimeout(() => {
            reject(new Error("Voice input did not finish stopping on the page."));
          }, 1500);
        })
      ]).catch((error) => {
        const message = error instanceof Error ? error.message : "Voice input did not finish stopping on the page.";
        this.emitError(message);
        throw new Error(message);
      });
    }
    async cancel() {
      const sessionId = this.currentSessionId;
      const tabId = this.currentTabId;
      this.currentSessionId = null;
      this.currentTabId = null;
      this.clearStopPromise();
      if (!sessionId || tabId === null) {
        if (this.supported && this.state !== "unsupported") {
          this.onLevel?.(0);
          this.emitState("idle");
        }
        return;
      }
      try {
        await this.args.sendToContentScript(tabId, {
          type: "CANCEL_PAGE_AUDIO_CAPTURE",
          payload: {
            sessionId
          }
        });
      } catch {
      }
      if (this.supported) {
        this.onLevel?.(0);
        this.emitState("idle");
      }
    }
    dispose() {
      void this.cancel();
      if (this.supported) {
        ;
        (this.args.removeRuntimeListener ?? this.removeChromeRuntimeListener)(this.runtimeListener);
      }
    }
    handleRuntimeMessage(message, sender) {
      if (sender.tab?.id != null) {
        return;
      }
      const payload = "payload" in message ? message.payload : void 0;
      if (payload?.tabId !== this.currentTabId) {
        return;
      }
      switch (message.type) {
        case "PAGE_AUDIO_CAPTURE_STATE_CHANGED":
          if (message.payload.sessionId !== this.currentSessionId) {
            return;
          }
          if (message.payload.state === "idle") {
            this.currentSessionId = null;
            this.currentTabId = null;
            this.resolveStop?.();
            this.clearStopPromise();
            return;
          }
          this.emitState(message.payload.state, message.payload.detail);
          if (message.payload.state === "error") {
            this.emitError(message.payload.detail ?? "Voice input failed.");
          }
          if (message.payload.state === "unsupported") {
            this.currentSessionId = null;
            this.currentTabId = null;
            this.clearStopPromise();
          }
          return;
        case "PAGE_AUDIO_CAPTURE_CHUNK":
          if (message.payload.sessionId !== this.currentSessionId) {
            return;
          }
          this.onLevel?.(measurePcm16Base64Level(message.payload.chunkBase64));
          this.onChunkBase64?.(message.payload.chunkBase64);
          return;
        default:
          return;
      }
    }
    emitState(state2, detail) {
      this.state = state2;
      this.onStateChange?.(state2, detail);
    }
    emitError(message) {
      const error = new Error(message);
      this.rejectStop?.(error);
      this.clearStopPromise();
      this.currentSessionId = null;
      this.currentTabId = null;
      this.onLevel?.(0);
      this.emitState("error", message);
      this.onError?.(error);
    }
    clearStopPromise() {
      this.stopPromise = null;
      this.resolveStop = null;
      this.rejectStop = null;
    }
    addChromeRuntimeListener(listener) {
      chrome.runtime.onMessage.addListener(listener);
    }
    removeChromeRuntimeListener(listener) {
      chrome.runtime.onMessage.removeListener(listener);
    }
  };

  // src/sidepanel/live-audio-output.ts
  var LiveAudioOutputPlayer = class {
    supported;
    onLevel;
    audioContext = null;
    activeSources = /* @__PURE__ */ new Set();
    nextPlaybackTime = 0;
    constructor() {
      this.supported = typeof AudioContext !== "undefined";
    }
    async playChunk(chunkBase64) {
      if (!this.supported) {
        return;
      }
      const context = this.ensureContext();
      await context.resume();
      const float32 = decodePcm16Base64ToFloat32(chunkBase64);
      this.onLevel?.(measurePcm16Base64Level(chunkBase64));
      const audioBuffer = context.createBuffer(1, float32.length, 24e3);
      audioBuffer.copyToChannel(Float32Array.from(float32), 0);
      const source = context.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(context.destination);
      const startTime = Math.max(context.currentTime, this.nextPlaybackTime);
      this.nextPlaybackTime = startTime + audioBuffer.duration;
      source.start(startTime);
      this.activeSources.add(source);
      source.onended = () => {
        this.activeSources.delete(source);
      };
    }
    stop() {
      this.onLevel?.(0);
      for (const source of this.activeSources) {
        try {
          source.stop();
        } catch {
        }
      }
      this.activeSources.clear();
      this.nextPlaybackTime = 0;
    }
    async dispose() {
      this.stop();
      if (this.audioContext) {
        await this.audioContext.close();
        this.audioContext = null;
      }
    }
    ensureContext() {
      if (!this.audioContext) {
        this.audioContext = new AudioContext({ sampleRate: 24e3 });
      }
      return this.audioContext;
    }
  };

  // src/sidepanel/runtime-transport.ts
  function makeTimestamp() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  function makeRequestId(prefix) {
    const random = globalThis.crypto?.randomUUID?.() ?? Math.random().toString(16).slice(2);
    return `${prefix}-${random}`;
  }
  function makeClientSessionId() {
    return globalThis.crypto?.randomUUID?.() ?? `runtime-${Date.now()}`;
  }
  function toWebSocketUrl(apiBaseUrl, token) {
    const url = new URL(apiBaseUrl);
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
    url.pathname = "/ws/runtime";
    url.search = "";
    url.searchParams.set("token", token);
    return url.toString();
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function isRuntimeV2ServerEnvelope(value) {
    return isRecord(value) && typeof value.type === "string" && typeof value.timestamp === "string" && isRecord(value.payload);
  }
  var RuntimeTransport = class {
    constructor(args) {
      this.args = args;
    }
    clientSessionId = makeClientSessionId();
    ws = null;
    sessionId = null;
    activeTurnId = null;
    connectPromise = null;
    resolveSessionReady = null;
    rejectSessionReady = null;
    async sendTextTurn(input) {
      const normalized = input.text.trim();
      if (!normalized) {
        throw new Error("text input is required");
      }
      if (this.activeTurnId) {
        await this.interrupt("superseded-by-new-turn");
      }
      await this.ensureSession(input.language);
      await this.syncContextSnapshot(input.activeTabId, input.snapshot);
      const sessionId = this.sessionId;
      if (!sessionId) {
        throw new Error("runtime session is not ready");
      }
      this.args.handlers.onPhaseChange?.("sending-intent");
      this.send({
        type: "turn.input.text",
        requestId: makeRequestId("turn-text"),
        timestamp: makeTimestamp(),
        sessionId,
        payload: {
          text: normalized
        }
      });
    }
    async startVoiceTurn(input) {
      if (this.activeTurnId) {
        await this.interrupt("superseded-by-new-turn");
      }
      await this.ensureSession(input.language);
      await this.syncContextSnapshot(input.activeTabId, input.snapshot);
    }
    appendAudioChunk(chunkBase64) {
      const sessionId = this.sessionId;
      if (!sessionId) {
        throw new Error("runtime session is not ready");
      }
      this.send({
        type: "turn.input.audio.append",
        requestId: makeRequestId("turn-audio"),
        timestamp: makeTimestamp(),
        sessionId,
        payload: {
          chunkBase64
        }
      });
    }
    commitAudio() {
      const sessionId = this.sessionId;
      if (!sessionId) {
        throw new Error("runtime session is not ready");
      }
      this.send({
        type: "turn.input.audio.commit",
        requestId: makeRequestId("turn-commit"),
        timestamp: makeTimestamp(),
        sessionId,
        payload: {
          endOfTurn: true
        }
      });
    }
    async interrupt(reason) {
      if (!this.sessionId || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
        return;
      }
      this.send({
        type: "turn.interrupt",
        requestId: makeRequestId("turn-interrupt"),
        timestamp: makeTimestamp(),
        sessionId: this.sessionId,
        ...this.activeTurnId ? { turnId: this.activeTurnId } : {},
        payload: reason ? { reason } : {}
      });
      this.activeTurnId = null;
    }
    async close() {
      this.connectPromise = null;
      this.resolveSessionReady = null;
      this.rejectSessionReady = null;
      this.sessionId = null;
      this.activeTurnId = null;
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
    }
    async ensureSession(language) {
      if (this.ws && this.ws.readyState === WebSocket.OPEN && this.sessionId) {
        return;
      }
      if (this.connectPromise) {
        await this.connectPromise;
        return;
      }
      this.args.handlers.onPhaseChange?.("opening-session");
      this.connectPromise = this.openSession(language).finally(() => {
        this.connectPromise = null;
      });
      await this.connectPromise;
    }
    async openSession(language) {
      const token = await this.args.authClient.issueToken();
      const factory = this.args.webSocketFactory ?? ((url) => new WebSocket(url));
      const nextWs = factory(toWebSocketUrl(this.args.apiBaseUrl, token.token));
      this.ws = nextWs;
      await new Promise((resolve, reject) => {
        this.resolveSessionReady = resolve;
        this.rejectSessionReady = reject;
        nextWs.onopen = () => {
          const envelope = {
            type: "session.open",
            requestId: makeRequestId("session-open"),
            timestamp: makeTimestamp(),
            payload: {
              clientSessionId: this.clientSessionId,
              ...language ? { language } : {}
            }
          };
          nextWs.send(JSON.stringify(envelope));
        };
        nextWs.onmessage = (event) => {
          this.handleSocketMessage(event.data);
        };
        nextWs.onerror = () => {
          this.args.handlers.onPhaseChange?.("error");
          this.rejectSessionReady?.(new Error("runtime websocket failed"));
          this.clearPendingSessionReady();
        };
        nextWs.onclose = () => {
          this.args.handlers.onPhaseChange?.("error");
          this.rejectSessionReady?.(new Error("runtime websocket closed"));
          this.clearPendingSessionReady();
          this.sessionId = null;
          this.activeTurnId = null;
          this.ws = null;
        };
      });
    }
    async syncContextSnapshot(tabId, snapshot) {
      if (!this.sessionId || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("runtime websocket is not ready");
      }
      this.send({
        type: "session.context.sync",
        requestId: makeRequestId("session-context"),
        timestamp: makeTimestamp(),
        sessionId: this.sessionId,
        payload: {
          tabId,
          isPrimary: true
        }
      });
      this.send({
        type: "session.snapshot.sync",
        requestId: makeRequestId("session-snapshot"),
        timestamp: makeTimestamp(),
        sessionId: this.sessionId,
        payload: {
          tabId,
          snapshot
        }
      });
    }
    handleSocketMessage(raw) {
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch {
        return;
      }
      if (!isRuntimeV2ServerEnvelope(parsed)) {
        return;
      }
      switch (parsed.type) {
        case "session.ready":
          this.sessionId = parsed.payload.sessionId;
          this.args.handlers.onSessionReady?.(parsed);
          this.args.handlers.onPhaseChange?.("ready");
          this.resolveSessionReady?.();
          this.clearPendingSessionReady();
          return;
        case "turn.started":
          this.activeTurnId = parsed.turnId;
          this.args.handlers.onTurnStarted?.(parsed);
          return;
        case "turn.input.transcript.partial":
          this.args.handlers.onInputTranscript?.(parsed.payload.text, false, parsed);
          return;
        case "turn.input.transcript.final":
          this.args.handlers.onInputTranscript?.(parsed.payload.text, true, parsed);
          return;
        case "turn.output.transcript.partial":
          this.args.handlers.onOutputTranscript?.(parsed.payload.text, false, parsed);
          return;
        case "turn.output.transcript.final":
          this.args.handlers.onOutputTranscript?.(parsed.payload.text, true, parsed);
          return;
        case "turn.output.audio.chunk":
          this.args.handlers.onAudioChunk?.(parsed);
          return;
        case "turn.output.projection":
          this.args.handlers.onProjection?.(parsed.payload.projection, parsed);
          return;
        case "tool.request":
          void this.handleToolRequest(parsed);
          return;
        case "turn.done":
          if (this.activeTurnId === parsed.turnId) {
            this.activeTurnId = null;
          }
          this.args.handlers.onPhaseChange?.("ready");
          this.args.handlers.onTurnDone?.(parsed);
          return;
        case "turn.error":
          if (parsed.turnId && this.activeTurnId === parsed.turnId) {
            this.activeTurnId = null;
          }
          this.args.handlers.onPhaseChange?.("error");
          this.args.handlers.onError?.(parsed.payload, parsed);
          return;
      }
    }
    async handleToolRequest(event) {
      const result = await this.args.handlers.onToolRequest?.(event);
      if (!event.payload.waitForResult && !result) {
        return;
      }
      const payload = result ?? {
        toolRequestId: event.payload.toolRequestId,
        kind: event.payload.kind,
        ok: false,
        error: "frontend tool handler did not return a result"
      };
      this.send({
        type: "tool.result",
        requestId: makeRequestId("tool-result"),
        timestamp: makeTimestamp(),
        sessionId: event.sessionId,
        turnId: event.turnId,
        payload
      });
    }
    send(envelope) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("runtime websocket is not open");
      }
      this.ws.send(JSON.stringify(envelope));
    }
    clearPendingSessionReady() {
      this.resolveSessionReady = null;
      this.rejectSessionReady = null;
    }
  };

  // src/sidepanel/conversation-controller.ts
  var ConversationController = class {
    constructor(args) {
      this.args = args;
      this.ttsEnabled = args.ttsEnabled;
      this.audioOutput = args.audioOutput ?? new LiveAudioOutputPlayer();
      this.transport = args.transport ?? new RuntimeTransport({
        apiBaseUrl: args.apiBaseUrl,
        authClient: args.authClient,
        handlers: {
          ...args.handlers,
          onAudioChunk: (event) => {
            if (this.ttsEnabled) {
              void this.audioOutput.playChunk(event.payload.chunkBase64);
            }
            args.handlers.onAudioChunk?.(event);
          },
          onTurnDone: (event) => {
            if (event.payload.modality === "voice") {
              this.acceptingVoiceInputChunks = false;
              if (this.audioInput.supported) {
                void this.audioInput.cancel();
              }
            }
            args.handlers.onTurnDone?.(event);
            this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
          },
          onError: (error, event) => {
            this.acceptingVoiceInputChunks = false;
            args.handlers.onError?.(error, event);
            this.audioOutput.stop();
            if (this.audioInput.supported) {
              void this.audioInput.cancel();
            } else {
              this.notifySpeechState("unsupported");
            }
          }
        }
      });
      this.audioInput = args.audioInput ?? new PageAudioInputProvider({
        getActiveTabId: args.getActiveTabId,
        sendToContentScript: args.sendToContentScript,
        addRuntimeListener: args.addRuntimeListener,
        removeRuntimeListener: args.removeRuntimeListener
      });
      this.audioInput.onChunkBase64 = (chunkBase64) => {
        if (!this.acceptingVoiceInputChunks) {
          return;
        }
        this.transport.appendAudioChunk(chunkBase64);
      };
      this.audioInput.onError = (error) => {
        this.acceptingVoiceInputChunks = false;
        this.audioOutput.stop();
        this.notifySpeechState("error", error.message);
      };
      this.audioInput.onStateChange = (state2, detail) => {
        this.notifySpeechState(state2, detail);
      };
      this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
    }
    audioInput;
    audioOutput;
    transport;
    ttsEnabled;
    acceptingVoiceInputChunks = false;
    get inputSupported() {
      return this.audioInput.supported;
    }
    get outputSupported() {
      return this.audioOutput.supported;
    }
    setVoiceOutputEnabled(enabled) {
      this.ttsEnabled = enabled;
      if (!enabled) {
        this.audioOutput.stop();
      }
    }
    async sendTextTurn(input) {
      this.acceptingVoiceInputChunks = false;
      this.audioOutput.stop();
      await this.transport.sendTextTurn(input);
    }
    async startVoiceTurn(input) {
      if (!this.audioInput.supported) {
        throw new Error("Voice input is unavailable in this browser.");
      }
      this.acceptingVoiceInputChunks = false;
      this.audioOutput.stop();
      await this.transport.startVoiceTurn(input);
      try {
        await this.audioInput.start();
        this.acceptingVoiceInputChunks = true;
      } catch (error) {
        this.acceptingVoiceInputChunks = false;
        throw error;
      }
    }
    async finishVoiceTurn() {
      if (!this.audioInput.supported) {
        return;
      }
      await this.audioInput.stop();
      this.acceptingVoiceInputChunks = false;
      this.transport.commitAudio();
    }
    async cancelVoiceTurn() {
      this.acceptingVoiceInputChunks = false;
      if (this.audioInput.supported) {
        await this.audioInput.cancel();
      }
      await this.transport.interrupt("cancelled");
      this.audioOutput.stop();
      this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
    }
    async interrupt(reason) {
      this.acceptingVoiceInputChunks = false;
      if (this.audioInput.supported) {
        await this.audioInput.cancel();
      }
      await this.transport.interrupt(reason);
      this.audioOutput.stop();
      this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
    }
    async close() {
      this.acceptingVoiceInputChunks = false;
      if (this.audioInput.supported) {
        await this.audioInput.cancel();
      }
      this.audioInput.dispose();
      await this.transport.close();
      await this.audioOutput.dispose();
    }
    notifySpeechState(state2, detail) {
      this.args.handlers.onSpeechStateChange?.(state2, detail);
    }
  };

  // src/sidepanel/transcript-merge.ts
  function mergeStreamingTranscript(current, incoming) {
    if (!incoming) {
      return current;
    }
    if (!current) {
      return incoming;
    }
    if (incoming === current) {
      return current;
    }
    if (incoming.startsWith(current)) {
      return incoming;
    }
    if (current.startsWith(incoming)) {
      return current;
    }
    const maxOverlap = Math.min(current.length, incoming.length);
    for (let overlap = maxOverlap; overlap > 0; overlap -= 1) {
      if (current.slice(-overlap) === incoming.slice(0, overlap)) {
        return current + incoming.slice(overlap);
      }
    }
    return current + incoming;
  }

  // src/sidepanel/ui.ts
  var PHASE_COLORS = {
    initializing: "#eab308",
    ready: "#16a34a",
    "opening-session": "#0ea5e9",
    "sending-intent": "#2563eb",
    "waiting-enrich": "#f59e0b",
    "resuming-turn": "#0f766e",
    dormant: "#64748b",
    error: "#dc2626"
  };
  var PHASE_LABELS = {
    initializing: "analyzing",
    ready: "ready",
    "opening-session": "opening session",
    "sending-intent": "sending intent",
    "waiting-enrich": "waiting enrich",
    "resuming-turn": "resuming turn",
    dormant: "dormant",
    error: "error"
  };
  var CONTEXT_RELATIONS = [
    "parent",
    "child",
    "sibling",
    "container",
    "ancestor"
  ];
  function getAuthDisplayName(user) {
    return user?.displayName ?? user?.primaryEmail ?? "Signed in";
  }
  function getAuthFallbackInitials(user) {
    const source = getAuthDisplayName(user).trim();
    if (!source) {
      return "TA";
    }
    const parts = source.split(/\s+/).filter(Boolean);
    const initials = (parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "");
    return (initials || source.slice(0, 2) || "TA").toUpperCase();
  }
  function bindAuthActions(args) {
    const signInButton = document.getElementById("auth-sign-in-button");
    const signOutButton = document.getElementById("auth-sign-out-button");
    signInButton?.addEventListener("click", args.onSignIn);
    signOutButton?.addEventListener("click", args.onSignOut);
  }
  function renderAuthCard(args) {
    const copy = document.getElementById("auth-copy");
    const userRoot = document.getElementById("auth-user");
    const avatar = document.getElementById("auth-avatar");
    const avatarFallback = document.getElementById("auth-avatar-fallback");
    const userName = document.getElementById("auth-user-name");
    const userEmail = document.getElementById("auth-user-email");
    const signInButton = document.getElementById("auth-sign-in-button");
    const signOutButton = document.getElementById("auth-sign-out-button");
    if (!copy || !userRoot || !avatar || !avatarFallback || !userName || !userEmail || !signInButton || !signOutButton) {
      return;
    }
    userName.textContent = args.user ? getAuthDisplayName(args.user) : "";
    userEmail.textContent = args.user?.primaryEmail ?? "";
    avatarFallback.textContent = getAuthFallbackInitials(args.user);
    avatar.classList.toggle("hidden-inline", !args.user?.avatarUrl);
    avatarFallback.classList.toggle("hidden-inline", Boolean(args.user?.avatarUrl));
    if (args.user?.avatarUrl) {
      avatar.src = args.user.avatarUrl;
      avatar.alt = `${getAuthDisplayName(args.user)} avatar`;
    } else {
      avatar.removeAttribute("src");
      avatar.alt = "";
    }
    signInButton.disabled = args.status === "signing-in" || args.status === "refreshing";
    signOutButton.disabled = args.status === "signing-in" || args.status === "refreshing";
    userRoot.classList.toggle("hidden-inline", !(args.status === "signed-in" && args.user));
    signOutButton.classList.toggle("hidden-inline", args.status !== "signed-in" || !args.user);
    if (args.status === "signed-in" && args.user) {
      copy.textContent = args.provider === "dev-bootstrap" ? "Internal preview session is active." : "Signed in. You can now ask about the current page.";
      signInButton.classList.add("hidden-inline");
      signInButton.textContent = "Continue with Google";
      return;
    }
    signInButton.classList.remove("hidden-inline");
    if (args.status === "signing-in") {
      copy.textContent = "Signing in with Google...";
      signInButton.textContent = "Signing in...";
      return;
    }
    if (args.status === "refreshing") {
      copy.textContent = "Refreshing your ThreadAtlas session...";
      signInButton.textContent = "Refreshing...";
      return;
    }
    if (args.status === "error") {
      copy.textContent = args.errorMessage ?? "Google sign-in failed. Try again.";
      signInButton.textContent = "Retry Google Sign-In";
      return;
    }
    copy.textContent = args.errorMessage ?? "Sign in with Google to ask questions about the current page.";
    signInButton.textContent = "Continue with Google";
  }
  function createValue(label, value) {
    const wrapper = document.createElement("div");
    const labelElement = document.createElement("div");
    labelElement.className = "snapshot-label";
    labelElement.textContent = label;
    const valueElement = document.createElement("div");
    valueElement.className = "snapshot-value";
    valueElement.textContent = value;
    wrapper.append(labelElement, valueElement);
    return wrapper;
  }
  function isCommentNode(node) {
    return node.kind === "comment";
  }
  function isInteractiveNode(node) {
    return node.kind === "interactive";
  }
  function getNodeText(node) {
    if (node.kind !== "interactive") {
      return node.text || "(empty)";
    }
    return node.label ?? node.valuePreview ?? "(empty)";
  }
  function renderPageSummary(snapshot) {
    const root = document.getElementById("semantic-page-summary");
    if (!root) {
      return;
    }
    root.innerHTML = "";
    if (!snapshot) {
      root.appendChild(createValue("State", "No semantic snapshot selected"));
      return;
    }
    root.appendChild(createValue("Title", snapshot.page.title ?? "(untitled)"));
    root.appendChild(createValue("URL", snapshot.page.url));
    root.appendChild(createValue("Kind", snapshot.page.kind));
  }
  function renderFocusDetail(snapshot) {
    const root = document.getElementById("semantic-focus-detail");
    if (!root) {
      return;
    }
    root.innerHTML = "";
    if (!snapshot) {
      root.appendChild(createValue("Focus", "No focus"));
      return;
    }
    const node = snapshot.focus.node;
    root.appendChild(createValue("Node", snapshot.focus.nodeId));
    root.appendChild(createValue("Region", snapshot.focus.region));
    root.appendChild(createValue("Text", getNodeText(node)));
    if (!isInteractiveNode(node) && isCommentNode(node)) {
      root.appendChild(createValue("Author", node.author ?? "(unknown)"));
      root.appendChild(createValue("Timestamp", node.timestamp ?? "(unknown)"));
      root.appendChild(createValue("Depth", String(node.depth)));
    } else if (isInteractiveNode(node)) {
      root.appendChild(createValue("Type", node.controlType));
      root.appendChild(createValue("Label", node.label ?? "(none)"));
      root.appendChild(createValue("Action", node.action ?? "(unknown)"));
      root.appendChild(createValue("State", node.state ?? "(none)"));
      root.appendChild(createValue("Value", node.valuePreview ?? "(none)"));
    } else {
      root.appendChild(createValue("Type", node.type));
      if (node.level) {
        root.appendChild(createValue("Level", String(node.level)));
      }
    }
  }
  function renderContextGroups(snapshot) {
    const root = document.getElementById("semantic-context-groups");
    if (!root) {
      return;
    }
    root.innerHTML = "";
    if (!snapshot || snapshot.context.length === 0) {
      root.appendChild(createValue("Context", "No related context"));
      return;
    }
    for (const relation of CONTEXT_RELATIONS) {
      const group = snapshot.context.filter((slice) => slice.relation === relation);
      if (group.length === 0) {
        continue;
      }
      const section = document.createElement("div");
      const label = document.createElement("div");
      label.className = "snapshot-label";
      label.textContent = relation;
      section.appendChild(label);
      for (const slice of group) {
        const value = document.createElement("div");
        value.className = "snapshot-value";
        value.textContent = getNodeText(slice.node);
        section.appendChild(value);
      }
      root.appendChild(section);
    }
  }
  function renderHistory(history, selectedSnapshotId) {
    const root = document.getElementById("semantic-history-list");
    if (!root) {
      return;
    }
    root.innerHTML = "";
    if (history.length === 0) {
      root.appendChild(createValue("History", "No snapshots in this tab yet"));
      return;
    }
    for (const snapshot of history) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "history-item";
      button.dataset.snapshotId = snapshot.meta.capturedAt;
      if (snapshot.meta.capturedAt === selectedSnapshotId) {
        button.classList.add("active");
      }
      const title = snapshot.page.title ?? snapshot.page.url;
      button.textContent = `${snapshot.meta.capturedAt} \xB7 ${snapshot.focus.region} \xB7 ${title}`;
      root.appendChild(button);
    }
  }
  function renderRawSnapshot(snapshot, rawVisible) {
    const output = document.getElementById("semantic-snapshot-json");
    const toggleButton = document.getElementById("semantic-raw-toggle-button");
    if (!output || !toggleButton) {
      return;
    }
    output.textContent = snapshot ? JSON.stringify(snapshot, null, 2) : "";
    output.classList.toggle("hidden", !rawVisible);
    toggleButton.textContent = rawVisible ? "Hide Raw JSON" : "Show Raw JSON";
  }
  function renderSelectionDetail(enabled, selectedTarget, snapshot, resolutionNote) {
    const status = document.getElementById("semantic-selection-status");
    const detail = document.getElementById("semantic-selection-detail");
    const clearButton = document.getElementById("semantic-selection-clear-button");
    if (!status || !detail || !clearButton) {
      return;
    }
    clearButton.disabled = selectedTarget === null;
    detail.innerHTML = "";
    if (!enabled) {
      status.textContent = "Selection mode is off.";
      detail.appendChild(createValue("State", "No semantic node selected"));
      return;
    }
    status.textContent = selectedTarget ? "Selection mode is on." : "Selection mode is on. Click a semantic node to select it.";
    if (!selectedTarget) {
      detail.appendChild(createValue("State", "No semantic node selected"));
      return;
    }
    detail.appendChild(createValue("Label", selectedTarget.displayLabel));
    detail.appendChild(createValue("Region", selectedTarget.regionId));
    detail.appendChild(createValue("Primitive", selectedTarget.primitive));
    if (selectedTarget.subtype) {
      detail.appendChild(createValue("Subtype", selectedTarget.subtype));
    }
    detail.appendChild(createValue("Category", selectedTarget.category));
    if (selectedTarget.nodeId) {
      detail.appendChild(createValue("Node", selectedTarget.nodeId));
    }
    if (selectedTarget.scopeRootId) {
      detail.appendChild(createValue("Scope Root", selectedTarget.scopeRootId));
    }
    if (selectedTarget.rootNodeId) {
      detail.appendChild(createValue("Root Node", selectedTarget.rootNodeId));
    }
    if (snapshot?.meta.coverage) {
      detail.appendChild(createValue("Coverage", snapshot.meta.coverage.kind));
      detail.appendChild(createValue("Captured Nodes", String(snapshot.meta.coverage.capturedNodeCount)));
      detail.appendChild(createValue("Omitted Nodes", String(snapshot.meta.coverage.omittedNodeCount)));
      detail.appendChild(createValue("Omitted Roots", String(snapshot.meta.coverage.omittedRootCount)));
    }
    if (resolutionNote) {
      detail.appendChild(createValue("Resolution", resolutionNote));
    }
    detail.appendChild(createValue("Text", selectedTarget.text || "(empty)"));
  }
  function renderDebugDetail(debugStatus, debugInfo) {
    const status = document.getElementById("semantic-debug-status");
    const detail = document.getElementById("semantic-debug-detail");
    if (!status || !detail) {
      return;
    }
    status.textContent = debugStatus;
    detail.innerHTML = "";
    if (!debugInfo) {
      detail.appendChild(createValue("State", debugStatus));
      return;
    }
    detail.appendChild(createValue("Region", debugInfo.regionId));
    detail.appendChild(createValue("Primitive", debugInfo.primitive));
    detail.appendChild(createValue("Subtype", debugInfo.subtype));
    detail.appendChild(createValue("Category", debugInfo.category));
    detail.appendChild(createValue("Layout Role", debugInfo.layoutRole));
    detail.appendChild(createValue("Role Rank", debugInfo.roleRank));
    detail.appendChild(createValue("Suppression", debugInfo.suppression));
    detail.appendChild(createValue("Normalized", debugInfo.normalizedKind));
    detail.appendChild(createValue("Assembled Items", debugInfo.assembledItemCount));
    detail.appendChild(createValue("Signals", debugInfo.signals));
    if (debugInfo.note) {
      detail.appendChild(createValue("Note", debugInfo.note));
    }
  }
  function renderContextRestrictions(restrictions) {
    const root = document.getElementById("semantic-context-restrictions");
    if (!root) {
      return;
    }
    root.innerHTML = "";
    if (restrictions.length === 0) {
      return;
    }
    for (const restriction of restrictions) {
      root.appendChild(createValue(restriction.profile, restriction.reason));
    }
  }
  function updatePhaseIndicator(phase) {
    const dot = document.getElementById("status-dot");
    const label = document.getElementById("status-label");
    if (!dot || !label) {
      return;
    }
    dot.style.background = PHASE_COLORS[phase];
    label.textContent = PHASE_LABELS[phase];
  }
  function renderPresent(content) {
    const root = document.getElementById("present-root");
    if (!root) {
      return;
    }
    root.innerHTML = "";
    const title = document.createElement("h3");
    title.textContent = content.title;
    title.style.margin = "0 0 8px";
    title.style.fontSize = "14px";
    root.appendChild(title);
    const list = document.createElement("ul");
    list.style.margin = "0";
    list.style.paddingLeft = "16px";
    for (const item of content.items) {
      const li = document.createElement("li");
      li.textContent = `${item.source}: ${item.summary}`;
      list.appendChild(li);
    }
    root.appendChild(list);
  }
  function clearPresent() {
    const root = document.getElementById("present-root");
    if (!root) {
      return;
    }
    root.innerHTML = "";
  }
  function showNotify(message, _level) {
    const root = document.getElementById("notify-root");
    if (!root) {
      return;
    }
    root.textContent = message;
    root.style.display = "block";
    window.setTimeout(() => {
      root.style.display = "none";
    }, 3e3);
  }
  function clearSuggestChips() {
    const root = document.getElementById("suggest-root");
    if (!root) {
      return;
    }
    root.innerHTML = "";
  }
  function showSuggestChips(options, onSelect) {
    const root = document.getElementById("suggest-root");
    if (!root) {
      return;
    }
    clearSuggestChips();
    for (const option of options) {
      const button = document.createElement("button");
      button.className = "chip";
      button.textContent = option;
      button.type = "button";
      button.addEventListener("click", () => onSelect(option));
      root.appendChild(button);
    }
  }
  var detachConversationKeyboardBindings = null;
  function isEditableConversationTarget(target) {
    if (!(target instanceof HTMLElement)) {
      return false;
    }
    if (target.isContentEditable) {
      return true;
    }
    const tagName = target.tagName;
    return tagName === "INPUT" || tagName === "TEXTAREA" || tagName === "SELECT" || tagName === "BUTTON";
  }
  function bindConversationActions(args) {
    const composer = document.getElementById("conversation-input");
    const sendButton = document.getElementById("conversation-send-button");
    const micButton = document.getElementById("conversation-mic-button");
    const voiceOutputButton = document.getElementById("conversation-voice-output-button");
    if (!composer || !sendButton || !micButton || !voiceOutputButton) {
      return;
    }
    let activePointerId = null;
    let suppressLostPointerCancel = false;
    let activeKeyboardMicPress = false;
    detachConversationKeyboardBindings?.();
    detachConversationKeyboardBindings = null;
    composer.addEventListener("input", () => {
      args.onComposerInput(composer.value);
    });
    composer.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" || event.shiftKey) {
        return;
      }
      event.preventDefault();
      args.onSubmitPrompt(composer.value);
    });
    sendButton.addEventListener("click", () => {
      args.onSubmitPrompt(composer.value);
    });
    micButton.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      activePointerId = event.pointerId;
      suppressLostPointerCancel = false;
      if (typeof micButton.setPointerCapture === "function") {
        micButton.setPointerCapture(event.pointerId);
      }
      args.onStartMicPress();
    });
    micButton.addEventListener("pointerup", (event) => {
      if (activePointerId !== event.pointerId) {
        return;
      }
      event.preventDefault();
      activePointerId = null;
      suppressLostPointerCancel = true;
      if (typeof micButton.releasePointerCapture === "function" && micButton.hasPointerCapture(event.pointerId)) {
        micButton.releasePointerCapture(event.pointerId);
      }
      args.onEndMicPress();
    });
    micButton.addEventListener("pointercancel", (event) => {
      if (activePointerId !== event.pointerId) {
        return;
      }
      activePointerId = null;
      suppressLostPointerCancel = false;
      args.onCancelMicPress();
    });
    micButton.addEventListener("lostpointercapture", () => {
      if (suppressLostPointerCancel) {
        suppressLostPointerCancel = false;
        return;
      }
      if (activePointerId === null) {
        return;
      }
      activePointerId = null;
      args.onCancelMicPress();
    });
    voiceOutputButton.addEventListener("click", () => {
      args.onToggleVoiceOutput();
    });
    const handleKeyDown = (event) => {
      if (event.isComposing || event.repeat || event.ctrlKey || event.metaKey || event.altKey) {
        return;
      }
      if (event.key === "Escape") {
        if (activeKeyboardMicPress) {
          activeKeyboardMicPress = false;
        }
        args.onCancelMicPress();
        return;
      }
      if (event.code !== "Space" || event.shiftKey) {
        return;
      }
      if (isEditableConversationTarget(event.target)) {
        return;
      }
      event.preventDefault();
      if (activeKeyboardMicPress) {
        return;
      }
      activeKeyboardMicPress = true;
      args.onStartMicPress();
    };
    const handleKeyUp = (event) => {
      if (event.code !== "Space" || event.shiftKey) {
        return;
      }
      if (!activeKeyboardMicPress) {
        return;
      }
      event.preventDefault();
      activeKeyboardMicPress = false;
      args.onEndMicPress();
    };
    const handleWindowBlur = () => {
      if (!activeKeyboardMicPress) {
        return;
      }
      activeKeyboardMicPress = false;
      args.onCancelMicPress();
    };
    const handleVisibilityChange = () => {
      if (!document.hidden || !activeKeyboardMicPress) {
        return;
      }
      activeKeyboardMicPress = false;
      args.onCancelMicPress();
    };
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("keyup", handleKeyUp);
    window.addEventListener("blur", handleWindowBlur);
    document.addEventListener("visibilitychange", handleVisibilityChange);
    detachConversationKeyboardBindings = () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("blur", handleWindowBlur);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }
  function bindSemanticSnapshotActions(args) {
    const captureButton = document.getElementById("semantic-capture-button");
    const copyButton = document.getElementById("semantic-copy-button");
    const copyContextButton = document.getElementById("semantic-context-copy-button");
    const selectionButton = document.getElementById("semantic-selection-button");
    const clearSelectionButton = document.getElementById("semantic-selection-clear-button");
    const rawToggleButton = document.getElementById("semantic-raw-toggle-button");
    const contextProfile = document.getElementById("semantic-context-profile");
    const contextPackTab = document.getElementById("semantic-context-pack-tab");
    const compactTab = document.getElementById("semantic-context-compact-tab");
    const linearTab = document.getElementById("semantic-context-linear-tab");
    const historyRoot = document.getElementById("semantic-history-list");
    captureButton?.addEventListener("click", args.onCapture);
    copyButton?.addEventListener("click", args.onCopy);
    copyContextButton?.addEventListener("click", args.onCopyContext);
    selectionButton?.addEventListener("click", args.onToggleSelection);
    clearSelectionButton?.addEventListener("click", args.onClearSelection);
    rawToggleButton?.addEventListener("click", args.onToggleRaw);
    contextProfile?.addEventListener("change", () => {
      args.onSelectContextProfile(contextProfile.value);
    });
    contextPackTab?.addEventListener("click", () => {
      args.onSelectContextFormat("context-pack-json");
    });
    compactTab?.addEventListener("click", () => {
      args.onSelectContextFormat("compact-json");
    });
    linearTab?.addEventListener("click", () => {
      args.onSelectContextFormat("linear-text");
    });
    historyRoot?.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) {
        return;
      }
      const button = target.closest("[data-snapshot-id]");
      const snapshotId = button?.dataset.snapshotId;
      if (snapshotId) {
        args.onSelectHistory(snapshotId);
      }
    });
  }
  function setSemanticSnapshotBusy(isBusy) {
    const captureButton = document.getElementById("semantic-capture-button");
    if (!captureButton) {
      return;
    }
    captureButton.disabled = isBusy;
    captureButton.textContent = isBusy ? "Capturing..." : "Capture Snapshot";
  }
  function renderConversation(args) {
    const transcript = document.getElementById("conversation-transcript");
    const status = document.getElementById("conversation-status");
    const composer = document.getElementById("conversation-input");
    const sendButton = document.getElementById("conversation-send-button");
    const micButton = document.getElementById("conversation-mic-button");
    const voiceOutputButton = document.getElementById("conversation-voice-output-button");
    if (!transcript || !status || !composer || !sendButton || !micButton || !voiceOutputButton) {
      return;
    }
    transcript.innerHTML = "";
    if (args.messages.length === 0) {
      const empty = document.createElement("div");
      empty.className = "conversation-empty";
      empty.textContent = "Capture a semantic snapshot, then ask about the current page.";
      transcript.appendChild(empty);
    } else {
      for (const message of args.messages) {
        const item = document.createElement("div");
        item.className = `conversation-message conversation-${message.role}`;
        if (message.pending) {
          item.classList.add("conversation-pending");
        }
        const label = document.createElement("div");
        label.className = "conversation-role";
        label.textContent = message.role === "user" ? "You" : "ThreadAtlas";
        const body = document.createElement("div");
        body.className = "conversation-text";
        body.textContent = message.text;
        item.append(label, body);
        transcript.appendChild(item);
      }
    }
    status.textContent = args.status;
    composer.value = args.composerValue;
    composer.disabled = args.composerDisabled;
    composer.readOnly = args.composerReadOnly ?? false;
    composer.placeholder = args.placeholder ?? "Ask about the current snapshot...";
    sendButton.disabled = args.submitDisabled;
    micButton.disabled = args.micDisabled ?? false;
    micButton.textContent = args.micLabel ?? "Mic";
    voiceOutputButton.disabled = args.voiceOutputDisabled ?? false;
    voiceOutputButton.textContent = args.voiceOutputLabel ?? (args.voiceOutputEnabled === false ? "Voice Output Off" : "Voice Output On");
    voiceOutputButton.classList.toggle("active-toggle", args.voiceOutputEnabled !== false);
    voiceOutputButton.setAttribute("aria-pressed", args.voiceOutputEnabled === false ? "false" : "true");
  }
  function renderSemanticSnapshot(args) {
    const status = document.getElementById("semantic-snapshot-status");
    const selectionButton = document.getElementById("semantic-selection-button");
    const contextProfile = document.getElementById("semantic-context-profile");
    const contextStatus = document.getElementById("semantic-context-status");
    const contextPreview = document.getElementById("semantic-context-preview");
    const contextCopyButton = document.getElementById("semantic-context-copy-button");
    const contextPackTab = document.getElementById("semantic-context-pack-tab");
    const compactTab = document.getElementById("semantic-context-compact-tab");
    const linearTab = document.getElementById("semantic-context-linear-tab");
    if (!status || !selectionButton || !contextProfile || !contextStatus || !contextPreview || !contextCopyButton || !contextPackTab || !compactTab || !linearTab) {
      return;
    }
    const {
      snapshot,
      error,
      history,
      selectedSnapshotId,
      rawVisible,
      selectionEnabled,
      selectedTarget,
      contextAvailable,
      contextRestrictions = [],
      selectionResolutionNote = null
    } = args;
    if (snapshot) {
      status.textContent = error ? `Captured with warning: ${error}` : "Latest semantic snapshot";
    } else if (error) {
      status.textContent = error;
    } else {
      status.textContent = "No semantic snapshot captured yet.";
    }
    selectionButton.textContent = selectionEnabled ? "Selection On" : "Selection Off";
    renderPageSummary(snapshot);
    renderFocusDetail(snapshot);
    renderContextGroups(snapshot);
    renderHistory(history, selectedSnapshotId);
    renderRawSnapshot(snapshot, rawVisible);
    renderSelectionDetail(selectionEnabled, selectedTarget, snapshot, selectionResolutionNote);
    renderDebugDetail(args.debugStatus ?? "No region dump loaded.", args.debugInfo ?? null);
    renderContextRestrictions(contextRestrictions);
    contextProfile.value = args.contextProfile;
    for (const option of Array.from(contextProfile.options)) {
      option.disabled = contextRestrictions.some((restriction) => restriction.profile === option.value);
    }
    contextStatus.textContent = args.contextStatus;
    contextPreview.textContent = args.contextPreview;
    contextCopyButton.disabled = !contextAvailable;
    contextPackTab.classList.toggle("active", args.contextFormat === "context-pack-json");
    compactTab.classList.toggle("active", args.contextFormat === "compact-json");
    linearTab.classList.toggle("active", args.contextFormat === "linear-text");
  }
  function selectSnapshotById(history, selectedSnapshotId, latestSnapshot) {
    if (selectedSnapshotId) {
      const selected = history.find((snapshot) => snapshot.meta.capturedAt === selectedSnapshotId);
      if (selected) {
        return selected;
      }
    }
    return history[0] ?? latestSnapshot;
  }

  // src/sidepanel/index.ts
  var TTS_ENABLED_STORAGE_KEY = "THREADATLAS_TTS_ENABLED";
  var authClient = createAuthClient();
  function readPersistedTtsEnabled() {
    const stored = window.localStorage.getItem(TTS_ENABLED_STORAGE_KEY);
    return stored === null ? true : stored === "true";
  }
  var state = {
    phase: "initializing",
    apiBaseUrl: "",
    conversationController: null,
    contentGraph: new ContentGraphManager(),
    activeTabId: null,
    latestSemanticSnapshot: null,
    latestRegionDump: null,
    semanticSnapshotHistory: [],
    selectedSemanticSnapshotId: null,
    semanticRawVisible: false,
    selectionEnabled: false,
    selectedTarget: null,
    sessionId: null,
    clientSessionId: null,
    activeTurnId: null,
    pendingEnrichRequest: null,
    lastRuntimeError: null,
    runtimeSnapshot: null,
    semanticContextProfile: "branch-summary",
    semanticContextFormat: "context-pack-json",
    conversationMessages: [],
    composerText: "",
    speechInputState: "unsupported",
    speechInputDetail: null,
    ttsEnabled: readPersistedTtsEnabled(),
    authStatus: "signed-out",
    authProvider: null,
    authUser: null,
    authError: null,
    authBusy: false,
    currentTurnOrigin: null,
    pendingTurnOrigin: null,
    voiceAssistantMessageId: null,
    voiceUserMessageId: null,
    voiceAssistantTranscriptBuffer: "",
    voiceUserTranscriptBuffer: ""
  };
  function resetVoiceTranscriptState() {
    state.voiceAssistantMessageId = null;
    state.voiceUserMessageId = null;
    state.voiceAssistantTranscriptBuffer = "";
    state.voiceUserTranscriptBuffer = "";
  }
  var INTERACTIVE_CONTEXT_RESTRICTION = "Interactive semantic snapshots currently support only the branch-summary profile.";
  function setPhase(phase) {
    state.phase = phase;
    updatePhaseIndicator(phase);
    renderConversationState();
  }
  function renderAuthState() {
    renderAuthCard({
      status: state.authStatus,
      provider: state.authProvider,
      user: state.authUser,
      errorMessage: state.authError
    });
  }
  function applyAuthState(next) {
    const previousStatus = state.authStatus;
    state.authStatus = next.status;
    state.authProvider = next.provider;
    state.authUser = next.user;
    state.authError = next.errorMessage ?? null;
    state.authBusy = next.status === "signing-in" || next.status === "refreshing";
    const shouldResetRuntime = previousStatus !== "signed-out" && previousStatus !== "error" && next.status !== "signed-in" && next.status !== "refreshing";
    if (shouldResetRuntime) {
      void state.conversationController?.close();
      resetVoiceTranscriptState();
      resetSpeechInputState();
      state.sessionId = null;
      state.clientSessionId = null;
      state.activeTurnId = null;
      state.pendingEnrichRequest = null;
      state.lastRuntimeError = null;
      state.runtimeSnapshot = null;
      clearTurnOrigin();
      resetConversationSurface();
    }
    renderAuthState();
    renderConversationState();
  }
  function isConversationAuthReady() {
    return state.authStatus === "signed-in";
  }
  function persistTtsEnabled() {
    window.localStorage.setItem(TTS_ENABLED_STORAGE_KEY, state.ttsEnabled ? "true" : "false");
  }
  function isSpeechListening() {
    return state.speechInputState === "listening";
  }
  function isSpeechProcessing() {
    return state.speechInputState === "processing";
  }
  function shouldShowSpeechError() {
    return state.speechInputState === "error" && Boolean(state.speechInputDetail);
  }
  function resetSpeechInputState() {
    state.speechInputState = state.conversationController?.inputSupported ? "idle" : "unsupported";
    state.speechInputDetail = null;
  }
  function setComposerDraft(value) {
    state.composerText = value;
  }
  function clearTurnOrigin() {
    state.currentTurnOrigin = null;
    state.pendingTurnOrigin = null;
  }
  function stopLiveAudioOutput() {
    state.conversationController?.audioOutput.stop();
  }
  async function interruptVoiceSession(reason = "interrupted") {
    await state.conversationController?.interrupt(reason);
    stopLiveAudioOutput();
    resetVoiceTranscriptState();
    resetSpeechInputState();
  }
  function upsertVoiceUserTranscript(text, final) {
    if (!text && !final) {
      return;
    }
    const messageId = state.voiceUserMessageId ?? `voice-user-${globalThis.crypto?.randomUUID?.() ?? Date.now().toString(16)}`;
    state.voiceUserMessageId = messageId;
    const merged = mergeStreamingTranscript(state.voiceUserTranscriptBuffer, text);
    state.voiceUserTranscriptBuffer = merged;
    if (merged.trim().length === 0 && final) {
      removeConversationMessage(messageId);
      state.voiceUserTranscriptBuffer = "";
      state.voiceUserMessageId = null;
      return;
    }
    upsertConversationMessage({
      id: messageId,
      role: "user",
      text: merged,
      pending: !final
    });
    if (final) {
      state.voiceUserTranscriptBuffer = "";
      state.voiceUserMessageId = null;
    }
  }
  function upsertVoiceAssistantTranscript(text, final) {
    if (!text && !final) {
      return;
    }
    const messageId = state.voiceAssistantMessageId ?? `voice-assistant-${globalThis.crypto?.randomUUID?.() ?? Date.now().toString(16)}`;
    state.voiceAssistantMessageId = messageId;
    const merged = mergeStreamingTranscript(state.voiceAssistantTranscriptBuffer, text);
    state.voiceAssistantTranscriptBuffer = merged;
    if (merged.trim().length === 0 && final) {
      removeConversationMessage(messageId);
      state.voiceAssistantTranscriptBuffer = "";
      state.voiceAssistantMessageId = null;
      return;
    }
    upsertConversationMessage({
      id: messageId,
      role: "assistant",
      text: merged,
      pending: !final
    });
    if (final) {
      state.voiceAssistantTranscriptBuffer = "";
      state.voiceAssistantMessageId = null;
    }
  }
  function hasActiveRuntimeTurn() {
    return state.activeTurnId !== null || state.pendingEnrichRequest !== null || state.phase === "opening-session" || state.phase === "sending-intent" || state.phase === "waiting-enrich" || state.phase === "resuming-turn";
  }
  function getConversationSnapshot() {
    return state.runtimeSnapshot ?? getSelectedSemanticSnapshot();
  }
  function getConversationStatus() {
    const inputSupported = state.conversationController?.inputSupported ?? false;
    const outputSupported = state.conversationController?.outputSupported ?? false;
    if (state.activeTabId === null) {
      return {
        status: "No active tab context.",
        placeholder: "Open a supported tab to start asking questions.",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (!getConversationSnapshot()) {
      return {
        status: "Capture a semantic snapshot to ask about the current page.",
        placeholder: "Capture a semantic snapshot first.",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (state.authStatus === "signing-in") {
      return {
        status: "Signing in with Google before starting the current-page assistant...",
        placeholder: "Waiting for Google sign-in...",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (state.authStatus === "refreshing") {
      return {
        status: "Refreshing your ThreadAtlas session...",
        placeholder: "Waiting for session refresh...",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (!isConversationAuthReady()) {
      return {
        status: state.authError ?? "Continue with Google to ask about the current page.",
        placeholder: "Sign in to ask about the current snapshot...",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (state.phase === "opening-session" || state.phase === "sending-intent") {
      return {
        status: "Sending your question to the current-page runtime...",
        placeholder: "Waiting for the current turn to start...",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (state.phase === "waiting-enrich") {
      return {
        status: "Gathering more page context before answering...",
        placeholder: "Waiting for enrich to finish...",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (state.phase === "resuming-turn") {
      return {
        status: "Finishing the current answer...",
        placeholder: "Waiting for the answer to complete...",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (isSpeechListening()) {
      return {
        status: "Listening for a single utterance. Tap Stop to send it automatically.",
        placeholder: "Listening...",
        composerDisabled: false,
        composerReadOnly: true,
        micDisabled: false,
        micLabel: "Stop",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (isSpeechProcessing()) {
      return {
        status: "Processing the captured voice input...",
        placeholder: "Waiting for the current voice turn to finish...",
        composerDisabled: false,
        composerReadOnly: true,
        micDisabled: true,
        micLabel: "Processing...",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (state.lastRuntimeError) {
      return {
        status: `Last runtime error: ${state.lastRuntimeError.message}`,
        placeholder: "Ask a follow-up about the current snapshot...",
        composerDisabled: false,
        composerReadOnly: false,
        micDisabled: !inputSupported,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (shouldShowSpeechError()) {
      return {
        status: `Voice input error: ${state.speechInputDetail}`,
        placeholder: "Ask about the current snapshot...",
        composerDisabled: false,
        composerReadOnly: false,
        micDisabled: !inputSupported,
        micLabel: "Retry Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (state.phase === "dormant") {
      return {
        status: "Semantic capture is not available on this page.",
        placeholder: "Open a supported page to ask questions.",
        composerDisabled: true,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    if (!inputSupported) {
      return {
        status: "Ask about the current semantic snapshot. Voice input is unavailable in this browser.",
        placeholder: "Ask about the current snapshot...",
        composerDisabled: false,
        composerReadOnly: false,
        micDisabled: true,
        micLabel: "Mic Unavailable",
        voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
        voiceOutputDisabled: !outputSupported
      };
    }
    return {
      status: "Ask about the current semantic snapshot.",
      placeholder: "Ask about the current snapshot...",
      composerDisabled: false,
      composerReadOnly: false,
      micDisabled: false,
      micLabel: "Mic",
      voiceOutputLabel: outputSupported ? state.ttsEnabled ? "Voice Output On" : "Voice Output Off" : "Voice Output Unavailable",
      voiceOutputDisabled: !outputSupported
    };
  }
  function renderConversationState() {
    const availability = getConversationStatus();
    renderConversation({
      messages: state.conversationMessages,
      composerValue: state.composerText,
      status: availability.status,
      composerDisabled: availability.composerDisabled,
      composerReadOnly: availability.composerReadOnly,
      submitDisabled: availability.composerDisabled || availability.composerReadOnly || state.composerText.trim().length === 0,
      micDisabled: availability.micDisabled,
      micLabel: availability.micLabel,
      voiceOutputEnabled: state.ttsEnabled,
      voiceOutputDisabled: availability.voiceOutputDisabled,
      voiceOutputLabel: availability.voiceOutputLabel,
      placeholder: availability.placeholder
    });
  }
  function appendConversationMessage(message) {
    state.conversationMessages = [
      ...state.conversationMessages,
      {
        ...message,
        id: message.id ?? globalThis.crypto?.randomUUID?.() ?? `msg-${Date.now()}`
      }
    ];
    renderConversationState();
  }
  function upsertConversationMessage(message) {
    const existingIndex = state.conversationMessages.findIndex((item) => item.id === message.id);
    if (existingIndex === -1) {
      state.conversationMessages = [...state.conversationMessages, message];
    } else {
      const next = [...state.conversationMessages];
      next[existingIndex] = {
        ...next[existingIndex],
        ...message
      };
      state.conversationMessages = next;
    }
    renderConversationState();
  }
  function removeConversationMessage(id) {
    if (!id) {
      return;
    }
    state.conversationMessages = state.conversationMessages.filter((item) => item.id !== id);
    renderConversationState();
  }
  function resetConversationSurface() {
    state.conversationMessages = [];
    setComposerDraft("");
    resetSpeechInputState();
    clearTurnOrigin();
    resetVoiceTranscriptState();
    clearSuggestChips();
    clearPresent();
    renderConversationState();
  }
  function setPhaseForUrl(url) {
    if (hasActiveRuntimeTurn()) {
      return;
    }
    setPhase(isSemanticCaptureSupportedUrl(url) ? "ready" : "dormant");
  }
  async function sendRuntimeMessage2(message) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
        reject(new Error("chrome.runtime.sendMessage unavailable"));
        return;
      }
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
  }
  async function sendToContentScript(tabId, message) {
    const trySend = () => new Promise((resolve, reject) => {
      if (typeof chrome === "undefined" || !chrome.tabs?.sendMessage) {
        reject(new Error("chrome.tabs.sendMessage unavailable"));
        return;
      }
      chrome.tabs.sendMessage(tabId, message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
    try {
      return await trySend();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : "";
      if (!messageText.includes("Receiving end does not exist") || typeof chrome === "undefined" || !chrome.scripting?.executeScript) {
        throw error;
      }
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content-semantic.js"]
      });
      return trySend();
    }
  }
  async function requestViewportCapture() {
    try {
      const response = await sendRuntimeMessage2({ type: "CAPTURE_VIEWPORT" });
      return response.viewport;
    } catch {
      return null;
    }
  }
  function getSelectedSemanticSnapshot() {
    return selectSnapshotById(
      state.semanticSnapshotHistory,
      state.selectedSemanticSnapshotId,
      state.latestSemanticSnapshot?.snapshot ?? null
    );
  }
  function getDisabledContextRestrictions(snapshot) {
    if (!snapshot || "text" in snapshot.focus.node) {
      return [];
    }
    return [
      {
        profile: "reply-assist",
        reason: INTERACTIVE_CONTEXT_RESTRICTION
      },
      {
        profile: "claim-extraction",
        reason: INTERACTIVE_CONTEXT_RESTRICTION
      }
    ];
  }
  function findRegionDumpEntry(dump, regionId) {
    if (!dump || !regionId) {
      return null;
    }
    return dump.regions.find((region) => region.id === regionId) ?? null;
  }
  function isProfileRestricted(restrictions, profile) {
    return restrictions.some((restriction) => restriction.profile === profile);
  }
  function getRestrictionReason(restrictions, profile) {
    return restrictions.find((restriction) => restriction.profile === profile)?.reason ?? null;
  }
  function describeSuppression(region) {
    if (!region.autoSuppressed) {
      return "active";
    }
    return region.explicitSelectionAllowed ? "suppressed (explicit selection allowed)" : "suppressed";
  }
  function buildSelectionResolutionNote(snapshot, selectedTarget, dumpState) {
    if (!snapshot || !selectedTarget || !dumpState?.dump) {
      return null;
    }
    const selectedRegion = findRegionDumpEntry(dumpState.dump, selectedTarget.regionId);
    if (selectedTarget.regionId !== snapshot.focus.region) {
      if (selectedRegion?.autoSuppressed) {
        return `Selected region ${selectedTarget.regionId} is suppressed, so focus fell back to ${snapshot.focus.region}.`;
      }
      return `Selected region ${selectedTarget.regionId} is no longer focusable, so focus resolved to ${snapshot.focus.region}.`;
    }
    if (selectedRegion?.autoSuppressed) {
      return "Explicit selection kept a suppressed region because direct selection is allowed.";
    }
    return null;
  }
  function buildDebugState(snapshot, selectedTarget, dumpState) {
    if (!snapshot) {
      return {
        status: dumpState?.error ?? "No semantic snapshot selected.",
        info: null
      };
    }
    if (!dumpState?.dump) {
      return {
        status: dumpState?.error ?? "No region dump loaded.",
        info: null
      };
    }
    const focusRegion = findRegionDumpEntry(dumpState.dump, snapshot.focus.region);
    if (!focusRegion) {
      return {
        status: "Focused region is not present in the current tab dump.",
        info: null
      };
    }
    const notes = [];
    if (snapshot.page.url !== dumpState.dump.url) {
      notes.push("Selected snapshot URL does not match the current tab dump.");
    }
    const selectionNote = buildSelectionResolutionNote(snapshot, selectedTarget, dumpState);
    if (selectionNote) {
      notes.push(selectionNote);
    }
    return {
      status: `Current region dump \xB7 ${dumpState.dump.url}`,
      info: {
        regionId: focusRegion.id,
        primitive: focusRegion.primitive,
        subtype: focusRegion.subtype ?? "(none)",
        category: focusRegion.category,
        layoutRole: focusRegion.layoutRole,
        roleRank: focusRegion.roleRank,
        suppression: describeSuppression(focusRegion),
        normalizedKind: focusRegion.normalizedKind ?? "(none)",
        assembledItemCount: String(focusRegion.assembledItemCount),
        signals: focusRegion.signals.join(", ") || "(none)",
        ...notes.length > 0 ? { note: notes.join(" ") } : {}
      }
    };
  }
  function renderSemanticSnapshotState(errorOverride) {
    const snapshot = getSelectedSemanticSnapshot();
    let contextPreview = "No semantic snapshot selected.";
    let contextAvailable = false;
    let contextStatus = "No semantic snapshot selected.";
    const contextRestrictions = getDisabledContextRestrictions(snapshot);
    const interactiveRestricted = snapshot !== null && isProfileRestricted(contextRestrictions, state.semanticContextProfile) && !("text" in snapshot.focus.node);
    const selectionResolutionNote = buildSelectionResolutionNote(snapshot, state.selectedTarget, state.latestRegionDump);
    const debugState = buildDebugState(snapshot, state.selectedTarget, state.latestRegionDump);
    if (snapshot) {
      const pack = (0, import_shared3.buildContextPack)(snapshot);
      if (interactiveRestricted) {
        contextStatus = "Interactive snapshots support branch-summary only.";
        contextPreview = getRestrictionReason(contextRestrictions, state.semanticContextProfile) ?? INTERACTIVE_CONTEXT_RESTRICTION;
      } else {
        contextAvailable = true;
        contextStatus = `${state.semanticContextProfile} \xB7 ${state.semanticContextFormat}`;
        contextPreview = state.semanticContextFormat === "context-pack-json" ? (0, import_projection_policy.renderContextPack)(pack) : state.semanticContextFormat === "compact-json" ? (0, import_projection_policy.renderCompactJson)(pack, state.semanticContextProfile) : (0, import_projection_policy.renderLinearText)(pack, state.semanticContextProfile);
      }
    }
    renderSemanticSnapshot({
      snapshot,
      error: errorOverride ?? state.latestSemanticSnapshot?.error ?? null,
      history: state.semanticSnapshotHistory,
      selectedSnapshotId: state.selectedSemanticSnapshotId,
      rawVisible: state.semanticRawVisible,
      selectionEnabled: state.selectionEnabled,
      selectedTarget: state.selectedTarget,
      contextProfile: state.semanticContextProfile,
      contextFormat: state.semanticContextFormat,
      contextPreview,
      contextAvailable,
      contextStatus,
      contextRestrictions,
      selectionResolutionNote,
      debugStatus: debugState.status,
      debugInfo: debugState.info
    });
    renderConversationState();
  }
  function updateSemanticSnapshot(payload) {
    state.latestSemanticSnapshot = payload;
    if (payload.snapshot) {
      state.selectedSemanticSnapshotId = payload.snapshot.meta.capturedAt;
    }
    renderSemanticSnapshotState();
  }
  function updateSemanticRegionDump(payload) {
    state.latestRegionDump = payload;
    renderSemanticSnapshotState();
  }
  function updateSemanticSnapshotHistory(payload) {
    state.semanticSnapshotHistory = payload.snapshots;
    if (!state.selectedSemanticSnapshotId && payload.snapshots[0]) {
      state.selectedSemanticSnapshotId = payload.snapshots[0].meta.capturedAt;
    }
    renderSemanticSnapshotState();
  }
  function updateSelectionState(payload) {
    state.selectionEnabled = payload.enabled;
    state.selectedTarget = payload.selectedTarget;
    renderSemanticSnapshotState();
  }
  async function hydrateSemanticSnapshot(tabId) {
    try {
      const payload = await sendRuntimeMessage2(
        typeof tabId === "number" ? {
          type: "GET_LATEST_SEMANTIC_SNAPSHOT",
          payload: { tabId }
        } : {
          type: "GET_LATEST_SEMANTIC_SNAPSHOT"
        }
      );
      updateSemanticSnapshot(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed to load semantic snapshot";
      renderSemanticSnapshotState(message);
    }
  }
  async function hydrateSemanticSnapshotHistory(tabId) {
    try {
      const payload = await sendRuntimeMessage2(
        typeof tabId === "number" ? {
          type: "GET_SEMANTIC_SNAPSHOT_HISTORY",
          payload: { tabId }
        } : {
          type: "GET_SEMANTIC_SNAPSHOT_HISTORY"
        }
      );
      updateSemanticSnapshotHistory(payload);
    } catch {
      updateSemanticSnapshotHistory({ tabId: tabId ?? null, snapshots: [] });
    }
  }
  async function hydrateSelectionState(tabId) {
    try {
      const payload = await sendRuntimeMessage2(
        typeof tabId === "number" ? {
          type: "GET_SEMANTIC_SELECTION_STATE",
          payload: { tabId }
        } : {
          type: "GET_SEMANTIC_SELECTION_STATE"
        }
      );
      updateSelectionState(payload);
    } catch {
      updateSelectionState({ tabId: tabId ?? null, enabled: false, selectedTarget: null });
    }
  }
  async function hydrateSemanticRegionDump(tabId) {
    try {
      const payload = await sendRuntimeMessage2(
        typeof tabId === "number" ? {
          type: "GET_SEMANTIC_REGION_DUMP",
          payload: { tabId }
        } : {
          type: "GET_SEMANTIC_REGION_DUMP"
        }
      );
      updateSemanticRegionDump(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed to load semantic region dump";
      updateSemanticRegionDump({ tabId: tabId ?? null, dump: null, error: message });
    }
  }
  async function requestSemanticSnapshot(options = {}) {
    const { suppressErrors = false, source = "sidepanel" } = options;
    setSemanticSnapshotBusy(true);
    try {
      const payload = await sendRuntimeMessage2(
        typeof state.activeTabId === "number" ? {
          type: "REQUEST_SEMANTIC_SNAPSHOT",
          payload: { tabId: state.activeTabId, source }
        } : {
          type: "REQUEST_SEMANTIC_SNAPSHOT",
          payload: { source }
        }
      );
      updateSemanticSnapshot(payload);
      if (payload.error && !suppressErrors) {
        showNotify(payload.error, "error");
      }
      await hydrateSemanticSnapshotHistory(state.activeTabId ?? void 0);
      await hydrateSemanticRegionDump(state.activeTabId ?? void 0);
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed to capture semantic snapshot";
      renderSemanticSnapshotState(message);
      if (!suppressErrors) {
        showNotify(message, "error");
      }
    } finally {
      setSemanticSnapshotBusy(false);
    }
  }
  async function copySemanticSnapshot() {
    const snapshot = getSelectedSemanticSnapshot();
    if (!snapshot) {
      showNotify("No semantic snapshot to copy.", "error");
      return;
    }
    await navigator.clipboard.writeText(JSON.stringify(snapshot, null, 2));
    showNotify("Semantic snapshot copied.", "success");
  }
  async function copySemanticContext() {
    const snapshot = getSelectedSemanticSnapshot();
    if (!snapshot) {
      showNotify("No semantic snapshot to derive LLM context from.", "error");
      return;
    }
    const restrictions = getDisabledContextRestrictions(snapshot);
    if (isProfileRestricted(restrictions, state.semanticContextProfile)) {
      showNotify(getRestrictionReason(restrictions, state.semanticContextProfile) ?? INTERACTIVE_CONTEXT_RESTRICTION, "info");
      return;
    }
    const pack = (0, import_shared3.buildContextPack)(snapshot);
    const output = state.semanticContextFormat === "context-pack-json" ? (0, import_projection_policy.renderContextPack)(pack) : state.semanticContextFormat === "compact-json" ? (0, import_projection_policy.renderCompactJson)(pack, state.semanticContextProfile) : (0, import_projection_policy.renderLinearText)(pack, state.semanticContextProfile);
    await navigator.clipboard.writeText(output);
    showNotify("LLM context copied.", "success");
  }
  async function toggleSemanticSelection() {
    const payload = await sendRuntimeMessage2(
      typeof state.activeTabId === "number" ? {
        type: "TOGGLE_SEMANTIC_SELECTION",
        payload: { tabId: state.activeTabId }
      } : {
        type: "TOGGLE_SEMANTIC_SELECTION"
      }
    );
    updateSelectionState(payload);
    showNotify(payload.enabled ? "Selection mode enabled." : "Selection mode disabled.", "info");
  }
  async function clearSemanticSelection() {
    const payload = await sendRuntimeMessage2(
      typeof state.activeTabId === "number" ? {
        type: "CLEAR_SEMANTIC_SELECTION",
        payload: { tabId: state.activeTabId }
      } : {
        type: "CLEAR_SEMANTIC_SELECTION"
      }
    );
    updateSelectionState(payload);
    showNotify("Semantic selection cleared.", "info");
  }
  function toggleSemanticRawView() {
    state.semanticRawVisible = !state.semanticRawVisible;
    renderSemanticSnapshotState();
  }
  function selectSemanticSnapshot(snapshotId) {
    state.selectedSemanticSnapshotId = snapshotId;
    renderSemanticSnapshotState();
    void hydrateSemanticRegionDump(state.activeTabId ?? void 0);
  }
  function selectSemanticContextProfile(profile) {
    const snapshot = getSelectedSemanticSnapshot();
    const restrictions = getDisabledContextRestrictions(snapshot);
    if (isProfileRestricted(restrictions, profile)) {
      showNotify(getRestrictionReason(restrictions, profile) ?? INTERACTIVE_CONTEXT_RESTRICTION, "info");
      return;
    }
    state.semanticContextProfile = profile;
    renderSemanticSnapshotState();
  }
  function selectSemanticContextFormat(format) {
    state.semanticContextFormat = format;
    renderSemanticSnapshotState();
  }
  async function handleRuntimeToolRequest(event) {
    if (event.payload.kind === "context.enrich") {
      try {
        const args = event.payload.args;
        if (!args.requestKind || !args.targetRef) {
          throw new Error("runtime enrich request is missing requestKind or targetRef");
        }
        const payload = await buildContextEnrichResult({
          requestKind: args.requestKind,
          targetRef: args.targetRef
        });
        return {
          toolRequestId: event.payload.toolRequestId,
          kind: event.payload.kind,
          ok: true,
          result: {
            payload
          }
        };
      } catch (error) {
        return {
          toolRequestId: event.payload.toolRequestId,
          kind: event.payload.kind,
          ok: false,
          error: error instanceof Error ? error.message : "enrich handling failed"
        };
      }
    }
    if (event.payload.kind === "focus.node" || event.payload.kind === "present.content" || event.payload.kind === "copy.text" || event.payload.kind === "navigate.url") {
      const projection = event.payload.args.projection;
      if (projection) {
        await applyProjectionSideEffects(projection);
      }
      return {
        toolRequestId: event.payload.toolRequestId,
        kind: event.payload.kind,
        ok: true
      };
    }
    return {
      toolRequestId: event.payload.toolRequestId,
      kind: event.payload.kind,
      ok: false,
      error: "unsupported runtime frontend tool"
    };
  }
  async function startVoiceCapture() {
    const controller = state.conversationController;
    if (!controller?.inputSupported) {
      showNotify("Voice input is unavailable in this browser.", "info");
      return;
    }
    if (!isConversationAuthReady()) {
      showNotify("Sign in with Google before starting voice input.", "info");
      return;
    }
    if (state.activeTabId === null) {
      showNotify("No active tab context.", "error");
      return;
    }
    if (!getConversationSnapshot()) {
      showNotify("Capture a semantic snapshot before starting voice input.", "info");
      return;
    }
    if (hasActiveRuntimeTurn()) {
      showNotify("Wait for the current answer to finish.", "info");
      return;
    }
    if (isSpeechListening() || isSpeechProcessing()) {
      return;
    }
    state.lastRuntimeError = null;
    clearSuggestChips();
    clearPresent();
    setComposerDraft("");
    state.pendingTurnOrigin = "voice";
    state.currentTurnOrigin = null;
    await state.conversationController?.transport.interrupt("superseded-by-voice-turn");
    await interruptVoiceSession("restart-voice-turn");
    const snapshot = getConversationSnapshot();
    if (!snapshot || state.activeTabId === null) {
      return;
    }
    try {
      state.runtimeSnapshot = snapshot;
      await controller.startVoiceTurn({
        activeTabId: state.activeTabId,
        snapshot,
        language: window.navigator.language
      });
      renderConversationState();
    } catch (error) {
      state.speechInputState = "error";
      state.speechInputDetail = error instanceof Error ? error.message : "Voice capture could not be started.";
      showNotify(state.speechInputDetail, "error");
      renderConversationState();
    }
  }
  async function finishVoiceCapture() {
    if (!isSpeechListening()) {
      return;
    }
    await state.conversationController?.finishVoiceTurn();
    renderConversationState();
  }
  async function cancelVoiceCapture() {
    if (!isSpeechListening() && !isSpeechProcessing()) {
      return;
    }
    await interruptVoiceSession("cancelled");
    renderConversationState();
  }
  function toggleVoiceOutput() {
    if (!state.conversationController?.outputSupported) {
      showNotify("Voice output is unavailable in this browser.", "info");
      return;
    }
    state.ttsEnabled = !state.ttsEnabled;
    persistTtsEnabled();
    state.conversationController.setVoiceOutputEnabled(state.ttsEnabled);
    renderConversationState();
  }
  function splitSuggestOptions(text) {
    return text.split(/[\n,]/).map((item) => item.trim()).filter(Boolean).slice(0, 4);
  }
  async function applyProjectionSideEffects(projection) {
    routeProjection(projection, {
      respond() {
      },
      focus(payload) {
        if (state.activeTabId === null) {
          return;
        }
        void sendToContentScript(state.activeTabId, {
          type: "EXECUTE_PROJECTION",
          projection: payload
        });
      },
      navigate(payload) {
        if (typeof chrome !== "undefined" && chrome.tabs?.create) {
          chrome.tabs.create({ url: payload.url, active: payload.options?.activate ?? true });
        }
      },
      present(payload) {
        renderPresent(payload.content);
      },
      notify(payload) {
        showNotify(payload.message, payload.level);
      },
      copy(payload) {
        void navigator.clipboard.writeText(payload.text);
      }
    });
  }
  async function executeProjection(projection) {
    routeProjection(projection, {
      respond(payload) {
        appendConversationMessage({
          role: "assistant",
          text: payload.text
        });
        if (payload.mode === "suggest") {
          const options = splitSuggestOptions(payload.text);
          showSuggestChips(options, (choice) => {
            void submitTextPrompt(choice, "text");
          });
          return;
        }
        clearSuggestChips();
      },
      focus(projection2) {
        void applyProjectionSideEffects(projection2);
      },
      navigate(payload) {
        void applyProjectionSideEffects({
          type: "navigate",
          payload
        });
      },
      present(payload) {
        void applyProjectionSideEffects({
          type: "present",
          payload
        });
      },
      notify(payload) {
        void applyProjectionSideEffects({
          type: "notify",
          payload
        });
      },
      copy(payload) {
        void applyProjectionSideEffects({
          type: "copy",
          payload
        });
      }
    });
  }
  function getSemanticNodeText(node) {
    if (node.kind === "interactive") {
      return node.label ?? node.valuePreview ?? "";
    }
    return node.text;
  }
  function asNonEmptyString(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }
  function buildEnrichBounds(region) {
    if (!region) {
      return void 0;
    }
    return {
      x: region.boundingRect.x,
      y: region.boundingRect.y,
      width: region.boundingRect.width,
      height: region.boundingRect.height
    };
  }
  function buildEnrichAttributes(snapshot, node, region) {
    const attributes = {
      "data-page-kind": snapshot.page.kind,
      "data-node-kind": node.kind,
      "data-region-id": snapshot.focus.region
    };
    if (region) {
      attributes["data-category"] = region.category;
      attributes["data-primitive"] = region.primitive;
      attributes["data-layout-role"] = region.layoutRole;
      attributes["data-role-rank"] = region.roleRank;
      if (region.subtype) {
        attributes["data-subtype"] = region.subtype;
      }
    }
    const selectedTarget = state.selectedTarget?.regionId === snapshot.focus.region ? state.selectedTarget : null;
    if (selectedTarget) {
      attributes["data-selection-category"] = selectedTarget.category;
      attributes["data-selection-primitive"] = selectedTarget.primitive;
      attributes["data-selection-label"] = selectedTarget.label;
    }
    if (node.kind === "content") {
      attributes["data-content-type"] = node.type;
      if (typeof node.level === "number") {
        attributes["data-heading-level"] = String(node.level);
      }
      for (const [key, value] of Object.entries(node.attributes ?? {})) {
        if (!value) {
          continue;
        }
        if (key === "role") {
          attributes.role = value;
          continue;
        }
        if (key === "title") {
          attributes.title = value;
          continue;
        }
        if (key.startsWith("data-") || key.startsWith("aria-")) {
          attributes[key] = value;
        }
      }
    }
    if (node.kind === "comment") {
      if (node.author) {
        attributes["data-author"] = node.author;
      }
      if (node.timestamp) {
        attributes["data-timestamp"] = node.timestamp;
      }
      attributes["data-depth"] = String(node.depth);
    }
    if (node.kind === "interactive") {
      attributes["data-control-type"] = node.controlType;
      if (node.role) {
        attributes.role = node.role;
      }
      if (node.label) {
        attributes.title = node.label;
      }
      if (node.action) {
        attributes["data-action"] = node.action;
      }
      if (node.state) {
        attributes["data-state"] = node.state;
      }
      if (node.options && node.options.length > 0) {
        attributes["data-options"] = node.options.join(" | ");
      }
    }
    return Object.keys(attributes).length > 0 ? attributes : void 0;
  }
  function getExpectedNodeId(targetRef) {
    return asNonEmptyString(targetRef.nodeId) ?? asNonEmptyString(targetRef.entityId);
  }
  async function buildContextEnrichResult(request) {
    const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
    const baseResult = {
      requestKind: request.requestKind,
      targetRef: request.targetRef,
      capturedAt
    };
    const snapshot = state.runtimeSnapshot ?? getSelectedSemanticSnapshot();
    if (!snapshot) {
      return {
        ...baseResult,
        status: "unsupported",
        failureReason: "no semantic snapshot is bound to the active turn"
      };
    }
    const expectedNodeId = getExpectedNodeId(request.targetRef);
    if (expectedNodeId && snapshot.focus.nodeId !== expectedNodeId) {
      return {
        ...baseResult,
        status: "unsupported",
        failureReason: "active semantic snapshot no longer matches the enrich target"
      };
    }
    const region = findRegionDumpEntry(state.latestRegionDump?.dump ?? null, snapshot.focus.region);
    const nodeText = getSemanticNodeText(snapshot.focus.node);
    const selectedTargetText = state.selectedTarget?.regionId === snapshot.focus.region ? state.selectedTarget.text.trim() : "";
    const text = selectedTargetText || nodeText;
    const detail = {
      captureScope: request.requestKind,
      pageUrl: snapshot.page.url,
      pageTitle: snapshot.page.title ?? null,
      nodeId: snapshot.focus.nodeId,
      regionId: snapshot.focus.region,
      text
    };
    const bounds = buildEnrichBounds(region);
    if (bounds) {
      detail.bounds = bounds;
    }
    const attributes = buildEnrichAttributes(snapshot, snapshot.focus.node, region);
    if (attributes) {
      detail.attributes = attributes;
    }
    if (request.requestKind === "node-detail") {
      return {
        ...baseResult,
        status: "ok",
        detail
      };
    }
    const viewport = await requestViewportCapture();
    if (!viewport) {
      return {
        ...baseResult,
        status: "failed",
        failureReason: "viewport capture unavailable for visual enrich request"
      };
    }
    detail.imageBase64 = viewport;
    return {
      ...baseResult,
      status: "ok",
      detail
    };
  }
  function createConversationController() {
    return new ConversationController({
      apiBaseUrl: state.apiBaseUrl,
      authClient,
      getActiveTabId: () => state.activeTabId,
      sendToContentScript,
      addRuntimeListener(listener) {
        chrome.runtime.onMessage.addListener(
          listener
        );
      },
      removeRuntimeListener(listener) {
        chrome.runtime.onMessage.removeListener(
          listener
        );
      },
      ttsEnabled: state.ttsEnabled,
      handlers: {
        onPhaseChange(phase) {
          setPhase(phase);
        },
        onSpeechStateChange(speechState, detail) {
          state.speechInputState = speechState;
          state.speechInputDetail = detail ?? null;
          renderConversationState();
        },
        onSessionReady(event) {
          state.sessionId = event.payload.sessionId;
          state.clientSessionId = event.payload.clientSessionId;
          state.lastRuntimeError = null;
        },
        onTurnStarted(event) {
          state.activeTurnId = event.turnId;
          state.lastRuntimeError = null;
          state.currentTurnOrigin = event.payload.modality;
          state.pendingTurnOrigin = null;
          renderConversationState();
        },
        onInputTranscript(text, final, event) {
          if (state.currentTurnOrigin === "voice") {
            upsertVoiceUserTranscript(text, final);
            return;
          }
          upsertConversationMessage({
            id: `turn-user-${event.turnId}`,
            role: "user",
            text,
            pending: !final
          });
        },
        onOutputTranscript(text, final) {
          if (state.currentTurnOrigin !== "voice") {
            return;
          }
          upsertVoiceAssistantTranscript(text, final);
        },
        onProjection(projection) {
          if (state.currentTurnOrigin === "voice" && projection.type === "respond") {
            return;
          }
          void executeProjection(projection);
        },
        async onToolRequest(event) {
          state.pendingEnrichRequest = event;
          renderConversationState();
          try {
            return await handleRuntimeToolRequest(event);
          } finally {
            state.pendingEnrichRequest = null;
            renderConversationState();
          }
        },
        onTurnDone() {
          state.activeTurnId = null;
          state.pendingEnrichRequest = null;
          state.lastRuntimeError = null;
          state.runtimeSnapshot = null;
          resetVoiceTranscriptState();
          clearTurnOrigin();
          renderConversationState();
        },
        onError(error) {
          state.activeTurnId = null;
          state.pendingEnrichRequest = null;
          state.lastRuntimeError = error;
          state.runtimeSnapshot = null;
          resetVoiceTranscriptState();
          clearTurnOrigin();
          stopLiveAudioOutput();
          showNotify(error.message, "error");
          renderConversationState();
        }
      }
    });
  }
  async function submitTextPrompt(prompt, origin = "text") {
    const normalized = prompt.trim();
    if (!normalized) {
      return;
    }
    if (!isConversationAuthReady()) {
      showNotify("Sign in with Google before asking about the current page.", "info");
      return;
    }
    if (state.activeTabId === null) {
      showNotify("No active tab context.", "error");
      return;
    }
    if (!getSelectedSemanticSnapshot()) {
      showNotify("Capture a semantic snapshot before asking a question.", "error");
      return;
    }
    if (hasActiveRuntimeTurn()) {
      showNotify("Wait for the current answer to finish.", "info");
      return;
    }
    await interruptVoiceSession("superseded-by-text-turn");
    setComposerDraft("");
    state.lastRuntimeError = null;
    state.pendingTurnOrigin = origin;
    state.currentTurnOrigin = null;
    clearSuggestChips();
    clearPresent();
    state.runtimeSnapshot = getSelectedSemanticSnapshot();
    if (!state.runtimeSnapshot) {
      return;
    }
    try {
      await state.conversationController?.sendTextTurn({
        activeTabId: state.activeTabId,
        snapshot: state.runtimeSnapshot,
        text: normalized,
        language: window.navigator.language
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed to send prompt to the unified runtime";
      state.activeTurnId = null;
      state.pendingEnrichRequest = null;
      state.runtimeSnapshot = null;
      clearTurnOrigin();
      state.lastRuntimeError = {
        code: "GENERATION_FAILED",
        message
      };
      setPhase("error");
      showNotify(message, "error");
      renderConversationState();
    }
  }
  function registerRuntimeListeners() {
    if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((message) => {
        if (message.type === "ACTIVE_TAB_CHANGED") {
          const tabChanged = state.activeTabId !== message.payload.tabId;
          if (tabChanged) {
            void interruptVoiceSession("active-tab-changed");
          }
          state.activeTabId = message.payload.tabId;
          if (tabChanged) {
            state.activeTurnId = null;
            state.pendingEnrichRequest = null;
            state.lastRuntimeError = null;
            state.runtimeSnapshot = null;
            clearTurnOrigin();
            state.latestSemanticSnapshot = null;
            state.latestRegionDump = null;
            state.semanticSnapshotHistory = [];
            state.selectedSemanticSnapshotId = null;
            state.selectionEnabled = false;
            state.selectedTarget = null;
            resetConversationSurface();
            renderSemanticSnapshotState();
          }
          setPhaseForUrl(message.payload.url);
          void hydrateSemanticSnapshot(message.payload.tabId);
          void hydrateSemanticSnapshotHistory(message.payload.tabId);
          void hydrateSelectionState(message.payload.tabId);
          void hydrateSemanticRegionDump(message.payload.tabId);
        }
        if (message.type === "ARTICLE_CONTENT") {
          state.contentGraph.addArticle(
            message.payload.url,
            message.payload.title,
            message.payload.text,
            message.payload.structure,
            message.payload.extractedAt
          );
        }
        if (message.type === "AUTH_STATE_CHANGED") {
          applyAuthState(message.payload);
        }
        if (message.type === "SEMANTIC_SNAPSHOT_READY") {
          updateSemanticSnapshot(message.payload);
          void hydrateSemanticRegionDump(message.payload.tabId ?? void 0);
          if (message.payload.error) {
            showNotify(message.payload.error, "error");
          }
        }
        if (message.type === "SEMANTIC_SNAPSHOT_HISTORY_UPDATED") {
          updateSemanticSnapshotHistory(message.payload);
          void hydrateSemanticRegionDump(message.payload.tabId ?? void 0);
        }
        if (message.type === "SEMANTIC_SELECTION_STATE_CHANGED") {
          updateSelectionState(message.payload);
          void hydrateSemanticRegionDump(message.payload.tabId ?? void 0);
        }
      });
    }
  }
  async function hydrateActiveTabState() {
    if (typeof chrome !== "undefined" && chrome.tabs?.query) {
      await new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          state.activeTabId = tabs[0]?.id ?? null;
          setPhaseForUrl(tabs[0]?.url ?? "");
          void hydrateSemanticSnapshot(state.activeTabId ?? void 0);
          void hydrateSemanticSnapshotHistory(state.activeTabId ?? void 0);
          void hydrateSelectionState(state.activeTabId ?? void 0);
          void hydrateSemanticRegionDump(state.activeTabId ?? void 0);
          resolve();
        });
      });
    }
  }
  async function hydrateAuthState() {
    applyAuthState(await authClient.getAuthState());
  }
  async function signInWithGoogle() {
    const next = await authClient.signInWithGoogle();
    applyAuthState(next);
    if (next.status === "signed-in") {
      showNotify("Signed in with Google.", "success");
      return;
    }
    if (next.errorMessage) {
      showNotify(next.errorMessage, next.status === "error" ? "error" : "info");
    }
  }
  async function signOut() {
    const next = await authClient.signOut();
    applyAuthState(next);
    showNotify("Signed out.", "info");
  }
  async function initialize() {
    setPhase("initializing");
    const config = await loadExtensionConfig(createChromeLocalStorage());
    state.apiBaseUrl = config.apiBaseUrl;
    state.conversationController = createConversationController();
    state.conversationController.setVoiceOutputEnabled(state.ttsEnabled);
    resetSpeechInputState();
    bindAuthActions({
      onSignIn: () => {
        void signInWithGoogle();
      },
      onSignOut: () => {
        void signOut();
      }
    });
    bindConversationActions({
      onComposerInput: (value) => {
        setComposerDraft(value);
        if (state.speechInputState === "error") {
          resetSpeechInputState();
        }
        renderConversationState();
      },
      onSubmitPrompt: (prompt) => {
        void submitTextPrompt(prompt, "text");
      },
      onStartMicPress: () => {
        void startVoiceCapture();
      },
      onEndMicPress: () => {
        void finishVoiceCapture();
      },
      onCancelMicPress: () => {
        void cancelVoiceCapture();
      },
      onToggleVoiceOutput: () => {
        toggleVoiceOutput();
      }
    });
    bindSemanticSnapshotActions({
      onCapture: () => {
        void requestSemanticSnapshot();
      },
      onCopy: () => {
        void copySemanticSnapshot();
      },
      onCopyContext: () => {
        void copySemanticContext();
      },
      onToggleSelection: () => {
        void toggleSemanticSelection();
      },
      onClearSelection: () => {
        void clearSemanticSelection();
      },
      onToggleRaw: () => {
        toggleSemanticRawView();
      },
      onSelectHistory: (snapshotId) => {
        selectSemanticSnapshot(snapshotId);
      },
      onSelectContextProfile: (profile) => {
        selectSemanticContextProfile(profile);
      },
      onSelectContextFormat: (format) => {
        selectSemanticContextFormat(format);
      }
    });
    renderAuthState();
    renderSemanticSnapshotState();
    renderConversationState();
    registerRuntimeListeners();
    await Promise.all([hydrateActiveTabState(), hydrateAuthState()]);
    window.addEventListener("beforeunload", () => {
      void state.conversationController?.close();
    });
  }
  void initialize().catch((error) => {
    setPhase("error");
    showNotify(error instanceof Error ? error.message : "failed to initialize", "error");
  });
})();
//# sourceMappingURL=console.js.map
