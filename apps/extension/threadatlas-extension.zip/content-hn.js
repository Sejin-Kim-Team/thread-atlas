"use strict";
(() => {
  // src/content/content-hn-utils.ts
  function parseDepthFromRow(row) {
    const indentRaw = row.querySelector(".ind")?.getAttribute("indent");
    if (!indentRaw) {
      return 0;
    }
    const parsed = Number.parseInt(indentRaw, 10);
    return Number.isFinite(parsed) ? parsed : 0;
  }
  function parseCommentRows(rows) {
    const parsedRows = [];
    const stack = [];
    for (const row of rows) {
      const id = row.getAttribute("id") ?? "";
      const depth = parseDepthFromRow(row);
      while (stack.length > 0 && (stack.at(-1)?.depth ?? 0) >= depth) {
        stack.pop();
      }
      const parentId = stack.at(-1)?.id ?? null;
      parsedRows.push({
        id,
        author: row.querySelector(".hnuser")?.textContent?.trim() ?? "",
        text: row.querySelector(".commtext")?.textContent?.trim() ?? "",
        depth,
        parentId,
        ageText: row.querySelector(".age")?.textContent?.trim() ?? null
      });
      stack.push({ id, depth });
    }
    return parsedRows;
  }
  function parseCommentsFromDocument(doc) {
    const commentRows = doc.querySelectorAll("tr.athing.comtr");
    return parseCommentRows(commentRows).map((row) => ({
      id: row.id,
      author: row.author,
      text: row.text,
      depth: row.depth,
      score: null,
      parentId: row.parentId,
      timestamp: Date.now()
    }));
  }
  function parseThreadDocFromDocument(doc, url) {
    const title = doc.querySelector(".titleline a")?.textContent?.trim() ?? "";
    const submitter = doc.querySelector(".hnuser")?.textContent?.trim() ?? "";
    const scoreText = doc.querySelector(".score")?.textContent ?? "0";
    const score = Number.parseInt(scoreText, 10) || 0;
    return {
      url,
      title,
      submitter,
      score,
      comments: parseCommentsFromDocument(doc)
    };
  }
  function parseVisibleComments(rows, viewportHeight, getRect) {
    const visible = [];
    for (const row of rows) {
      const rect = getRect(row);
      if (rect.top < viewportHeight && rect.bottom > 0) {
        const text = row.querySelector(".commtext")?.textContent?.trim() ?? "";
        visible.push({
          commentId: row.getAttribute("id") ?? "",
          author: row.querySelector(".hnuser")?.textContent?.trim() ?? "",
          textPreview: text.slice(0, 150),
          depth: parseDepthFromRow(row),
          scoreIfAvailable: null
        });
      }
    }
    return visible;
  }
  function deriveSelectedText(fullText, selectedText) {
    const index = fullText.indexOf(selectedText);
    if (index < 0) {
      return selectedText.slice(0, 200);
    }
    const start = Math.max(0, index - 100);
    const end = Math.min(fullText.length, index + selectedText.length + 100);
    return fullText.slice(start, end);
  }
  function selectionFromWindow(selection) {
    if (!selection || selection.isCollapsed) {
      return null;
    }
    const text = selection.toString().trim();
    if (!text) {
      return null;
    }
    const anchor = selection.anchorNode;
    const anchorElement = anchor?.parentElement ?? null;
    const row = anchorElement?.closest("tr.athing.comtr");
    const commentId = row?.getAttribute("id") ?? null;
    const fullText = row?.querySelector(".commtext")?.textContent ?? "";
    return {
      text,
      commentId,
      surroundingContext: deriveSelectedText(fullText, text)
    };
  }

  // src/content/content-hn.ts
  var lastHoveredCommentId = null;
  function detectHNPageType() {
    const url = window.location.href;
    if (/news\.ycombinator\.com\/item\?id=\d+/.test(url)) {
      return "hn_thread";
    }
    return "hn_other";
  }
  function parseThreadDoc() {
    return parseThreadDocFromDocument(document, window.location.href);
  }
  function extractArticleUrl() {
    const titleLink = document.querySelector(".titleline a");
    if (!titleLink) {
      return null;
    }
    if (titleLink.href.includes("news.ycombinator.com")) {
      return null;
    }
    return titleLink.href;
  }
  function getVisibleComments() {
    const rows = Array.from(document.querySelectorAll("tr.athing.comtr"));
    return parseVisibleComments(rows, window.innerHeight, (row) => row.getBoundingClientRect());
  }
  function getFocusedComment() {
    if (!lastHoveredCommentId) {
      return null;
    }
    const row = document.getElementById(lastHoveredCommentId);
    if (!row) {
      return null;
    }
    return {
      commentId: lastHoveredCommentId,
      text: (row.querySelector(".commtext")?.textContent ?? "").slice(0, 150),
      source: "hover"
    };
  }
  function getPageStructure() {
    const headings = Array.from(document.querySelectorAll("h1,h2,h3,h4,h5,h6")).map((heading) => ({
      level: Number.parseInt(heading.tagName.slice(1), 10),
      text: heading.textContent?.trim() ?? ""
    }));
    const landmarks = Array.from(document.querySelectorAll("[role]")).map((element) => ({
      role: element.getAttribute("role") ?? "",
      label: element.getAttribute("aria-label") ?? ""
    }));
    const rows = Array.from(document.querySelectorAll("tr.athing.comtr"));
    const nestingDepth = rows.reduce((maxDepth, row) => {
      const raw = row.querySelector(".ind")?.getAttribute("indent");
      const depth = Number.parseInt(raw ?? "0", 10);
      return Number.isFinite(depth) ? Math.max(maxDepth, depth) : maxDepth;
    }, 0);
    return {
      headings,
      landmarks,
      commentCount: rows.length,
      nestingDepth
    };
  }
  function clearHighlightStyles() {
    for (const row of document.querySelectorAll("tr.athing.comtr")) {
      row.classList.remove("ta-highlight-primary", "ta-highlight-secondary", "ta-highlight-warning", "ta-dimmed");
      row.querySelectorAll(".ta-badge").forEach((badge) => badge.remove());
    }
  }
  function applyBadge(target, label) {
    const existing = target.querySelector(".ta-badge");
    if (existing) {
      existing.remove();
    }
    const badge = document.createElement("span");
    badge.className = "ta-badge";
    badge.textContent = label;
    const commtext = target.querySelector(".commtext");
    commtext?.appendChild(badge);
  }
  function styleClass(style) {
    switch (style) {
      case "secondary":
        return "ta-highlight-secondary";
      case "warning":
        return "ta-highlight-warning";
      default:
        return "ta-highlight-primary";
    }
  }
  function executeFocus(projection) {
    const target = document.getElementById(projection.payload.commentId);
    if (!target) {
      return;
    }
    clearHighlightStyles();
    target.classList.add(styleClass(projection.payload.options?.style));
    if (projection.payload.options?.label) {
      applyBadge(target, projection.payload.options.label);
    }
    if (projection.payload.options?.scroll !== false) {
      target.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }
  function executeFocusMultiple(projection) {
    clearHighlightStyles();
    const allRows = Array.from(document.querySelectorAll("tr.athing.comtr"));
    const selected = new Set(projection.payload.targets.map((target) => target.commentId));
    for (const row of allRows) {
      const id = row.getAttribute("id") ?? "";
      if (!selected.has(id)) {
        row.classList.add("ta-dimmed");
      }
    }
    for (const target of projection.payload.targets) {
      const row = document.getElementById(target.commentId);
      if (!row) {
        continue;
      }
      row.classList.add(styleClass(target.style));
      if (target.label) {
        applyBadge(row, target.label);
      }
    }
    const firstTarget = projection.payload.options?.scrollTo ?? projection.payload.targets[0]?.commentId;
    if (firstTarget) {
      document.getElementById(firstTarget)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }
  function collectSensors() {
    return {
      visibleComments: getVisibleComments(),
      focus: getFocusedComment(),
      selection: selectionFromWindow(window.getSelection()),
      structure: getPageStructure(),
      threadDoc: parseThreadDoc(),
      articleUrl: extractArticleUrl()
    };
  }
  function executeProjection(projection) {
    switch (projection.type) {
      case "focus":
        executeFocus(projection);
        break;
      case "focusMultiple":
        executeFocusMultiple(projection);
        break;
      default:
        break;
    }
  }
  function registerListeners() {
    document.addEventListener("mousemove", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      const row = target.closest("tr.athing.comtr");
      lastHoveredCommentId = row?.getAttribute("id") ?? null;
    });
    if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
        switch (msg.type) {
          case "COLLECT_SENSORS":
            sendResponse(collectSensors());
            return true;
          case "GET_THREAD_DOC":
            sendResponse({
              threadDoc: parseThreadDoc(),
              articleUrl: extractArticleUrl()
            });
            return true;
          case "EXECUTE_PROJECTION":
            executeProjection(msg.projection);
            sendResponse({ ok: true });
            return true;
          default:
            return false;
        }
      });
    }
  }
  if (detectHNPageType() === "hn_thread") {
    registerListeners();
  }
})();
//# sourceMappingURL=content-hn.js.map
