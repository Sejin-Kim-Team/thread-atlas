"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../packages/shared/dist/types/api.js
  var require_api = __commonJS({
    "../../packages/shared/dist/types/api.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/auth-session.js
  var require_auth_session = __commonJS({
    "../../packages/shared/dist/types/auth-session.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/article.js
  var require_article = __commonJS({
    "../../packages/shared/dist/types/article.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context.js
  var require_context = __commonJS({
    "../../packages/shared/dist/types/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context-pack.js
  var require_context_pack = __commonJS({
    "../../packages/shared/dist/types/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/intent.js
  var require_intent = __commonJS({
    "../../packages/shared/dist/types/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/memory.js
  var require_memory = __commonJS({
    "../../packages/shared/dist/types/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/projection.js
  var require_projection = __commonJS({
    "../../packages/shared/dist/types/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantic-snapshot.js
  var require_semantic_snapshot = __commonJS({
    "../../packages/shared/dist/types/semantic-snapshot.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantics.js
  var require_semantics = __commonJS({
    "../../packages/shared/dist/types/semantics.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/state.js
  var require_state = __commonJS({
    "../../packages/shared/dist/types/state.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/thread.js
  var require_thread = __commonJS({
    "../../packages/shared/dist/types/thread.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/constants/limits.js
  var require_limits = __commonJS({
    "../../packages/shared/dist/constants/limits.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.MAX_ACTIVE_TOPICS = exports.MAX_CONTEXT_TURNS = exports.TOKEN_RENEWAL_BUFFER_SECONDS = exports.TOKEN_TTL_SECONDS = exports.TOOL_TIMEOUT_MS = exports.LOOP_TIMEOUT_MS = exports.MAX_LOOPS = void 0;
      exports.MAX_LOOPS = 8;
      exports.LOOP_TIMEOUT_MS = 3e4;
      exports.TOOL_TIMEOUT_MS = 1e4;
      exports.TOKEN_TTL_SECONDS = 600;
      exports.TOKEN_RENEWAL_BUFFER_SECONDS = 120;
      exports.MAX_CONTEXT_TURNS = 10;
      exports.MAX_ACTIVE_TOPICS = 10;
    }
  });

  // ../../packages/shared/dist/constants/defaults.js
  var require_defaults = __commonJS({
    "../../packages/shared/dist/constants/defaults.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.CONTEXT_LIMITS = exports.EMPTY_CONVERSATION_CONTEXT = exports.DEFAULT_API_BASE_URL = exports.DEFAULT_USER_ID = void 0;
      var limits_1 = require_limits();
      exports.DEFAULT_USER_ID = "user_sungwoo";
      exports.DEFAULT_API_BASE_URL = "http://localhost:8080";
      exports.EMPTY_CONVERSATION_CONTEXT = {
        turns: [],
        activeTopics: [],
        threadUrl: ""
      };
      exports.CONTEXT_LIMITS = {
        maxTurns: limits_1.MAX_CONTEXT_TURNS,
        maxActiveTopics: limits_1.MAX_ACTIVE_TOPICS
      };
    }
  });

  // ../../packages/shared/dist/utils/context.js
  var require_context2 = __commonJS({
    "../../packages/shared/dist/utils/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.trimTurns = trimTurns;
      exports.appendTurn = appendTurn;
      exports.setActiveTopics = setActiveTopics;
      var defaults_1 = require_defaults();
      function trimTurns(turns) {
        if (turns.length <= defaults_1.CONTEXT_LIMITS.maxTurns) {
          return turns;
        }
        return turns.slice(turns.length - defaults_1.CONTEXT_LIMITS.maxTurns);
      }
      function appendTurn(context, turn) {
        return {
          ...context,
          turns: trimTurns([...context.turns, turn])
        };
      }
      function setActiveTopics(context, topics) {
        return {
          ...context,
          activeTopics: topics.slice(0, defaults_1.CONTEXT_LIMITS.maxActiveTopics)
        };
      }
    }
  });

  // ../../packages/shared/dist/utils/hash.js
  var require_hash = __commonJS({
    "../../packages/shared/dist/utils/hash.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.hashUrl = hashUrl;
      function intToFixedHex(value) {
        return (value >>> 0).toString(16).padStart(8, "0");
      }
      function hashUrl(url) {
        let h1 = 2654435769;
        let h2 = 2246822507;
        for (let i = 0; i < url.length; i += 1) {
          const code = url.charCodeAt(i);
          h1 = Math.imul(h1 ^ code, 2246822519);
          h2 = Math.imul(h2 ^ code, 3266489917);
        }
        return `${intToFixedHex(h1)}${intToFixedHex(h2)}`.slice(0, 16);
      }
    }
  });

  // ../../packages/shared/dist/utils/context-pack.js
  var require_context_pack2 = __commonJS({
    "../../packages/shared/dist/utils/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = buildContextPack;
      exports.selectProjectionView = selectProjectionView;
      exports.renderContextPack = renderContextPack;
      exports.renderCompactJson = renderCompactJson;
      exports.renderLinearText = renderLinearText;
      function isCommentNode(node) {
        return node.kind === "comment";
      }
      function isInteractiveNode(node) {
        return node.kind === "interactive";
      }
      function toContextPackNode(node, relation, distance) {
        if (isCommentNode(node)) {
          return {
            id: node.id,
            kind: "comment",
            relation,
            distance,
            text: node.text,
            ...node.author ? { author: node.author } : {},
            ...node.timestamp ? { timestamp: node.timestamp } : {},
            depth: node.depth,
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        if (isInteractiveNode(node)) {
          return {
            id: node.id,
            kind: "interactive",
            relation,
            distance,
            text: node.label ?? node.valuePreview ?? "",
            controlType: node.controlType,
            ...node.action ? { action: node.action } : {},
            ...node.state ? { state: node.state } : {},
            ...node.role ? { role: node.role } : {},
            ...node.valuePreview ? { valuePreview: node.valuePreview } : {},
            ...node.label ? { label: node.label } : {},
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        return {
          id: node.id,
          kind: "content",
          relation,
          distance,
          text: node.text,
          contentType: node.type,
          ...node.level ? { level: node.level } : {},
          ...node.parentId ? { parentId: node.parentId } : {},
          ...node.attributes ? { metadata: node.attributes } : {}
        };
      }
      function mapSlices(snapshot, relation) {
        return snapshot.context.map((slice, originalIndex) => ({ slice, originalIndex })).filter(({ slice }) => slice.relation === relation).map(({ slice, originalIndex }) => ({
          ...toContextPackNode(slice.node, relation === "child" ? "descendant" : relation === "container" ? "container" : relation === "sibling" ? "sibling" : "ancestor", slice.distance),
          originalIndex
        }));
      }
      function buildOmitted(snapshot) {
        const coverage = snapshot.meta.coverage;
        if (!coverage) {
          return {
            nodeCount: 0,
            rootCount: 0,
            note: "Coverage metadata unavailable."
          };
        }
        return {
          nodeCount: coverage.omittedNodeCount,
          rootCount: coverage.omittedRootCount,
          note: `Only the ${coverage.kind} semantic scope is included.`
        };
      }
      function buildScope(snapshot) {
        const coverage = snapshot.meta.coverage;
        return {
          kind: coverage?.kind ?? (isCommentNode(snapshot.focus.node) ? "focus-branch" : "focus-section"),
          rootNodeId: coverage?.rootNodeId ?? snapshot.focus.nodeId,
          focusNodeId: snapshot.focus.nodeId
        };
      }
      function buildProjectionFocusNode(pack) {
        const { metadata: _metadata, relation: _relation, distance: _distance, ...focus } = pack.focus;
        return focus;
      }
      function includeByProfile(node, group, profile) {
        if (group === "containers") {
          return false;
        }
        if (profile === "branch-summary") {
          return true;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        if (group === "ancestors") {
          return node.distance === 1;
        }
        if (group === "descendants") {
          return node.distance === 1;
        }
        if (group === "siblings") {
          return node.distance === 1;
        }
        return false;
      }
      function formatNodeSummary(node) {
        const headerParts = [
          node.author,
          node.timestamp,
          node.kind === "interactive" && node.controlType ? node.controlType : null,
          node.kind === "interactive" && node.action ? node.action : null,
          node.kind === "interactive" && node.state ? node.state : null,
          node.kind === "content" && node.contentType ? node.contentType : null
        ].filter(Boolean);
        if (headerParts.length === 0) {
          return `- ${node.text || node.valuePreview || "(empty)"}`;
        }
        return `- ${headerParts.join(", ")}: ${node.text || node.valuePreview || "(empty)"}`;
      }
      function buildContextPack(snapshot) {
        const ancestors = [
          ...mapSlices(snapshot, "parent"),
          ...mapSlices(snapshot, "ancestor")
        ].sort((left, right) => right.distance - left.distance || left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const descendants = mapSlices(snapshot, "child").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const siblings = mapSlices(snapshot, "sibling").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const containers = mapSlices(snapshot, "container").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        return {
          version: 1,
          scope: buildScope(snapshot),
          page: {
            id: snapshot.page.id,
            url: snapshot.page.url,
            ...snapshot.page.title ? { title: snapshot.page.title } : {},
            kind: snapshot.page.kind,
            ...snapshot.page.metadata ? { metadata: snapshot.page.metadata } : {}
          },
          focus: toContextPackNode(snapshot.focus.node, "focus", 0),
          groups: {
            ancestors,
            descendants,
            siblings,
            containers
          },
          omitted: buildOmitted(snapshot),
          provenance: {
            extractorId: snapshot.meta.extractorId,
            capturedAt: snapshot.meta.capturedAt,
            skeletonVersion: snapshot.meta.skeletonVersion
          }
        };
      }
      function selectProjectionView(pack, profile) {
        const groups = {
          ancestors: pack.groups.ancestors.filter((node) => includeByProfile(node, "ancestors", profile)),
          descendants: pack.groups.descendants.filter((node) => includeByProfile(node, "descendants", profile)),
          siblings: pack.groups.siblings.filter((node) => includeByProfile(node, "siblings", profile)),
          containers: pack.groups.containers.filter((node) => includeByProfile(node, "containers", profile))
        };
        return {
          scope: pack.scope,
          page: {
            ...pack.page.title ? { title: pack.page.title } : {},
            url: pack.page.url,
            kind: pack.page.kind
          },
          focus: buildProjectionFocusNode(pack),
          groups,
          omitted: pack.omitted,
          provenance: {
            extractorId: pack.provenance.extractorId,
            capturedAt: pack.provenance.capturedAt
          }
        };
      }
      function renderContextPack(pack) {
        return JSON.stringify(pack, null, 2);
      }
      function renderCompactJson(pack, profile) {
        return JSON.stringify(selectProjectionView(pack, profile), null, 2);
      }
      function renderLinearText(pack, profile) {
        const view = selectProjectionView(pack, profile);
        const lines = [
          `Page: ${view.page.title ?? "(untitled)"}`,
          `URL: ${view.page.url}`,
          `Kind: ${view.page.kind}`,
          `Scope: ${view.scope.kind}`,
          ""
        ];
        const sections = [
          ["Ancestors", view.groups.ancestors],
          ["Focus", [pack.focus]],
          ["Descendants", view.groups.descendants],
          ["Siblings", view.groups.siblings]
        ];
        for (const [label, nodes] of sections) {
          const groupKey = label === "Ancestors" ? "ancestors" : label === "Descendants" ? "descendants" : label === "Siblings" ? "siblings" : null;
          if (groupKey && !projectionIncludesGroup(profile, groupKey)) {
            continue;
          }
          lines.push(label);
          if (nodes.length === 0) {
            lines.push("- none");
          } else {
            for (const node of nodes) {
              lines.push(formatNodeSummary(node));
            }
          }
          lines.push("");
        }
        lines.push("Omitted");
        lines.push(`- ${view.omitted.nodeCount} nodes omitted`);
        lines.push(`- ${view.omitted.rootCount} roots omitted`);
        lines.push(`- ${view.omitted.note}`);
        return lines.join("\n");
      }
      function projectionIncludesGroup(profile, group) {
        if (group === "containers") {
          return false;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        return true;
      }
    }
  });

  // ../../packages/shared/dist/factories/intent.js
  var require_intent2 = __commonJS({
    "../../packages/shared/dist/factories/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createUserSpeechIntent = createUserSpeechIntent;
      exports.createUserSelectionIntent = createUserSelectionIntent;
      exports.createPageNavigationIntent = createPageNavigationIntent;
      function createUserSpeechIntent(transcript, intentType = "general") {
        return {
          type: "UserSpeech",
          transcript,
          intentType
        };
      }
      function createUserSelectionIntent(transcript) {
        return {
          type: "UserSelection",
          transcript,
          intentType: "memory_query"
        };
      }
      function createPageNavigationIntent(transcript) {
        return {
          type: "PageNavigation",
          transcript,
          intentType: "navigation_request"
        };
      }
    }
  });

  // ../../packages/shared/dist/factories/memory.js
  var require_memory2 = __commonJS({
    "../../packages/shared/dist/factories/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createEmptyInterestProfile = createEmptyInterestProfile;
      exports.createMemoryDelta = createMemoryDelta;
      exports.mergeTopicDeltas = mergeTopicDeltas;
      function createEmptyInterestProfile() {
        return {
          topics: {},
          updatedAt: Date.now()
        };
      }
      function createMemoryDelta(topicDeltas, highlights = []) {
        return {
          interestProfile: { topicDeltas },
          threadHistory: {
            highlights,
            turnCountDelta: 1
          }
        };
      }
      function mergeTopicDeltas(base, incoming) {
        const merged = { ...base };
        for (const [topic, count] of Object.entries(incoming)) {
          merged[topic] = (merged[topic] ?? 0) + count;
        }
        return merged;
      }
    }
  });

  // ../../packages/shared/dist/factories/projection.js
  var require_projection2 = __commonJS({
    "../../packages/shared/dist/factories/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.respond = respond;
      exports.focus = focus;
      exports.focusMultiple = focusMultiple;
      exports.navigate = navigate;
      exports.present = present;
      exports.notify = notify;
      exports.copy = copy;
      function respond(text, mode = "answer") {
        return { type: "respond", payload: { text, mode } };
      }
      function focus(commentId, options) {
        if (options) {
          return { type: "focus", payload: { commentId, options } };
        }
        return { type: "focus", payload: { commentId } };
      }
      function focusMultiple(targets, options) {
        if (options) {
          return { type: "focusMultiple", payload: { targets, options } };
        }
        return { type: "focusMultiple", payload: { targets } };
      }
      function navigate(url, options) {
        if (options) {
          return { type: "navigate", payload: { url, options } };
        }
        return { type: "navigate", payload: { url } };
      }
      function present(target, content, persistent = false) {
        return {
          type: "present",
          payload: {
            target,
            content,
            options: { persistent }
          }
        };
      }
      function notify(message, level = "info") {
        return {
          type: "notify",
          payload: { message, level }
        };
      }
      function copy(text) {
        return { type: "copy", payload: { text } };
      }
    }
  });

  // ../../packages/shared/dist/domain.js
  var require_domain = __commonJS({
    "../../packages/shared/dist/domain.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = void 0;
      __exportStar(require_api(), exports);
      __exportStar(require_auth_session(), exports);
      __exportStar(require_article(), exports);
      __exportStar(require_context(), exports);
      __exportStar(require_context_pack(), exports);
      __exportStar(require_intent(), exports);
      __exportStar(require_memory(), exports);
      __exportStar(require_projection(), exports);
      __exportStar(require_semantic_snapshot(), exports);
      __exportStar(require_semantics(), exports);
      __exportStar(require_state(), exports);
      __exportStar(require_thread(), exports);
      __exportStar(require_defaults(), exports);
      __exportStar(require_limits(), exports);
      __exportStar(require_context2(), exports);
      __exportStar(require_hash(), exports);
      var context_pack_1 = require_context_pack2();
      Object.defineProperty(exports, "buildContextPack", { enumerable: true, get: function() {
        return context_pack_1.buildContextPack;
      } });
      __exportStar(require_intent2(), exports);
      __exportStar(require_memory2(), exports);
      __exportStar(require_projection2(), exports);
    }
  });

  // ../../packages/shared/dist/index.js
  var require_dist = __commonJS({
    "../../packages/shared/dist/index.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      __exportStar(require_domain(), exports);
    }
  });

  // src/common/semantic-url.ts
  function isSemanticCaptureSupportedUrl(url) {
    return /^https?:\/\//.test(url ?? "");
  }

  // src/sidepanel/auth-client.ts
  async function sendRuntimeMessage(message) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
        reject(new Error("chrome.runtime.sendMessage unavailable"));
        return;
      }
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
  }
  function createAuthClient() {
    return {
      async getAuthState() {
        return sendRuntimeMessage({ type: "GET_AUTH_STATE" });
      },
      async signInWithGoogle() {
        return sendRuntimeMessage({ type: "SIGN_IN_WITH_GOOGLE" });
      },
      async signOut() {
        return sendRuntimeMessage({ type: "SIGN_OUT" });
      },
      async issueToken() {
        const response = await sendRuntimeMessage({
          type: "ENSURE_AUTH_SESSION"
        });
        if (!response.ok || !response.token || !response.user || typeof response.expiresAt !== "number") {
          throw new Error(
            response.error ?? response.state.errorMessage ?? "No authenticated ThreadAtlas session is available."
          );
        }
        return {
          token: response.token,
          expiresAt: response.expiresAt,
          user: response.user
        };
      }
    };
  }

  // src/common/extension-config.ts
  var import_shared = __toESM(require_dist());
  var API_BASE_URL_KEY = "THREADATLAS_API_BASE_URL";
  var GOOGLE_OAUTH_CLIENT_ID_KEY = "THREADATLAS_GOOGLE_OAUTH_CLIENT_ID";
  var AUTH_GRANT_TYPE_KEY = "THREADATLAS_AUTH_GRANT_TYPE";
  var BOOTSTRAP_SUBJECT_KEY = "THREADATLAS_BOOTSTRAP_SUBJECT";
  var BOOTSTRAP_KEY_KEY = "THREADATLAS_AUTH_BOOTSTRAP_KEY";
  var DISPLAY_NAME_KEY = "THREADATLAS_AUTH_DISPLAY_NAME";
  var PRIMARY_EMAIL_KEY = "THREADATLAS_AUTH_PRIMARY_EMAIL";
  var AVATAR_URL_KEY = "THREADATLAS_AUTH_AVATAR_URL";
  var EXTENSION_CONFIG_KEYS = [
    API_BASE_URL_KEY,
    GOOGLE_OAUTH_CLIENT_ID_KEY,
    AUTH_GRANT_TYPE_KEY,
    BOOTSTRAP_SUBJECT_KEY,
    BOOTSTRAP_KEY_KEY,
    DISPLAY_NAME_KEY,
    PRIMARY_EMAIL_KEY,
    AVATAR_URL_KEY
  ];
  function normalizeText(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }
  function readCompiledApiBaseUrl() {
    if (true) {
      const normalized = normalizeText("http://localhost:8080");
      if (normalized) {
        return normalized;
      }
    }
    return import_shared.DEFAULT_API_BASE_URL;
  }
  function readCompiledGoogleClientId() {
    if (true) {
      return normalizeText("");
    }
    return null;
  }
  function createChromeLocalStorage(area = chrome.storage.local) {
    return {
      get(keys) {
        return new Promise((resolve, reject) => {
          area.get(keys, (items) => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve(items);
          });
        });
      },
      set(values) {
        return new Promise((resolve, reject) => {
          area.set(values, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      },
      remove(keys) {
        return new Promise((resolve, reject) => {
          area.remove(keys, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      }
    };
  }
  async function loadExtensionConfig(storage = createChromeLocalStorage()) {
    const stored = await storage.get(EXTENSION_CONFIG_KEYS);
    const apiBaseUrl = normalizeText(stored[API_BASE_URL_KEY]) ?? readCompiledApiBaseUrl();
    const googleOAuthClientId = normalizeText(stored[GOOGLE_OAUTH_CLIENT_ID_KEY]) ?? readCompiledGoogleClientId();
    const configuredGrant = normalizeText(stored[AUTH_GRANT_TYPE_KEY]);
    const bootstrapSubject = normalizeText(stored[BOOTSTRAP_SUBJECT_KEY]);
    const bootstrapKey = normalizeText(stored[BOOTSTRAP_KEY_KEY]);
    let devBootstrap = null;
    if (configuredGrant === "dev-bootstrap" && bootstrapSubject && bootstrapKey) {
      const profile = {};
      const displayName = normalizeText(stored[DISPLAY_NAME_KEY]);
      const primaryEmail = normalizeText(stored[PRIMARY_EMAIL_KEY]);
      const avatarUrl = normalizeText(stored[AVATAR_URL_KEY]);
      if (displayName) {
        profile.displayName = displayName;
      }
      if (primaryEmail) {
        profile.primaryEmail = primaryEmail;
      }
      if (avatarUrl) {
        profile.avatarUrl = avatarUrl;
      }
      devBootstrap = {
        bootstrapSubject,
        bootstrapKey,
        ...Object.keys(profile).length > 0 ? { profile } : {}
      };
    }
    return {
      apiBaseUrl,
      googleOAuthClientId,
      devBootstrap
    };
  }

  // src/sidepanel/audio-level.ts
  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }
  function measurePcm16Base64Level(base64) {
    const bytes = base64ToBytes(base64);
    if (bytes.byteLength < 2) {
      return 0;
    }
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const sampleCount = Math.floor(bytes.byteLength / 2);
    let total = 0;
    for (let index = 0; index < sampleCount; index += 1) {
      const sample = view.getInt16(index * 2, true) / 32768;
      total += sample * sample;
    }
    const rms = Math.sqrt(total / sampleCount);
    return Math.max(0, Math.min(1, rms * 4));
  }
  function decodePcm16Base64ToFloat32(base64) {
    const bytes = base64ToBytes(base64);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const sampleCount = Math.floor(bytes.byteLength / 2);
    const output = new Float32Array(sampleCount);
    for (let index = 0; index < sampleCount; index += 1) {
      const sample = view.getInt16(index * 2, true);
      output[index] = sample / 32768;
    }
    return output;
  }

  // src/sidepanel/content-audio-input.ts
  function makeCaptureSessionId() {
    return globalThis.crypto?.randomUUID?.() ?? `page-audio-${Date.now()}`;
  }
  var PageAudioInputProvider = class {
    constructor(args) {
      this.args = args;
      const hasInjectedRuntimeBridge = typeof args.addRuntimeListener === "function" && typeof args.removeRuntimeListener === "function";
      const hasChromeRuntimeBridge = typeof chrome !== "undefined" && Boolean(chrome.runtime?.onMessage);
      this.supported = typeof args.sendToContentScript === "function" && (hasInjectedRuntimeBridge || hasChromeRuntimeBridge);
      this.state = this.supported ? "idle" : "unsupported";
      this.runtimeListener = (message, sender) => {
        this.handleRuntimeMessage(message, sender);
      };
      if (this.supported) {
        ;
        (args.addRuntimeListener ?? this.addChromeRuntimeListener)(this.runtimeListener);
      }
    }
    supported;
    onLevel;
    onChunkBase64;
    onError;
    onStateChange;
    currentSessionId = null;
    currentTabId = null;
    state;
    stopPromise = null;
    resolveStop = null;
    rejectStop = null;
    runtimeListener;
    async start() {
      if (!this.supported) {
        throw new Error("Voice input is unavailable in this browser.");
      }
      const tabId = this.args.getActiveTabId();
      if (tabId === null) {
        throw new Error("No active tab context.");
      }
      await this.cancel();
      const sessionId = makeCaptureSessionId();
      this.currentSessionId = sessionId;
      this.currentTabId = tabId;
      this.clearStopPromise();
      this.emitState("processing");
      const response = await this.args.sendToContentScript(tabId, {
        type: "START_PAGE_AUDIO_CAPTURE",
        payload: {
          sessionId
        }
      });
      if (!response.ok) {
        this.emitError(response.error ?? "Voice input could not be started on the page.");
        throw new Error(response.error ?? "Voice input could not be started on the page.");
      }
    }
    async stop() {
      if (!this.currentSessionId || this.currentTabId === null) {
        return;
      }
      this.emitState("processing");
      this.stopPromise = new Promise((resolve, reject) => {
        this.resolveStop = resolve;
        this.rejectStop = reject;
      });
      const response = await this.args.sendToContentScript(this.currentTabId, {
        type: "STOP_PAGE_AUDIO_CAPTURE",
        payload: {
          sessionId: this.currentSessionId
        }
      });
      if (!response.ok) {
        const error = new Error(response.error ?? "Voice input could not be stopped on the page.");
        this.rejectStop?.(error);
        this.clearStopPromise();
        this.emitError(error.message);
        throw error;
      }
      await Promise.race([
        this.stopPromise,
        new Promise((_, reject) => {
          window.setTimeout(() => {
            reject(new Error("Voice input did not finish stopping on the page."));
          }, 1500);
        })
      ]).catch((error) => {
        const message = error instanceof Error ? error.message : "Voice input did not finish stopping on the page.";
        this.emitError(message);
        throw new Error(message);
      });
    }
    async cancel() {
      const sessionId = this.currentSessionId;
      const tabId = this.currentTabId;
      this.currentSessionId = null;
      this.currentTabId = null;
      this.clearStopPromise();
      if (!sessionId || tabId === null) {
        if (this.supported && this.state !== "unsupported") {
          this.onLevel?.(0);
          this.emitState("idle");
        }
        return;
      }
      try {
        await this.args.sendToContentScript(tabId, {
          type: "CANCEL_PAGE_AUDIO_CAPTURE",
          payload: {
            sessionId
          }
        });
      } catch {
      }
      if (this.supported) {
        this.onLevel?.(0);
        this.emitState("idle");
      }
    }
    dispose() {
      void this.cancel();
      if (this.supported) {
        ;
        (this.args.removeRuntimeListener ?? this.removeChromeRuntimeListener)(this.runtimeListener);
      }
    }
    handleRuntimeMessage(message, sender) {
      if (sender.tab?.id != null) {
        return;
      }
      const payload = "payload" in message ? message.payload : void 0;
      if (payload?.tabId !== this.currentTabId) {
        return;
      }
      switch (message.type) {
        case "PAGE_AUDIO_CAPTURE_STATE_CHANGED":
          if (message.payload.sessionId !== this.currentSessionId) {
            return;
          }
          if (message.payload.state === "idle") {
            this.currentSessionId = null;
            this.currentTabId = null;
            this.resolveStop?.();
            this.clearStopPromise();
            return;
          }
          this.emitState(message.payload.state, message.payload.detail);
          if (message.payload.state === "error") {
            this.emitError(message.payload.detail ?? "Voice input failed.");
          }
          if (message.payload.state === "unsupported") {
            this.currentSessionId = null;
            this.currentTabId = null;
            this.clearStopPromise();
          }
          return;
        case "PAGE_AUDIO_CAPTURE_CHUNK":
          if (message.payload.sessionId !== this.currentSessionId) {
            return;
          }
          this.onLevel?.(measurePcm16Base64Level(message.payload.chunkBase64));
          this.onChunkBase64?.(message.payload.chunkBase64);
          return;
        default:
          return;
      }
    }
    emitState(state2, detail) {
      this.state = state2;
      this.onStateChange?.(state2, detail);
    }
    emitError(message) {
      const error = new Error(message);
      this.rejectStop?.(error);
      this.clearStopPromise();
      this.currentSessionId = null;
      this.currentTabId = null;
      this.onLevel?.(0);
      this.emitState("error", message);
      this.onError?.(error);
    }
    clearStopPromise() {
      this.stopPromise = null;
      this.resolveStop = null;
      this.rejectStop = null;
    }
    addChromeRuntimeListener(listener) {
      chrome.runtime.onMessage.addListener(listener);
    }
    removeChromeRuntimeListener(listener) {
      chrome.runtime.onMessage.removeListener(listener);
    }
  };

  // src/sidepanel/live-audio-output.ts
  var LiveAudioOutputPlayer = class {
    supported;
    onLevel;
    audioContext = null;
    activeSources = /* @__PURE__ */ new Set();
    nextPlaybackTime = 0;
    constructor() {
      this.supported = typeof AudioContext !== "undefined";
    }
    async playChunk(chunkBase64) {
      if (!this.supported) {
        return;
      }
      const context = this.ensureContext();
      await context.resume();
      const float32 = decodePcm16Base64ToFloat32(chunkBase64);
      this.onLevel?.(measurePcm16Base64Level(chunkBase64));
      const audioBuffer = context.createBuffer(1, float32.length, 24e3);
      audioBuffer.copyToChannel(Float32Array.from(float32), 0);
      const source = context.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(context.destination);
      const startTime = Math.max(context.currentTime, this.nextPlaybackTime);
      this.nextPlaybackTime = startTime + audioBuffer.duration;
      source.start(startTime);
      this.activeSources.add(source);
      source.onended = () => {
        this.activeSources.delete(source);
      };
    }
    stop() {
      this.onLevel?.(0);
      for (const source of this.activeSources) {
        try {
          source.stop();
        } catch {
        }
      }
      this.activeSources.clear();
      this.nextPlaybackTime = 0;
    }
    async dispose() {
      this.stop();
      if (this.audioContext) {
        await this.audioContext.close();
        this.audioContext = null;
      }
    }
    ensureContext() {
      if (!this.audioContext) {
        this.audioContext = new AudioContext({ sampleRate: 24e3 });
      }
      return this.audioContext;
    }
  };

  // src/sidepanel/runtime-transport.ts
  function makeTimestamp() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  function makeRequestId(prefix) {
    const random = globalThis.crypto?.randomUUID?.() ?? Math.random().toString(16).slice(2);
    return `${prefix}-${random}`;
  }
  function makeClientSessionId() {
    return globalThis.crypto?.randomUUID?.() ?? `runtime-${Date.now()}`;
  }
  function toWebSocketUrl(apiBaseUrl, token) {
    const url = new URL(apiBaseUrl);
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
    url.pathname = "/ws/runtime";
    url.search = "";
    url.searchParams.set("token", token);
    return url.toString();
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function isRuntimeV2ServerEnvelope(value) {
    return isRecord(value) && typeof value.type === "string" && typeof value.timestamp === "string" && isRecord(value.payload);
  }
  var RuntimeTransport = class {
    constructor(args) {
      this.args = args;
    }
    clientSessionId = makeClientSessionId();
    ws = null;
    sessionId = null;
    activeTurnId = null;
    connectPromise = null;
    resolveSessionReady = null;
    rejectSessionReady = null;
    async sendTextTurn(input) {
      const normalized = input.text.trim();
      if (!normalized) {
        throw new Error("text input is required");
      }
      if (this.activeTurnId) {
        await this.interrupt("superseded-by-new-turn");
      }
      await this.ensureSession(input.language);
      await this.syncContextSnapshot(input.activeTabId, input.snapshot);
      const sessionId = this.sessionId;
      if (!sessionId) {
        throw new Error("runtime session is not ready");
      }
      this.args.handlers.onPhaseChange?.("sending-intent");
      this.send({
        type: "turn.input.text",
        requestId: makeRequestId("turn-text"),
        timestamp: makeTimestamp(),
        sessionId,
        payload: {
          text: normalized
        }
      });
    }
    async startVoiceTurn(input) {
      if (this.activeTurnId) {
        await this.interrupt("superseded-by-new-turn");
      }
      await this.ensureSession(input.language);
      await this.syncContextSnapshot(input.activeTabId, input.snapshot);
    }
    appendAudioChunk(chunkBase64) {
      const sessionId = this.sessionId;
      if (!sessionId) {
        throw new Error("runtime session is not ready");
      }
      this.send({
        type: "turn.input.audio.append",
        requestId: makeRequestId("turn-audio"),
        timestamp: makeTimestamp(),
        sessionId,
        payload: {
          chunkBase64
        }
      });
    }
    commitAudio() {
      const sessionId = this.sessionId;
      if (!sessionId) {
        throw new Error("runtime session is not ready");
      }
      this.send({
        type: "turn.input.audio.commit",
        requestId: makeRequestId("turn-commit"),
        timestamp: makeTimestamp(),
        sessionId,
        payload: {
          endOfTurn: true
        }
      });
    }
    async interrupt(reason) {
      if (!this.sessionId || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
        return;
      }
      this.send({
        type: "turn.interrupt",
        requestId: makeRequestId("turn-interrupt"),
        timestamp: makeTimestamp(),
        sessionId: this.sessionId,
        ...this.activeTurnId ? { turnId: this.activeTurnId } : {},
        payload: reason ? { reason } : {}
      });
      this.activeTurnId = null;
    }
    async close() {
      this.connectPromise = null;
      this.resolveSessionReady = null;
      this.rejectSessionReady = null;
      this.sessionId = null;
      this.activeTurnId = null;
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
    }
    async ensureSession(language) {
      if (this.ws && this.ws.readyState === WebSocket.OPEN && this.sessionId) {
        return;
      }
      if (this.connectPromise) {
        await this.connectPromise;
        return;
      }
      this.args.handlers.onPhaseChange?.("opening-session");
      this.connectPromise = this.openSession(language).finally(() => {
        this.connectPromise = null;
      });
      await this.connectPromise;
    }
    async openSession(language) {
      const token = await this.args.authClient.issueToken();
      const factory = this.args.webSocketFactory ?? ((url) => new WebSocket(url));
      const nextWs = factory(toWebSocketUrl(this.args.apiBaseUrl, token.token));
      this.ws = nextWs;
      await new Promise((resolve, reject) => {
        this.resolveSessionReady = resolve;
        this.rejectSessionReady = reject;
        nextWs.onopen = () => {
          const envelope = {
            type: "session.open",
            requestId: makeRequestId("session-open"),
            timestamp: makeTimestamp(),
            payload: {
              clientSessionId: this.clientSessionId,
              ...language ? { language } : {}
            }
          };
          nextWs.send(JSON.stringify(envelope));
        };
        nextWs.onmessage = (event) => {
          this.handleSocketMessage(event.data);
        };
        nextWs.onerror = () => {
          this.args.handlers.onPhaseChange?.("error");
          this.rejectSessionReady?.(new Error("runtime websocket failed"));
          this.clearPendingSessionReady();
        };
        nextWs.onclose = () => {
          this.args.handlers.onPhaseChange?.("error");
          this.rejectSessionReady?.(new Error("runtime websocket closed"));
          this.clearPendingSessionReady();
          this.sessionId = null;
          this.activeTurnId = null;
          this.ws = null;
        };
      });
    }
    async syncContextSnapshot(tabId, snapshot) {
      if (!this.sessionId || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("runtime websocket is not ready");
      }
      this.send({
        type: "session.context.sync",
        requestId: makeRequestId("session-context"),
        timestamp: makeTimestamp(),
        sessionId: this.sessionId,
        payload: {
          tabId,
          isPrimary: true
        }
      });
      this.send({
        type: "session.snapshot.sync",
        requestId: makeRequestId("session-snapshot"),
        timestamp: makeTimestamp(),
        sessionId: this.sessionId,
        payload: {
          tabId,
          snapshot
        }
      });
    }
    handleSocketMessage(raw) {
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch {
        return;
      }
      if (!isRuntimeV2ServerEnvelope(parsed)) {
        return;
      }
      switch (parsed.type) {
        case "session.ready":
          this.sessionId = parsed.payload.sessionId;
          this.args.handlers.onSessionReady?.(parsed);
          this.args.handlers.onPhaseChange?.("ready");
          this.resolveSessionReady?.();
          this.clearPendingSessionReady();
          return;
        case "turn.started":
          this.activeTurnId = parsed.turnId;
          this.args.handlers.onTurnStarted?.(parsed);
          return;
        case "turn.input.transcript.partial":
          this.args.handlers.onInputTranscript?.(parsed.payload.text, false, parsed);
          return;
        case "turn.input.transcript.final":
          this.args.handlers.onInputTranscript?.(parsed.payload.text, true, parsed);
          return;
        case "turn.output.transcript.partial":
          this.args.handlers.onOutputTranscript?.(parsed.payload.text, false, parsed);
          return;
        case "turn.output.transcript.final":
          this.args.handlers.onOutputTranscript?.(parsed.payload.text, true, parsed);
          return;
        case "turn.output.audio.chunk":
          this.args.handlers.onAudioChunk?.(parsed);
          return;
        case "turn.output.projection":
          this.args.handlers.onProjection?.(parsed.payload.projection, parsed);
          return;
        case "tool.request":
          void this.handleToolRequest(parsed);
          return;
        case "turn.done":
          if (this.activeTurnId === parsed.turnId) {
            this.activeTurnId = null;
          }
          this.args.handlers.onPhaseChange?.("ready");
          this.args.handlers.onTurnDone?.(parsed);
          return;
        case "turn.error":
          if (parsed.turnId && this.activeTurnId === parsed.turnId) {
            this.activeTurnId = null;
          }
          this.args.handlers.onPhaseChange?.("error");
          this.args.handlers.onError?.(parsed.payload, parsed);
          return;
      }
    }
    async handleToolRequest(event) {
      const result = await this.args.handlers.onToolRequest?.(event);
      if (!event.payload.waitForResult && !result) {
        return;
      }
      const payload = result ?? {
        toolRequestId: event.payload.toolRequestId,
        kind: event.payload.kind,
        ok: false,
        error: "frontend tool handler did not return a result"
      };
      this.send({
        type: "tool.result",
        requestId: makeRequestId("tool-result"),
        timestamp: makeTimestamp(),
        sessionId: event.sessionId,
        turnId: event.turnId,
        payload
      });
    }
    send(envelope) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("runtime websocket is not open");
      }
      this.ws.send(JSON.stringify(envelope));
    }
    clearPendingSessionReady() {
      this.resolveSessionReady = null;
      this.rejectSessionReady = null;
    }
  };

  // src/sidepanel/conversation-controller.ts
  var ConversationController = class {
    constructor(args) {
      this.args = args;
      this.ttsEnabled = args.ttsEnabled;
      this.audioOutput = args.audioOutput ?? new LiveAudioOutputPlayer();
      this.transport = args.transport ?? new RuntimeTransport({
        apiBaseUrl: args.apiBaseUrl,
        authClient: args.authClient,
        handlers: {
          ...args.handlers,
          onAudioChunk: (event) => {
            if (this.ttsEnabled) {
              void this.audioOutput.playChunk(event.payload.chunkBase64);
            }
            args.handlers.onAudioChunk?.(event);
          },
          onTurnDone: (event) => {
            if (event.payload.modality === "voice") {
              this.acceptingVoiceInputChunks = false;
              if (this.audioInput.supported) {
                void this.audioInput.cancel();
              }
            }
            args.handlers.onTurnDone?.(event);
            this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
          },
          onError: (error, event) => {
            this.acceptingVoiceInputChunks = false;
            args.handlers.onError?.(error, event);
            this.audioOutput.stop();
            if (this.audioInput.supported) {
              void this.audioInput.cancel();
            } else {
              this.notifySpeechState("unsupported");
            }
          }
        }
      });
      this.audioInput = args.audioInput ?? new PageAudioInputProvider({
        getActiveTabId: args.getActiveTabId,
        sendToContentScript: args.sendToContentScript,
        addRuntimeListener: args.addRuntimeListener,
        removeRuntimeListener: args.removeRuntimeListener
      });
      this.audioInput.onChunkBase64 = (chunkBase64) => {
        if (!this.acceptingVoiceInputChunks) {
          return;
        }
        this.transport.appendAudioChunk(chunkBase64);
      };
      this.audioInput.onError = (error) => {
        this.acceptingVoiceInputChunks = false;
        this.audioOutput.stop();
        this.notifySpeechState("error", error.message);
      };
      this.audioInput.onStateChange = (state2, detail) => {
        this.notifySpeechState(state2, detail);
      };
      this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
    }
    audioInput;
    audioOutput;
    transport;
    ttsEnabled;
    acceptingVoiceInputChunks = false;
    get inputSupported() {
      return this.audioInput.supported;
    }
    get outputSupported() {
      return this.audioOutput.supported;
    }
    setVoiceOutputEnabled(enabled) {
      this.ttsEnabled = enabled;
      if (!enabled) {
        this.audioOutput.stop();
      }
    }
    async sendTextTurn(input) {
      this.acceptingVoiceInputChunks = false;
      this.audioOutput.stop();
      await this.transport.sendTextTurn(input);
    }
    async startVoiceTurn(input) {
      if (!this.audioInput.supported) {
        throw new Error("Voice input is unavailable in this browser.");
      }
      this.acceptingVoiceInputChunks = false;
      this.audioOutput.stop();
      await this.transport.startVoiceTurn(input);
      try {
        await this.audioInput.start();
        this.acceptingVoiceInputChunks = true;
      } catch (error) {
        this.acceptingVoiceInputChunks = false;
        throw error;
      }
    }
    async finishVoiceTurn() {
      if (!this.audioInput.supported) {
        return;
      }
      await this.audioInput.stop();
      this.acceptingVoiceInputChunks = false;
      this.transport.commitAudio();
    }
    async cancelVoiceTurn() {
      this.acceptingVoiceInputChunks = false;
      if (this.audioInput.supported) {
        await this.audioInput.cancel();
      }
      await this.transport.interrupt("cancelled");
      this.audioOutput.stop();
      this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
    }
    async interrupt(reason) {
      this.acceptingVoiceInputChunks = false;
      if (this.audioInput.supported) {
        await this.audioInput.cancel();
      }
      await this.transport.interrupt(reason);
      this.audioOutput.stop();
      this.notifySpeechState(this.audioInput.supported ? "idle" : "unsupported");
    }
    async close() {
      this.acceptingVoiceInputChunks = false;
      if (this.audioInput.supported) {
        await this.audioInput.cancel();
      }
      this.audioInput.dispose();
      await this.transport.close();
      await this.audioOutput.dispose();
    }
    notifySpeechState(state2, detail) {
      this.args.handlers.onSpeechStateChange?.(state2, detail);
    }
  };

  // src/sidepanel/projection-router.ts
  function routeProjection(projection, handlers) {
    switch (projection.type) {
      case "respond":
        handlers.respond(projection.payload);
        return;
      case "focus":
      case "focusMultiple":
        handlers.focus(projection);
        return;
      case "navigate":
        handlers.navigate(projection.payload);
        return;
      case "present":
        handlers.present(projection.payload);
        return;
      case "notify":
        handlers.notify(projection.payload);
        return;
      case "copy":
        handlers.copy(projection.payload);
        return;
      default:
        return;
    }
  }

  // src/sidepanel/transcript-merge.ts
  function mergeStreamingTranscript(current, incoming) {
    if (!incoming) {
      return current;
    }
    if (!current) {
      return incoming;
    }
    if (incoming === current) {
      return current;
    }
    if (incoming.startsWith(current)) {
      return incoming;
    }
    if (current.startsWith(incoming)) {
      return current;
    }
    const maxOverlap = Math.min(current.length, incoming.length);
    for (let overlap = maxOverlap; overlap > 0; overlap -= 1) {
      if (current.slice(-overlap) === incoming.slice(0, overlap)) {
        return current + incoming.slice(overlap);
      }
    }
    return current + incoming;
  }

  // src/sidepanel/ui.ts
  function showNotify(message, _level) {
    const root = document.getElementById("notify-root");
    if (!root) {
      return;
    }
    root.textContent = message;
    root.style.display = "block";
    window.setTimeout(() => {
      root.style.display = "none";
    }, 3e3);
  }

  // src/sidepanel-user/ui.ts
  function getAuthDisplayName(user) {
    return user?.displayName ?? user?.primaryEmail ?? "Signed in";
  }
  function getAuthFallbackInitials(user) {
    const source = getAuthDisplayName(user).trim();
    if (!source) {
      return "TA";
    }
    const parts = source.split(/\s+/).filter(Boolean);
    const initials = (parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "");
    return (initials || source.slice(0, 2) || "TA").toUpperCase();
  }
  function getElement(id) {
    return document.getElementById(id);
  }
  function createWavePath(levels, mode) {
    const width = 240;
    const height = 28;
    const baseline = height / 2;
    const safeLevels = levels.length > 1 ? levels : mode === "thinking" ? [0.08, 0.12, 0.08, 0.12, 0.08, 0.12, 0.08, 0.12] : [0, 0, 0, 0, 0, 0, 0, 0];
    const step = width / Math.max(1, safeLevels.length - 1);
    return safeLevels.map((level, index) => {
      const amplitude = mode === "thinking" ? 3 + level * 8 : level * 12;
      const phase = index % 2 === 0 ? -1 : 1;
      const y = baseline + amplitude * phase;
      return `${index === 0 ? "M" : "L"} ${Math.round(index * step)} ${Math.round(y)}`;
    }).join(" ");
  }
  function renderTranscript(messages) {
    const root = getElement("consumer-transcript");
    if (!root) {
      return;
    }
    root.innerHTML = "";
    if (messages.length === 0) {
      const empty = document.createElement("div");
      empty.className = "consumer-empty";
      empty.textContent = "Ask what matters on this page, or hold to talk.";
      root.appendChild(empty);
      return;
    }
    for (const message of messages) {
      const item = document.createElement("article");
      item.className = `consumer-message consumer-message-${message.role}`;
      item.dataset.messageId = message.id;
      if (message.pending) {
        item.classList.add("consumer-message-pending");
      }
      const label = document.createElement("div");
      label.className = "consumer-message-role";
      label.textContent = message.role === "user" ? "You" : "ThreadAtlas";
      const body = document.createElement("div");
      body.className = "consumer-message-text";
      body.textContent = message.text;
      item.append(label, body);
      if (message.role === "assistant") {
        const hasProvenance = Boolean(message.provenanceSummary?.length);
        const hasActions = Boolean(message.actions?.copyText) || Boolean(message.actions?.highlight) || Boolean(message.actions?.showContext);
        if (hasProvenance || hasActions) {
          const footer = document.createElement("div");
          footer.className = "consumer-message-footer";
          if (hasProvenance) {
            const provenance = document.createElement("div");
            provenance.className = "consumer-provenance";
            for (const itemText of message.provenanceSummary ?? []) {
              const pill = document.createElement("span");
              pill.className = "consumer-provenance-pill";
              pill.textContent = itemText === "current-page" ? "Based on this page" : itemText === "enriched-context" ? "Used more page context" : itemText;
              provenance.appendChild(pill);
            }
            footer.appendChild(provenance);
          }
          if (hasActions) {
            const actions = document.createElement("div");
            actions.className = "consumer-actions";
            if (message.actions?.highlight) {
              const button = document.createElement("button");
              button.type = "button";
              button.className = "consumer-action-button";
              button.dataset.action = "highlight";
              button.dataset.messageId = message.id;
              button.textContent = "Highlight";
              actions.appendChild(button);
            }
            if (message.actions?.showContext) {
              const button = document.createElement("button");
              button.type = "button";
              button.className = "consumer-action-button";
              button.dataset.action = "context";
              button.dataset.messageId = message.id;
              button.textContent = "Show context";
              actions.appendChild(button);
            }
            if (message.actions?.copyText) {
              const button = document.createElement("button");
              button.type = "button";
              button.className = "consumer-action-button";
              button.dataset.action = "copy";
              button.dataset.messageId = message.id;
              button.textContent = "Copy";
              actions.appendChild(button);
            }
            footer.appendChild(actions);
          }
          item.appendChild(footer);
        }
      }
      root.appendChild(item);
    }
  }
  function renderConsumerShell(args) {
    const pageDomain = getElement("consumer-page-domain");
    const pageTitle = getElement("consumer-page-title");
    const readiness = getElement("consumer-readiness-pill");
    const composer = getElement("conversation-input");
    const send = getElement("conversation-send-button");
    const mic = getElement("conversation-mic-button");
    const activity = getElement("consumer-activity-label");
    const signal = getElement("consumer-signal-path");
    const signalRoot = getElement("consumer-signal");
    const authCard = getElement("consumer-auth-card");
    const authTitle = getElement("consumer-auth-title");
    const authBody = getElement("consumer-auth-body");
    const signInButton = getElement("consumer-sign-in-button");
    const recovery = getElement("consumer-recovery-card");
    const recoveryTitle = getElement("consumer-recovery-title");
    const recoveryBody = getElement("consumer-recovery-body");
    const recoveryPrimary = getElement("consumer-recovery-primary");
    const scopeChip = getElement("consumer-scope-chip");
    const scopeLabel = getElement("consumer-scope-label");
    const scopeClear = getElement("consumer-scope-clear");
    const scopePreview = getElement("consumer-scope-preview");
    const scopeMeta = getElement("consumer-scope-meta");
    const menu = getElement("consumer-menu");
    const menuAvatar = getElement("consumer-menu-avatar");
    const menuName = getElement("consumer-menu-name");
    const menuEmail = getElement("consumer-menu-email");
    const signOutButton = getElement("consumer-sign-out-button");
    const voiceOutputButton = getElement("consumer-menu-voice-output");
    const internalConsoleButton = getElement("consumer-open-console-button");
    const contextSheet = getElement("consumer-context-sheet");
    const contextTitle = getElement("consumer-context-title");
    const contextList = getElement("consumer-context-list");
    if (!pageDomain || !pageTitle || !readiness || !composer || !send || !mic || !activity || !signal || !signalRoot || !authCard || !authTitle || !authBody || !signInButton || !recovery || !recoveryTitle || !recoveryBody || !recoveryPrimary || !scopeChip || !scopeLabel || !scopeClear || !scopePreview || !scopeMeta || !menu || !menuAvatar || !menuName || !menuEmail || !signOutButton || !voiceOutputButton || !internalConsoleButton || !contextSheet || !contextTitle || !contextList) {
      return;
    }
    pageDomain.textContent = args.pageDomain;
    pageTitle.textContent = args.pageTitle;
    readiness.textContent = args.view.readinessLabel;
    readiness.dataset.state = args.view.readinessState;
    activity.textContent = args.view.activityLabel;
    signal.setAttribute("d", createWavePath(args.signalLevels, args.voiceActivityState));
    signalRoot.dataset.state = args.voiceActivityState;
    renderTranscript(args.messages);
    composer.value = args.composerValue;
    composer.disabled = args.view.composerDisabled;
    composer.placeholder = args.view.composerPlaceholder;
    send.disabled = args.sendDisabled;
    mic.disabled = args.view.micDisabled;
    mic.textContent = args.voiceActivityState === "listening" ? "Release" : "Hold to talk";
    authCard.classList.toggle("hidden", !args.view.showAuthPrompt);
    authTitle.textContent = args.authStatusLabel;
    authBody.textContent = args.authStatusDescription;
    signInButton.disabled = args.view.composerDisabled && !args.view.showAuthPrompt;
    recovery.classList.toggle("hidden", !args.view.showRecovery);
    recoveryTitle.textContent = args.view.recoveryTitle ?? "";
    recoveryBody.textContent = args.view.recoveryBody ?? "";
    recoveryPrimary.textContent = args.view.recoveryPrimaryLabel ?? "Try again";
    recoveryPrimary.dataset.kind = args.view.recoveryKind ?? "";
    scopeChip.dataset.scope = args.activeScope;
    scopeLabel.textContent = args.activeScope === "selection" ? "Your selection" : "This page";
    scopeClear.classList.toggle("hidden", args.activeScope !== "selection");
    scopePreview.classList.toggle("hidden", !(args.activeScope === "selection" && args.selectionPreview));
    scopePreview.textContent = args.selectionPreview ?? "";
    scopeMeta.classList.toggle("hidden", !(args.activeScope === "selection" && args.selectionScopeMeta));
    scopeMeta.textContent = args.selectionScopeMeta ?? "";
    menu.classList.toggle("hidden", !args.menuOpen);
    menuAvatar.textContent = getAuthFallbackInitials(args.signedInUser);
    menuName.textContent = args.signedInUser ? getAuthDisplayName(args.signedInUser) : "Signed out";
    menuEmail.textContent = args.signedInUser?.primaryEmail ?? "";
    signOutButton.classList.toggle("hidden", !args.signedInUser);
    voiceOutputButton.textContent = args.voiceOutputEnabled ? "Voice output on" : "Voice output off";
    voiceOutputButton.setAttribute("aria-pressed", args.voiceOutputEnabled ? "true" : "false");
    internalConsoleButton.classList.toggle("hidden", !args.showInternalConsoleLauncher);
    contextSheet.classList.toggle("hidden", !args.contextSheetOpen);
    contextTitle.textContent = args.contextContent?.title ?? "More context";
    contextList.innerHTML = "";
    for (const item of args.contextContent?.items ?? []) {
      const row = document.createElement("div");
      row.className = "consumer-context-item";
      const source = document.createElement("div");
      source.className = "consumer-context-source";
      source.textContent = item.source;
      const summary = document.createElement("div");
      summary.className = "consumer-context-summary";
      summary.textContent = item.summary;
      row.append(source, summary);
      contextList.appendChild(row);
    }
  }
  var detachKeyboardBindings = null;
  function isEditableTarget(target) {
    if (!(target instanceof HTMLElement)) {
      return false;
    }
    return Boolean(target.closest("textarea, input, select, button, [contenteditable='true']"));
  }
  function bindConsumerShellActions(args) {
    const composer = getElement("conversation-input");
    const send = getElement("conversation-send-button");
    const mic = getElement("conversation-mic-button");
    const menuButton = getElement("consumer-menu-button");
    const voiceOutputButton = getElement("consumer-menu-voice-output");
    const signInButton = getElement("consumer-sign-in-button");
    const signOutButton = getElement("consumer-sign-out-button");
    const recoveryPrimary = getElement("consumer-recovery-primary");
    const scopeClear = getElement("consumer-scope-clear");
    const transcript = getElement("consumer-transcript");
    const internalConsoleButton = getElement("consumer-open-console-button");
    const closeContextButton = getElement("consumer-context-close");
    composer?.addEventListener("input", () => {
      args.onComposerInput(composer.value);
    });
    composer?.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        args.onSubmitPrompt(composer.value);
      }
    });
    send?.addEventListener("click", () => {
      args.onSubmitPrompt(composer?.value ?? "");
    });
    let activePointerId = null;
    mic?.addEventListener("pointerdown", (event) => {
      activePointerId = event.pointerId;
      mic.setPointerCapture?.(event.pointerId);
      args.onStartMicPress();
    });
    mic?.addEventListener("pointerup", (event) => {
      if (activePointerId === event.pointerId) {
        activePointerId = null;
        args.onEndMicPress();
      }
    });
    mic?.addEventListener("pointercancel", () => {
      activePointerId = null;
      args.onCancelMicPress();
    });
    menuButton?.addEventListener("click", args.onToggleMenu);
    voiceOutputButton?.addEventListener("click", args.onToggleVoiceOutput);
    signInButton?.addEventListener("click", args.onSignIn);
    signOutButton?.addEventListener("click", args.onSignOut);
    scopeClear?.addEventListener("click", args.onClearScope);
    internalConsoleButton?.addEventListener("click", args.onOpenInternalConsole);
    closeContextButton?.addEventListener("click", args.onCloseContextSheet);
    recoveryPrimary?.addEventListener("click", () => {
      const kind = recoveryPrimary.dataset.kind || null;
      args.onRecoveryPrimary(kind);
    });
    transcript?.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) {
        return;
      }
      const button = target.closest("[data-action][data-message-id]");
      if (!button) {
        return;
      }
      const messageId = button.dataset.messageId;
      if (!messageId) {
        return;
      }
      const action = button.dataset.action;
      if (action === "copy") {
        args.onCopyMessage(messageId);
        return;
      }
      if (action === "context") {
        args.onShowContext(messageId);
        return;
      }
      if (action === "highlight") {
        args.onHighlightMessage(messageId);
      }
    });
    detachKeyboardBindings?.();
    detachKeyboardBindings = null;
    let keyboardVoiceActive = false;
    const handleKeyDown = (event) => {
      if (event.defaultPrevented || event.repeat || event.isComposing) {
        return;
      }
      if (event.altKey || event.ctrlKey || event.metaKey) {
        return;
      }
      if (event.code === "Space" && !isEditableTarget(event.target)) {
        event.preventDefault();
        keyboardVoiceActive = true;
        args.onStartMicPress();
        return;
      }
      if (event.key === "Escape") {
        event.preventDefault();
        if (keyboardVoiceActive) {
          keyboardVoiceActive = false;
        }
        args.onEscape();
      }
    };
    const handleKeyUp = (event) => {
      if (event.isComposing) {
        return;
      }
      if (event.code === "Space" && keyboardVoiceActive && !isEditableTarget(event.target)) {
        event.preventDefault();
        keyboardVoiceActive = false;
        args.onEndMicPress();
      }
    };
    const handleBlur = () => {
      if (!keyboardVoiceActive) {
        return;
      }
      keyboardVoiceActive = false;
      args.onCancelMicPress();
    };
    const handleVisibilityChange = () => {
      if (document.visibilityState === "hidden") {
        handleBlur();
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("keyup", handleKeyUp);
    window.addEventListener("blur", handleBlur);
    document.addEventListener("visibilitychange", handleVisibilityChange);
    detachKeyboardBindings = () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("blur", handleBlur);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }

  // src/sidepanel-user/view-state.ts
  function deriveConsumerShellViewState(args) {
    const readinessState = !args.pageSupported ? "unavailable" : args.snapshotPreparing ? "preparing" : args.snapshotReady ? "ready" : "needs-refresh";
    let readinessLabel = "Needs refresh";
    if (readinessState === "unavailable") {
      readinessLabel = "Unavailable";
    } else if (readinessState === "preparing") {
      readinessLabel = "Preparing";
    } else if (readinessState === "ready") {
      readinessLabel = "Ready";
    }
    const signedIn = args.authStatus === "signed-in";
    const showAuthPrompt = !signedIn && args.authStatus !== "signing-in" && args.authStatus !== "refreshing";
    let activityLabel = "Hold to talk or type a question.";
    if (args.voiceActivityState === "listening" || args.speechInputState === "listening") {
      activityLabel = "Listening... release to send.";
    } else if (args.voiceActivityState === "speaking") {
      activityLabel = "Speaking...";
    } else if (args.voiceActivityState === "thinking" || args.speechInputState === "processing" || args.runtimePhase === "initializing" || args.runtimePhase === "opening-session" || args.runtimePhase === "sending-intent" || args.runtimePhase === "waiting-enrich" || args.runtimePhase === "resuming-turn") {
      activityLabel = "Thinking...";
    } else if (!signedIn) {
      activityLabel = "Sign in to talk with the page you are reading.";
    } else if (readinessState === "preparing") {
      activityLabel = "Preparing this page...";
    } else if (readinessState === "needs-refresh") {
      activityLabel = "This page needs a refresh before it can answer reliably.";
    } else if (readinessState === "unavailable") {
      activityLabel = "This page is not ready for ThreadAtlas.";
    }
    let showRecovery = false;
    let recoveryTitle = null;
    let recoveryBody = null;
    let recoveryPrimaryLabel = null;
    let recoveryKind = null;
    if (args.speechInputState === "error" && args.speechInputDetail) {
      showRecovery = true;
      recoveryTitle = "Microphone access is needed";
      recoveryBody = args.speechInputDetail;
      recoveryPrimaryLabel = "Try microphone again";
      recoveryKind = "microphone";
    } else if (args.lastRuntimeError) {
      showRecovery = true;
      recoveryTitle = "The answer was interrupted";
      recoveryBody = args.lastRuntimeError.message;
      recoveryPrimaryLabel = "Refresh page";
      recoveryKind = "runtime";
    } else if (readinessState === "needs-refresh" && args.snapshotError) {
      showRecovery = true;
      recoveryTitle = "This page needs a refresh";
      recoveryBody = args.snapshotError;
      recoveryPrimaryLabel = "Refresh page";
      recoveryKind = "refresh";
    } else if (readinessState === "unavailable" && args.pageSupported) {
      showRecovery = true;
      recoveryTitle = "This page is not ready yet";
      recoveryBody = "Try refreshing the page context and then ask again.";
      recoveryPrimaryLabel = "Refresh page";
      recoveryKind = "refresh";
    }
    const composerDisabled = !signedIn || readinessState === "unavailable";
    const micDisabled = !signedIn || !args.inputSupported || readinessState === "unavailable";
    let composerPlaceholder = "Ask about this page...";
    if (!signedIn) {
      composerPlaceholder = "Sign in to ask about this page...";
    } else if (readinessState === "preparing") {
      composerPlaceholder = "Preparing this page...";
    } else if (readinessState === "needs-refresh") {
      composerPlaceholder = "Ask anyway or refresh the page context...";
    } else if (readinessState === "unavailable") {
      composerPlaceholder = "Open a supported page to start.";
    }
    return {
      readinessState,
      readinessLabel,
      activityLabel,
      composerDisabled,
      composerPlaceholder,
      micDisabled,
      showAuthPrompt,
      showRecovery,
      recoveryTitle,
      recoveryBody,
      recoveryPrimaryLabel,
      recoveryKind
    };
  }

  // src/sidepanel-user/index.ts
  var TTS_ENABLED_STORAGE_KEY = "THREADATLAS_TTS_ENABLED";
  var authClient = createAuthClient();
  function readPersistedTtsEnabled() {
    const stored = window.localStorage.getItem(TTS_ENABLED_STORAGE_KEY);
    return stored === null ? true : stored === "true";
  }
  var state = {
    apiBaseUrl: "",
    conversationController: null,
    activeTabId: null,
    activeTabUrl: "",
    activeTabTitle: "ThreadAtlas",
    currentPageKey: null,
    latestSemanticSnapshot: null,
    latestRegionDump: null,
    pageSnapshot: null,
    selectionSnapshot: null,
    activeScope: "page",
    selectionPreview: null,
    selectionScopeMeta: null,
    runtimeSnapshot: null,
    phase: "initializing",
    authState: {
      status: "signed-out",
      provider: null,
      user: null,
      session: null
    },
    authBusy: false,
    conversationMessages: [],
    composerText: "",
    currentTurnOrigin: null,
    activeTurnId: null,
    lastRuntimeError: null,
    speechInputState: "unsupported",
    speechInputDetail: null,
    pendingEnrichRequest: null,
    voiceAssistantMessageId: null,
    voiceAssistantTranscriptBuffer: "",
    voiceUserMessageId: null,
    voiceUserTranscriptBuffer: "",
    menuOpen: false,
    ttsEnabled: readPersistedTtsEnabled(),
    contextSheetOpen: false,
    contextSheetContent: null,
    turnDecorations: /* @__PURE__ */ new Map(),
    preparingSnapshot: false,
    voiceActivityState: "idle",
    signalLevels: Array.from({ length: 24 }, () => 0),
    showInternalConsoleLauncher: false
  };
  var voiceVisualDecayTimer = null;
  var selectionCaptureVersion = 0;
  function isPageTextSelectionChangedMessage(message) {
    if (typeof message !== "object" || message === null) {
      return false;
    }
    const candidate = message;
    return candidate.type === "PAGE_TEXT_SELECTION_CHANGED" && typeof candidate.payload?.hasSelection === "boolean" && typeof candidate.payload?.textPreview === "string" && typeof candidate.payload?.timestamp === "number";
  }
  function resetVoiceTranscriptState() {
    state.voiceAssistantMessageId = null;
    state.voiceAssistantTranscriptBuffer = "";
    state.voiceUserMessageId = null;
    state.voiceUserTranscriptBuffer = "";
  }
  function resetSignalLevels() {
    state.signalLevels = Array.from({ length: 24 }, () => 0);
  }
  function setVoiceActivityState(next) {
    state.voiceActivityState = next;
    if (next === "idle" || next === "thinking") {
      resetSignalLevels();
    }
  }
  function pushSignalLevel(level) {
    const normalized = Math.max(0, Math.min(1, level));
    state.signalLevels = [...state.signalLevels.slice(-23), normalized];
  }
  function persistTtsEnabled() {
    window.localStorage.setItem(TTS_ENABLED_STORAGE_KEY, state.ttsEnabled ? "true" : "false");
  }
  function hasActiveRuntimeTurn() {
    return state.activeTurnId !== null || state.pendingEnrichRequest !== null || state.phase === "opening-session" || state.phase === "sending-intent" || state.phase === "waiting-enrich" || state.phase === "resuming-turn";
  }
  function getPageTitle() {
    if (state.activeTabTitle.trim()) {
      return state.activeTabTitle;
    }
    if (state.activeTabUrl) {
      try {
        return new URL(state.activeTabUrl).hostname;
      } catch {
        return "ThreadAtlas";
      }
    }
    return "ThreadAtlas";
  }
  function getPageDomain() {
    if (!state.activeTabUrl) {
      return "Current page";
    }
    try {
      return new URL(state.activeTabUrl).hostname;
    } catch {
      return "Current page";
    }
  }
  function isSignedIn() {
    return state.authState.status === "signed-in";
  }
  function isSupportedPage() {
    return Boolean(state.activeTabUrl) && isSemanticCaptureSupportedUrl(state.activeTabUrl);
  }
  function getActiveScopeSnapshot() {
    if (state.activeScope === "selection" && state.selectionSnapshot) {
      return state.selectionSnapshot;
    }
    return state.pageSnapshot ?? state.latestSemanticSnapshot?.snapshot ?? null;
  }
  function formatCount(count, singular, plural = `${singular}s`) {
    return `${count} ${count === 1 ? singular : plural}`;
  }
  function describeSelectionScope(snapshot) {
    const node = snapshot.focus.node;
    const coverage = snapshot.meta.coverage;
    const relatedCount = snapshot.context.length;
    let label = "Section";
    if (coverage?.kind === "focus-branch" || node.kind === "comment") {
      label = "Comment branch";
    } else if (node.kind === "interactive") {
      label = "Control group";
    }
    if (!coverage) {
      return `${label} \xB7 ${formatCount(relatedCount, "related node")}`;
    }
    return `${label} \xB7 ${formatCount(coverage.capturedNodeCount, "captured node")} \xB7 ${formatCount(
      relatedCount,
      "related node"
    )}`;
  }
  async function applySelectionScopeHighlight(snapshot) {
    if (state.activeTabId === null) {
      return;
    }
    try {
      await sendToContentScript(state.activeTabId, {
        type: "APPLY_PAGE_SELECTION_SCOPE_HIGHLIGHT",
        payload: {
          regionId: snapshot.focus.region,
          focusNodeId: snapshot.focus.nodeId,
          rootNodeId: snapshot.meta.coverage?.rootNodeId ?? snapshot.focus.nodeId
        }
      });
    } catch {
    }
  }
  async function clearSelectionScopeHighlight(tabId) {
    if (tabId === null) {
      return;
    }
    try {
      await sendToContentScript(tabId, {
        type: "CLEAR_PAGE_SELECTION_SCOPE_HIGHLIGHT"
      });
    } catch {
    }
  }
  function refreshVoiceVisualState() {
    if (state.speechInputState === "listening") {
      state.voiceActivityState = "listening";
      return;
    }
    if (hasActiveRuntimeTurn() || state.speechInputState === "processing") {
      state.voiceActivityState = "thinking";
      return;
    }
    state.voiceActivityState = "idle";
  }
  function scheduleVoiceVisualDecay() {
    if (voiceVisualDecayTimer !== null) {
      window.clearTimeout(voiceVisualDecayTimer);
    }
    voiceVisualDecayTimer = window.setTimeout(() => {
      refreshVoiceVisualState();
      renderShell();
    }, 180);
  }
  function applyTurnDecoration(message, turnId) {
    if (!turnId) {
      return message;
    }
    const decoration = state.turnDecorations.get(turnId);
    if (!decoration) {
      if (message.role !== "assistant") {
        return message;
      }
      return {
        ...message,
        actions: {
          ...message.actions,
          copyText: message.actions?.copyText ?? message.text
        }
      };
    }
    const nextMessage = { ...message };
    if (message.role === "assistant") {
      nextMessage.actions = {
        copyText: decoration.copyText ?? message.actions?.copyText ?? message.text,
        showContext: Boolean(decoration.contextContent ?? message.contextContent),
        highlight: Boolean(decoration.highlightProjection ?? message.highlightProjection)
      };
    }
    const provenanceSummary = decoration.provenanceSummary ?? message.provenanceSummary;
    if (provenanceSummary) {
      nextMessage.provenanceSummary = provenanceSummary;
    }
    const contextContent = decoration.contextContent ?? message.contextContent;
    if (contextContent) {
      nextMessage.contextContent = contextContent;
    }
    const highlightProjection = decoration.highlightProjection ?? message.highlightProjection;
    if (highlightProjection) {
      nextMessage.highlightProjection = highlightProjection;
    }
    return nextMessage;
  }
  function updateTurnDecoration(turnId, patch) {
    if (!turnId) {
      return;
    }
    const current = state.turnDecorations.get(turnId) ?? {};
    const next = {
      ...current,
      ...patch
    };
    state.turnDecorations.set(turnId, next);
    state.conversationMessages = state.conversationMessages.map(
      (message) => message.turnId === turnId && message.role === "assistant" ? applyTurnDecoration(message, turnId) : message
    );
  }
  function appendConversationMessage(message) {
    state.conversationMessages = [
      ...state.conversationMessages,
      applyTurnDecoration(
        {
          ...message,
          id: message.id ?? globalThis.crypto?.randomUUID?.() ?? `msg-${Date.now()}`
        },
        message.turnId
      )
    ];
  }
  function upsertConversationMessage(message) {
    const existingIndex = state.conversationMessages.findIndex((item) => item.id === message.id);
    const nextMessage = applyTurnDecoration(message, message.turnId);
    if (existingIndex === -1) {
      state.conversationMessages = [...state.conversationMessages, nextMessage];
    } else {
      const next = [...state.conversationMessages];
      next[existingIndex] = {
        ...next[existingIndex],
        ...nextMessage
      };
      state.conversationMessages = next;
    }
  }
  function removeConversationMessage(id) {
    if (!id) {
      return;
    }
    state.conversationMessages = state.conversationMessages.filter((item) => item.id !== id);
  }
  function resetConversationSurface() {
    state.conversationMessages = [];
    state.composerText = "";
    state.contextSheetOpen = false;
    state.contextSheetContent = null;
    resetVoiceTranscriptState();
    state.turnDecorations.clear();
  }
  function getAssistantMessageById(messageId) {
    return state.conversationMessages.find((message) => message.id === messageId) ?? null;
  }
  function upsertVoiceUserTranscript(turnId, text, final) {
    if (!text && !final) {
      return;
    }
    const messageId = state.voiceUserMessageId ?? `voice-user-${globalThis.crypto?.randomUUID?.() ?? Date.now().toString(16)}`;
    state.voiceUserMessageId = messageId;
    const merged = mergeStreamingTranscript(state.voiceUserTranscriptBuffer, text);
    state.voiceUserTranscriptBuffer = merged;
    if (merged.trim().length === 0 && final) {
      removeConversationMessage(messageId);
      state.voiceUserTranscriptBuffer = "";
      state.voiceUserMessageId = null;
      return;
    }
    upsertConversationMessage({
      id: messageId,
      role: "user",
      text: merged,
      pending: !final,
      turnId
    });
    if (final) {
      state.voiceUserTranscriptBuffer = "";
      state.voiceUserMessageId = null;
    }
  }
  function upsertVoiceAssistantTranscript(turnId, text, final) {
    if (!text && !final) {
      return;
    }
    const messageId = state.voiceAssistantMessageId ?? `voice-assistant-${globalThis.crypto?.randomUUID?.() ?? Date.now().toString(16)}`;
    state.voiceAssistantMessageId = messageId;
    const merged = mergeStreamingTranscript(state.voiceAssistantTranscriptBuffer, text);
    state.voiceAssistantTranscriptBuffer = merged;
    if (merged.trim().length === 0 && final) {
      removeConversationMessage(messageId);
      state.voiceAssistantTranscriptBuffer = "";
      state.voiceAssistantMessageId = null;
      return;
    }
    upsertConversationMessage({
      id: messageId,
      role: "assistant",
      text: merged,
      pending: !final,
      turnId,
      actions: {
        copyText: merged
      }
    });
    if (final) {
      state.voiceAssistantTranscriptBuffer = "";
      state.voiceAssistantMessageId = null;
    }
  }
  function renderShell() {
    const signedInUser = state.authState.user;
    const view = deriveConsumerShellViewState({
      pageSupported: isSupportedPage(),
      snapshotReady: Boolean(state.pageSnapshot ?? state.selectionSnapshot),
      snapshotPreparing: state.preparingSnapshot,
      snapshotError: state.latestSemanticSnapshot?.error ?? null,
      authStatus: state.authState.status,
      inputSupported: state.conversationController?.inputSupported ?? false,
      voiceActivityState: state.voiceActivityState,
      runtimePhase: state.phase,
      speechInputState: state.speechInputState,
      speechInputDetail: state.speechInputDetail,
      lastRuntimeError: state.lastRuntimeError
    });
    renderConsumerShell({
      pageTitle: getPageTitle(),
      pageDomain: getPageDomain(),
      view,
      messages: state.conversationMessages,
      activeScope: state.activeScope,
      selectionPreview: state.selectionPreview,
      selectionScopeMeta: state.selectionScopeMeta,
      composerValue: state.composerText,
      sendDisabled: view.composerDisabled || state.composerText.trim().length === 0,
      voiceActivityState: state.voiceActivityState,
      signalLevels: state.signalLevels,
      signedInUser,
      authStatusLabel: state.authState.status === "signing-in" ? "Signing in with Google" : state.authState.status === "refreshing" ? "Refreshing your session" : "Talk with the page you are reading",
      authStatusDescription: state.authState.status === "error" ? state.authState.errorMessage ?? "Google sign-in failed. Try again." : "Sign in once and ask questions about the current page with voice or text.",
      menuOpen: state.menuOpen,
      voiceOutputEnabled: state.ttsEnabled,
      showInternalConsoleLauncher: state.showInternalConsoleLauncher,
      contextContent: state.contextSheetContent,
      contextSheetOpen: state.contextSheetOpen
    });
  }
  async function sendRuntimeMessage2(message) {
    return new Promise((resolve, reject) => {
      if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
        reject(new Error("chrome.runtime.sendMessage unavailable"));
        return;
      }
      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
  }
  async function sendToContentScript(tabId, message) {
    const trySend = () => new Promise((resolve, reject) => {
      if (typeof chrome === "undefined" || !chrome.tabs?.sendMessage) {
        reject(new Error("chrome.tabs.sendMessage unavailable"));
        return;
      }
      chrome.tabs.sendMessage(tabId, message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }
        resolve(response);
      });
    });
    try {
      return await trySend();
    } catch (error) {
      const messageText = error instanceof Error ? error.message : "";
      if (!messageText.includes("Receiving end does not exist") || typeof chrome === "undefined" || !chrome.scripting?.executeScript) {
        throw error;
      }
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content-semantic.js"]
      });
      return trySend();
    }
  }
  async function requestViewportCapture() {
    try {
      const response = await sendRuntimeMessage2({ type: "CAPTURE_VIEWPORT" });
      return response.viewport;
    } catch {
      return null;
    }
  }
  function updateSemanticSnapshot(payload) {
    state.latestSemanticSnapshot = payload;
    state.pageSnapshot = payload.snapshot;
  }
  async function hydrateSemanticRegionDump(tabId) {
    try {
      const payload = await sendRuntimeMessage2(
        typeof tabId === "number" ? {
          type: "GET_SEMANTIC_REGION_DUMP",
          payload: { tabId }
        } : {
          type: "GET_SEMANTIC_REGION_DUMP"
        }
      );
      state.latestRegionDump = payload;
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed to load semantic region dump";
      state.latestRegionDump = { tabId: tabId ?? null, dump: null, error: message };
    }
  }
  async function requestSemanticSnapshot(options = {}) {
    if (!isSupportedPage()) {
      state.latestSemanticSnapshot = {
        tabId: state.activeTabId,
        snapshot: null,
        error: "This page is not available for ThreadAtlas."
      };
      renderShell();
      return null;
    }
    state.preparingSnapshot = true;
    renderShell();
    try {
      const payload = await sendRuntimeMessage2(
        typeof state.activeTabId === "number" ? {
          type: "REQUEST_SEMANTIC_SNAPSHOT",
          payload: { tabId: state.activeTabId, source: "sidepanel" }
        } : {
          type: "REQUEST_SEMANTIC_SNAPSHOT",
          payload: { source: "sidepanel" }
        }
      );
      updateSemanticSnapshot(payload);
      await hydrateSemanticRegionDump(state.activeTabId ?? void 0);
      if (payload.error && !options.silent) {
        showNotify(payload.error, "error");
      }
      return payload.snapshot;
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed to prepare the page context";
      state.latestSemanticSnapshot = {
        tabId: state.activeTabId,
        snapshot: null,
        error: message
      };
      if (!options.silent) {
        showNotify(message, "error");
      }
      return null;
    } finally {
      state.preparingSnapshot = false;
      renderShell();
    }
  }
  async function captureSelectionSnapshot() {
    if (state.activeTabId === null) {
      return {
        snapshot: null,
        error: "There is no active page to select from."
      };
    }
    return sendToContentScript(state.activeTabId, {
      type: "CAPTURE_PAGE_TEXT_SELECTION_SNAPSHOT"
    });
  }
  async function captureSelectionScope(textPreview) {
    if (!isSupportedPage()) {
      return;
    }
    const captureVersion = ++selectionCaptureVersion;
    try {
      const result = await captureSelectionSnapshot();
      if (captureVersion !== selectionCaptureVersion) {
        return;
      }
      if (result.snapshot) {
        state.selectionSnapshot = result.snapshot;
        state.selectionPreview = textPreview;
        state.selectionScopeMeta = describeSelectionScope(result.snapshot);
        state.activeScope = "selection";
        void applySelectionScopeHighlight(result.snapshot);
        renderShell();
        return;
      }
    } catch {
    }
    if (captureVersion !== selectionCaptureVersion) {
      return;
    }
    showNotify("Couldn't use that selection. Still using this page.", "info");
    renderShell();
  }
  async function clearSelectionScope(options = {}) {
    const tabId = state.activeTabId;
    state.activeScope = "page";
    state.selectionSnapshot = null;
    state.selectionPreview = null;
    state.selectionScopeMeta = null;
    selectionCaptureVersion += 1;
    if (options.clearBrowserSelection !== false && state.activeTabId !== null) {
      try {
        await sendToContentScript(state.activeTabId, {
          type: "CLEAR_PAGE_TEXT_SELECTION"
        });
      } catch {
      }
    }
    await clearSelectionScopeHighlight(tabId);
    renderShell();
  }
  async function ensurePreparedSnapshot() {
    const scopedSnapshot = getActiveScopeSnapshot();
    if (scopedSnapshot) {
      return scopedSnapshot;
    }
    return requestSemanticSnapshot();
  }
  function getSemanticNodeText(node) {
    if (node.kind === "interactive") {
      return node.label ?? node.valuePreview ?? "";
    }
    return node.text;
  }
  function asNonEmptyString(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }
  function findRegionDumpEntry(dump, regionId) {
    if (!dump || !regionId) {
      return null;
    }
    return dump.regions.find((region) => region.id === regionId) ?? null;
  }
  function buildEnrichBounds(region) {
    if (!region) {
      return void 0;
    }
    return {
      x: region.boundingRect.x,
      y: region.boundingRect.y,
      width: region.boundingRect.width,
      height: region.boundingRect.height
    };
  }
  function buildEnrichAttributes(snapshot, node, region) {
    const attributes = {
      "data-page-kind": snapshot.page.kind,
      "data-node-kind": node.kind,
      "data-region-id": snapshot.focus.region
    };
    if (region) {
      attributes["data-category"] = region.category;
      attributes["data-primitive"] = region.primitive;
      attributes["data-layout-role"] = region.layoutRole;
      attributes["data-role-rank"] = region.roleRank;
      if (region.subtype) {
        attributes["data-subtype"] = region.subtype;
      }
    }
    if (node.kind === "content") {
      attributes["data-content-type"] = node.type;
      if (typeof node.level === "number") {
        attributes["data-heading-level"] = String(node.level);
      }
    }
    if (node.kind === "comment") {
      if (node.author) {
        attributes["data-author"] = node.author;
      }
      if (node.timestamp) {
        attributes["data-timestamp"] = node.timestamp;
      }
      attributes["data-depth"] = String(node.depth);
    }
    if (node.kind === "interactive") {
      attributes["data-control-type"] = node.controlType;
      if (node.action) {
        attributes["data-action"] = node.action;
      }
    }
    return Object.keys(attributes).length > 0 ? attributes : void 0;
  }
  function getExpectedNodeId(targetRef) {
    return asNonEmptyString(targetRef.nodeId) ?? asNonEmptyString(targetRef.entityId);
  }
  async function buildContextEnrichResult(request) {
    const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
    const baseResult = {
      requestKind: request.requestKind,
      targetRef: request.targetRef,
      capturedAt
    };
    const snapshot = state.runtimeSnapshot ?? state.latestSemanticSnapshot?.snapshot;
    if (!snapshot) {
      return {
        ...baseResult,
        status: "unsupported",
        failureReason: "no semantic snapshot is bound to the active turn"
      };
    }
    const expectedNodeId = getExpectedNodeId(request.targetRef);
    if (expectedNodeId && snapshot.focus.nodeId !== expectedNodeId) {
      return {
        ...baseResult,
        status: "unsupported",
        failureReason: "active semantic snapshot no longer matches the enrich target"
      };
    }
    const region = findRegionDumpEntry(state.latestRegionDump?.dump ?? null, snapshot.focus.region);
    const text = getSemanticNodeText(snapshot.focus.node);
    const detail = {
      captureScope: request.requestKind,
      pageUrl: snapshot.page.url,
      pageTitle: snapshot.page.title ?? null,
      nodeId: snapshot.focus.nodeId,
      regionId: snapshot.focus.region,
      text
    };
    const bounds = buildEnrichBounds(region);
    if (bounds) {
      detail.bounds = bounds;
    }
    const attributes = buildEnrichAttributes(snapshot, snapshot.focus.node, region);
    if (attributes) {
      detail.attributes = attributes;
    }
    if (request.requestKind === "node-detail") {
      return {
        ...baseResult,
        status: "ok",
        detail
      };
    }
    const viewport = await requestViewportCapture();
    if (!viewport) {
      return {
        ...baseResult,
        status: "failed",
        failureReason: "viewport capture unavailable for visual enrich request"
      };
    }
    detail.imageBase64 = viewport;
    return {
      ...baseResult,
      status: "ok",
      detail
    };
  }
  async function applyProjectionSideEffects(projection) {
    routeProjection(projection, {
      respond() {
      },
      focus(payload) {
        if (state.activeTabId === null) {
          return;
        }
        void sendToContentScript(state.activeTabId, {
          type: "EXECUTE_PROJECTION",
          projection: payload
        });
      },
      navigate(payload) {
        if (typeof chrome !== "undefined" && chrome.tabs?.create) {
          chrome.tabs.create({ url: payload.url, active: payload.options?.activate ?? true });
        }
      },
      present(payload) {
        state.contextSheetContent = payload.content;
      },
      notify(payload) {
        showNotify(payload.message, payload.level);
      },
      copy(payload) {
        void navigator.clipboard.writeText(payload.text);
        showNotify("Copied.", "success");
      }
    });
  }
  async function handleRuntimeToolRequest(event) {
    if (event.payload.kind === "context.enrich") {
      try {
        const args = event.payload.args;
        if (!args.requestKind || !args.targetRef) {
          throw new Error("runtime enrich request is missing requestKind or targetRef");
        }
        const payload = await buildContextEnrichResult({
          requestKind: args.requestKind,
          targetRef: args.targetRef
        });
        return {
          toolRequestId: event.payload.toolRequestId,
          kind: event.payload.kind,
          ok: true,
          result: {
            payload
          }
        };
      } catch (error) {
        return {
          toolRequestId: event.payload.toolRequestId,
          kind: event.payload.kind,
          ok: false,
          error: error instanceof Error ? error.message : "enrich handling failed"
        };
      }
    }
    if (event.payload.kind === "focus.node" || event.payload.kind === "present.content" || event.payload.kind === "copy.text" || event.payload.kind === "navigate.url") {
      const projection = event.payload.args.projection;
      if (!projection) {
        return {
          toolRequestId: event.payload.toolRequestId,
          kind: event.payload.kind,
          ok: false,
          error: "runtime frontend tool payload is missing a projection"
        };
      }
      if (projection?.type === "present") {
        updateTurnDecoration(event.turnId, { contextContent: projection.payload.content });
      }
      if (projection?.type === "focus" || projection?.type === "focusMultiple") {
        updateTurnDecoration(event.turnId, { highlightProjection: projection });
      }
      await applyProjectionSideEffects(projection);
      return {
        toolRequestId: event.payload.toolRequestId,
        kind: event.payload.kind,
        ok: true
      };
    }
    return {
      toolRequestId: event.payload.toolRequestId,
      kind: event.payload.kind,
      ok: false,
      error: "unsupported runtime frontend tool"
    };
  }
  function applyAuthState(next) {
    const previous = state.authState.status;
    state.authState = next;
    state.authBusy = next.status === "signing-in" || next.status === "refreshing";
    const signedOutNow = previous !== "signed-out" && previous !== "error" && next.status !== "signed-in" && next.status !== "refreshing";
    if (signedOutNow) {
      void state.conversationController?.close();
      state.activeTurnId = null;
      state.pendingEnrichRequest = null;
      state.lastRuntimeError = null;
      state.runtimeSnapshot = null;
      state.currentTurnOrigin = null;
      resetVoiceTranscriptState();
      setVoiceActivityState("idle");
      resetConversationSurface();
    }
    renderShell();
  }
  async function hydrateAuthState() {
    applyAuthState(await authClient.getAuthState());
  }
  async function signInWithGoogle() {
    const next = await authClient.signInWithGoogle();
    applyAuthState(next);
    if (next.status === "signed-in") {
      showNotify("Signed in with Google.", "success");
    } else if (next.errorMessage) {
      showNotify(next.errorMessage, next.status === "error" ? "error" : "info");
    }
  }
  async function signOut() {
    const next = await authClient.signOut();
    applyAuthState(next);
    showNotify("Signed out.", "info");
  }
  async function submitTextPrompt(prompt) {
    const normalized = prompt.trim();
    if (!normalized) {
      return;
    }
    if (!isSignedIn()) {
      showNotify("Sign in with Google before asking about this page.", "info");
      return;
    }
    if (!isSupportedPage()) {
      showNotify("This page is not available for ThreadAtlas.", "info");
      return;
    }
    if (hasActiveRuntimeTurn()) {
      showNotify("Wait for the current answer to finish.", "info");
      return;
    }
    const snapshot = await ensurePreparedSnapshot();
    if (!snapshot || state.activeTabId === null) {
      return;
    }
    state.lastRuntimeError = null;
    state.runtimeSnapshot = snapshot;
    state.currentTurnOrigin = "text";
    state.contextSheetOpen = false;
    try {
      await state.conversationController?.sendTextTurn({
        activeTabId: state.activeTabId,
        snapshot,
        text: normalized,
        language: window.navigator.language
      });
      state.composerText = "";
      renderShell();
    } catch (error) {
      const message = error instanceof Error ? error.message : "failed to send prompt";
      state.lastRuntimeError = {
        code: "GENERATION_FAILED",
        message
      };
      state.runtimeSnapshot = null;
      showNotify(message, "error");
      renderShell();
    }
  }
  async function startVoiceCapture() {
    const controller = state.conversationController;
    if (!controller?.inputSupported) {
      showNotify("Voice input is unavailable in this browser.", "info");
      return;
    }
    if (!isSignedIn()) {
      showNotify("Sign in with Google before starting voice input.", "info");
      return;
    }
    if (!isSupportedPage()) {
      showNotify("This page is not available for ThreadAtlas.", "info");
      return;
    }
    if (hasActiveRuntimeTurn()) {
      showNotify("Wait for the current answer to finish.", "info");
      return;
    }
    if (state.speechInputState === "listening" || state.speechInputState === "processing") {
      return;
    }
    const snapshot = await ensurePreparedSnapshot();
    if (!snapshot || state.activeTabId === null) {
      return;
    }
    state.lastRuntimeError = null;
    state.runtimeSnapshot = snapshot;
    state.currentTurnOrigin = "voice";
    try {
      await controller.startVoiceTurn({
        activeTabId: state.activeTabId,
        snapshot,
        language: window.navigator.language
      });
      renderShell();
    } catch (error) {
      state.speechInputState = "error";
      state.speechInputDetail = error instanceof Error ? error.message : "Voice capture could not be started.";
      showNotify(state.speechInputDetail, "error");
      renderShell();
    }
  }
  async function finishVoiceCapture() {
    if (state.speechInputState !== "listening") {
      return;
    }
    await state.conversationController?.finishVoiceTurn();
    renderShell();
  }
  async function cancelVoiceCapture() {
    if (state.speechInputState !== "listening" && state.speechInputState !== "processing") {
      return;
    }
    await state.conversationController?.interrupt("cancelled");
    setVoiceActivityState("idle");
    resetVoiceTranscriptState();
    renderShell();
  }
  function toggleMenu() {
    state.menuOpen = !state.menuOpen;
    renderShell();
  }
  function toggleVoiceOutput() {
    if (!state.conversationController?.outputSupported) {
      showNotify("Voice output is unavailable in this browser.", "info");
      return;
    }
    state.ttsEnabled = !state.ttsEnabled;
    persistTtsEnabled();
    state.conversationController.setVoiceOutputEnabled(state.ttsEnabled);
    renderShell();
  }
  function openInternalConsole() {
    if (typeof chrome !== "undefined" && chrome.tabs?.create) {
      chrome.tabs.create({
        url: chrome.runtime.getURL("console.html"),
        active: true
      });
    }
  }
  function openContextSheet(messageId) {
    const message = getAssistantMessageById(messageId);
    if (!message?.contextContent) {
      return;
    }
    state.contextSheetContent = message.contextContent;
    state.contextSheetOpen = true;
    renderShell();
  }
  async function copyAssistantMessage(messageId) {
    const message = getAssistantMessageById(messageId);
    const text = message?.actions?.copyText ?? message?.text;
    if (!text) {
      return;
    }
    await navigator.clipboard.writeText(text);
    showNotify("Copied.", "success");
  }
  async function highlightAssistantMessage(messageId) {
    const message = getAssistantMessageById(messageId);
    if (!message?.highlightProjection || state.activeTabId === null) {
      return;
    }
    await sendToContentScript(state.activeTabId, {
      type: "EXECUTE_PROJECTION",
      projection: message.highlightProjection
    });
  }
  async function handleRecovery(kind) {
    if (kind === "microphone") {
      await startVoiceCapture();
      return;
    }
    await requestSemanticSnapshot();
  }
  function resetForNewPage() {
    const previousTabId = state.activeTabId;
    void clearSelectionScopeHighlight(previousTabId);
    selectionCaptureVersion += 1;
    state.activeTurnId = null;
    state.pendingEnrichRequest = null;
    state.lastRuntimeError = null;
    state.pageSnapshot = null;
    state.selectionSnapshot = null;
    state.activeScope = "page";
    state.selectionPreview = null;
    state.selectionScopeMeta = null;
    state.runtimeSnapshot = null;
    state.currentTurnOrigin = null;
    state.contextSheetOpen = false;
    state.contextSheetContent = null;
    state.latestSemanticSnapshot = null;
    state.latestRegionDump = null;
    resetVoiceTranscriptState();
    resetConversationSurface();
    setVoiceActivityState("idle");
  }
  async function handleEscapeAction() {
    if (state.speechInputState === "listening" || state.speechInputState === "processing") {
      await cancelVoiceCapture();
      return;
    }
    if (state.menuOpen) {
      state.menuOpen = false;
      renderShell();
      return;
    }
    if (state.contextSheetOpen) {
      state.contextSheetOpen = false;
      renderShell();
      return;
    }
    if (state.activeScope === "selection") {
      await clearSelectionScope();
    }
  }
  async function prepareCurrentPage() {
    if (!isSupportedPage()) {
      state.latestSemanticSnapshot = {
        tabId: state.activeTabId,
        snapshot: null,
        error: "This page is not supported."
      };
      renderShell();
      return;
    }
    await requestSemanticSnapshot({ silent: true });
  }
  function registerRuntimeListeners() {
    if (typeof chrome === "undefined" || !chrome.runtime?.onMessage) {
      return;
    }
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === "ACTIVE_TAB_CHANGED") {
        const nextKey = `${message.payload.tabId}:${message.payload.url}`;
        const pageChanged = state.currentPageKey !== nextKey;
        state.activeTabId = message.payload.tabId;
        state.activeTabUrl = message.payload.url;
        state.activeTabTitle = message.payload.title || "ThreadAtlas";
        if (pageChanged) {
          state.currentPageKey = nextKey;
          resetForNewPage();
        }
        renderShell();
        void prepareCurrentPage();
        return;
      }
      if (message.type === "AUTH_STATE_CHANGED") {
        applyAuthState(message.payload);
        return;
      }
      if (message.type === "SEMANTIC_SNAPSHOT_READY") {
        updateSemanticSnapshot(message.payload);
        void hydrateSemanticRegionDump(message.payload.tabId ?? void 0);
        renderShell();
        return;
      }
      if (message.type === "PAGE_AUDIO_CAPTURE_READY") {
        return;
      }
      if (isPageTextSelectionChangedMessage(message)) {
        if (!message.payload.hasSelection || state.activeTabId === null || message.payload.tabId !== state.activeTabId || !isSupportedPage()) {
          return;
        }
        void captureSelectionScope(message.payload.textPreview);
      }
    });
  }
  async function hydrateActiveTabState() {
    if (typeof chrome === "undefined" || !chrome.tabs?.query) {
      return;
    }
    await new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        state.activeTabId = tab?.id ?? null;
        state.activeTabUrl = tab?.url ?? "";
        state.activeTabTitle = tab?.title ?? "ThreadAtlas";
        state.currentPageKey = typeof tab?.id === "number" && tab?.url ? `${tab.id}:${tab.url}` : null;
        resolve();
      });
    });
    renderShell();
    await prepareCurrentPage();
  }
  function createConversationController() {
    const controller = new ConversationController({
      apiBaseUrl: state.apiBaseUrl,
      authClient,
      getActiveTabId: () => state.activeTabId,
      sendToContentScript,
      addRuntimeListener(listener) {
        chrome.runtime.onMessage.addListener(
          listener
        );
      },
      removeRuntimeListener(listener) {
        chrome.runtime.onMessage.removeListener(
          listener
        );
      },
      ttsEnabled: state.ttsEnabled,
      handlers: {
        onPhaseChange(phase) {
          state.phase = phase;
          refreshVoiceVisualState();
          renderShell();
        },
        onSpeechStateChange(speechState, detail) {
          state.speechInputState = speechState;
          state.speechInputDetail = detail ?? null;
          refreshVoiceVisualState();
          renderShell();
        },
        onSessionReady() {
          state.lastRuntimeError = null;
        },
        onTurnStarted(event) {
          state.activeTurnId = event.turnId;
          state.lastRuntimeError = null;
          state.currentTurnOrigin = event.payload.modality;
          refreshVoiceVisualState();
          renderShell();
        },
        onInputTranscript(text, final, event) {
          if (event.turnId && state.currentTurnOrigin === "voice") {
            upsertVoiceUserTranscript(event.turnId, text, final);
          } else {
            upsertConversationMessage({
              id: `turn-user-${event.turnId}`,
              role: "user",
              text,
              pending: !final,
              turnId: event.turnId
            });
          }
          renderShell();
        },
        onOutputTranscript(text, final, event) {
          if (state.currentTurnOrigin === "voice") {
            upsertVoiceAssistantTranscript(event.turnId, text, final);
          }
          renderShell();
        },
        onProjection(projection, event) {
          if (projection.type === "respond") {
            if (state.currentTurnOrigin !== "voice") {
              appendConversationMessage({
                id: `turn-assistant-${event.turnId}`,
                role: "assistant",
                text: projection.payload.text,
                turnId: event.turnId,
                actions: {
                  copyText: projection.payload.text
                }
              });
            } else {
              updateTurnDecoration(event.turnId, {
                copyText: projection.payload.text
              });
            }
            renderShell();
            return;
          }
          if (projection.type === "present") {
            updateTurnDecoration(event.turnId, { contextContent: projection.payload.content });
            renderShell();
            return;
          }
          if (projection.type === "focus" || projection.type === "focusMultiple") {
            updateTurnDecoration(event.turnId, { highlightProjection: projection });
            renderShell();
            return;
          }
          void applyProjectionSideEffects(projection);
        },
        async onToolRequest(event) {
          state.pendingEnrichRequest = event;
          renderShell();
          try {
            return await handleRuntimeToolRequest(event);
          } finally {
            state.pendingEnrichRequest = null;
            renderShell();
          }
        },
        onTurnDone(event) {
          state.activeTurnId = null;
          state.pendingEnrichRequest = null;
          state.lastRuntimeError = null;
          state.runtimeSnapshot = null;
          if (Array.isArray(event.payload.provenanceSummary) && event.payload.provenanceSummary.length > 0) {
            updateTurnDecoration(event.turnId, {
              provenanceSummary: event.payload.provenanceSummary
            });
          }
          resetVoiceTranscriptState();
          refreshVoiceVisualState();
          renderShell();
        },
        onError(error) {
          state.activeTurnId = null;
          state.pendingEnrichRequest = null;
          state.lastRuntimeError = error;
          state.runtimeSnapshot = null;
          resetVoiceTranscriptState();
          refreshVoiceVisualState();
          showNotify(error.message, "error");
          renderShell();
        }
      }
    });
    controller.audioInput.onLevel = (level) => {
      pushSignalLevel(level);
      state.voiceActivityState = "listening";
      scheduleVoiceVisualDecay();
      renderShell();
    };
    controller.audioOutput.onLevel = (level) => {
      pushSignalLevel(level);
      state.voiceActivityState = "speaking";
      scheduleVoiceVisualDecay();
      renderShell();
    };
    return controller;
  }
  async function initialize() {
    const config = await loadExtensionConfig(createChromeLocalStorage());
    state.apiBaseUrl = config.apiBaseUrl;
    state.showInternalConsoleLauncher = Boolean(config.devBootstrap);
    state.conversationController = createConversationController();
    state.conversationController.setVoiceOutputEnabled(state.ttsEnabled);
    state.speechInputState = state.conversationController.inputSupported ? "idle" : "unsupported";
    bindConsumerShellActions({
      onComposerInput: (value) => {
        state.composerText = value;
        renderShell();
      },
      onSubmitPrompt: (prompt) => {
        void submitTextPrompt(prompt);
      },
      onStartMicPress: () => {
        void startVoiceCapture();
      },
      onEndMicPress: () => {
        void finishVoiceCapture();
      },
      onCancelMicPress: () => {
        void cancelVoiceCapture();
      },
      onToggleMenu: () => {
        toggleMenu();
      },
      onToggleVoiceOutput: () => {
        toggleVoiceOutput();
      },
      onSignIn: () => {
        void signInWithGoogle();
      },
      onSignOut: () => {
        void signOut();
      },
      onRecoveryPrimary: (kind) => {
        void handleRecovery(kind);
      },
      onCopyMessage: (messageId) => {
        void copyAssistantMessage(messageId);
      },
      onShowContext: (messageId) => {
        openContextSheet(messageId);
      },
      onHighlightMessage: (messageId) => {
        void highlightAssistantMessage(messageId);
      },
      onClearScope: () => {
        void clearSelectionScope();
      },
      onEscape: () => {
        void handleEscapeAction();
      },
      onOpenInternalConsole: () => {
        openInternalConsole();
      },
      onCloseContextSheet: () => {
        state.contextSheetOpen = false;
        renderShell();
      }
    });
    renderShell();
    registerRuntimeListeners();
    await Promise.all([hydrateActiveTabState(), hydrateAuthState()]);
    window.addEventListener("beforeunload", () => {
      void state.conversationController?.close();
    });
  }
  void initialize().catch((error) => {
    showNotify(error instanceof Error ? error.message : "failed to initialize", "error");
  });
})();
//# sourceMappingURL=sidepanel.js.map
