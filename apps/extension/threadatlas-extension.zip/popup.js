"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // ../../packages/shared/dist/types/api.js
  var require_api = __commonJS({
    "../../packages/shared/dist/types/api.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/auth-session.js
  var require_auth_session = __commonJS({
    "../../packages/shared/dist/types/auth-session.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/article.js
  var require_article = __commonJS({
    "../../packages/shared/dist/types/article.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context.js
  var require_context = __commonJS({
    "../../packages/shared/dist/types/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/context-pack.js
  var require_context_pack = __commonJS({
    "../../packages/shared/dist/types/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/intent.js
  var require_intent = __commonJS({
    "../../packages/shared/dist/types/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/memory.js
  var require_memory = __commonJS({
    "../../packages/shared/dist/types/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/projection.js
  var require_projection = __commonJS({
    "../../packages/shared/dist/types/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantic-snapshot.js
  var require_semantic_snapshot = __commonJS({
    "../../packages/shared/dist/types/semantic-snapshot.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/semantics.js
  var require_semantics = __commonJS({
    "../../packages/shared/dist/types/semantics.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/state.js
  var require_state = __commonJS({
    "../../packages/shared/dist/types/state.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/types/thread.js
  var require_thread = __commonJS({
    "../../packages/shared/dist/types/thread.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
    }
  });

  // ../../packages/shared/dist/constants/limits.js
  var require_limits = __commonJS({
    "../../packages/shared/dist/constants/limits.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.MAX_ACTIVE_TOPICS = exports.MAX_CONTEXT_TURNS = exports.TOKEN_RENEWAL_BUFFER_SECONDS = exports.TOKEN_TTL_SECONDS = exports.TOOL_TIMEOUT_MS = exports.LOOP_TIMEOUT_MS = exports.MAX_LOOPS = void 0;
      exports.MAX_LOOPS = 8;
      exports.LOOP_TIMEOUT_MS = 3e4;
      exports.TOOL_TIMEOUT_MS = 1e4;
      exports.TOKEN_TTL_SECONDS = 600;
      exports.TOKEN_RENEWAL_BUFFER_SECONDS = 120;
      exports.MAX_CONTEXT_TURNS = 10;
      exports.MAX_ACTIVE_TOPICS = 10;
    }
  });

  // ../../packages/shared/dist/constants/defaults.js
  var require_defaults = __commonJS({
    "../../packages/shared/dist/constants/defaults.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.CONTEXT_LIMITS = exports.EMPTY_CONVERSATION_CONTEXT = exports.DEFAULT_API_BASE_URL = exports.DEFAULT_USER_ID = void 0;
      var limits_1 = require_limits();
      exports.DEFAULT_USER_ID = "user_sungwoo";
      exports.DEFAULT_API_BASE_URL = "http://localhost:8080";
      exports.EMPTY_CONVERSATION_CONTEXT = {
        turns: [],
        activeTopics: [],
        threadUrl: ""
      };
      exports.CONTEXT_LIMITS = {
        maxTurns: limits_1.MAX_CONTEXT_TURNS,
        maxActiveTopics: limits_1.MAX_ACTIVE_TOPICS
      };
    }
  });

  // ../../packages/shared/dist/utils/context.js
  var require_context2 = __commonJS({
    "../../packages/shared/dist/utils/context.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.trimTurns = trimTurns;
      exports.appendTurn = appendTurn;
      exports.setActiveTopics = setActiveTopics;
      var defaults_1 = require_defaults();
      function trimTurns(turns) {
        if (turns.length <= defaults_1.CONTEXT_LIMITS.maxTurns) {
          return turns;
        }
        return turns.slice(turns.length - defaults_1.CONTEXT_LIMITS.maxTurns);
      }
      function appendTurn(context, turn) {
        return {
          ...context,
          turns: trimTurns([...context.turns, turn])
        };
      }
      function setActiveTopics(context, topics) {
        return {
          ...context,
          activeTopics: topics.slice(0, defaults_1.CONTEXT_LIMITS.maxActiveTopics)
        };
      }
    }
  });

  // ../../packages/shared/dist/utils/hash.js
  var require_hash = __commonJS({
    "../../packages/shared/dist/utils/hash.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.hashUrl = hashUrl;
      function intToFixedHex(value) {
        return (value >>> 0).toString(16).padStart(8, "0");
      }
      function hashUrl(url) {
        let h1 = 2654435769;
        let h2 = 2246822507;
        for (let i = 0; i < url.length; i += 1) {
          const code = url.charCodeAt(i);
          h1 = Math.imul(h1 ^ code, 2246822519);
          h2 = Math.imul(h2 ^ code, 3266489917);
        }
        return `${intToFixedHex(h1)}${intToFixedHex(h2)}`.slice(0, 16);
      }
    }
  });

  // ../../packages/shared/dist/utils/context-pack.js
  var require_context_pack2 = __commonJS({
    "../../packages/shared/dist/utils/context-pack.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = buildContextPack;
      exports.selectProjectionView = selectProjectionView;
      exports.renderContextPack = renderContextPack;
      exports.renderCompactJson = renderCompactJson;
      exports.renderLinearText = renderLinearText;
      function isCommentNode(node) {
        return node.kind === "comment";
      }
      function isInteractiveNode(node) {
        return node.kind === "interactive";
      }
      function toContextPackNode(node, relation, distance) {
        if (isCommentNode(node)) {
          return {
            id: node.id,
            kind: "comment",
            relation,
            distance,
            text: node.text,
            ...node.author ? { author: node.author } : {},
            ...node.timestamp ? { timestamp: node.timestamp } : {},
            depth: node.depth,
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        if (isInteractiveNode(node)) {
          return {
            id: node.id,
            kind: "interactive",
            relation,
            distance,
            text: node.label ?? node.valuePreview ?? "",
            controlType: node.controlType,
            ...node.action ? { action: node.action } : {},
            ...node.state ? { state: node.state } : {},
            ...node.role ? { role: node.role } : {},
            ...node.valuePreview ? { valuePreview: node.valuePreview } : {},
            ...node.label ? { label: node.label } : {},
            ...node.parentId ? { parentId: node.parentId } : {},
            ...node.metadata ? { metadata: node.metadata } : {}
          };
        }
        return {
          id: node.id,
          kind: "content",
          relation,
          distance,
          text: node.text,
          contentType: node.type,
          ...node.level ? { level: node.level } : {},
          ...node.parentId ? { parentId: node.parentId } : {},
          ...node.attributes ? { metadata: node.attributes } : {}
        };
      }
      function mapSlices(snapshot, relation) {
        return snapshot.context.map((slice, originalIndex) => ({ slice, originalIndex })).filter(({ slice }) => slice.relation === relation).map(({ slice, originalIndex }) => ({
          ...toContextPackNode(slice.node, relation === "child" ? "descendant" : relation === "container" ? "container" : relation === "sibling" ? "sibling" : "ancestor", slice.distance),
          originalIndex
        }));
      }
      function buildOmitted(snapshot) {
        const coverage = snapshot.meta.coverage;
        if (!coverage) {
          return {
            nodeCount: 0,
            rootCount: 0,
            note: "Coverage metadata unavailable."
          };
        }
        return {
          nodeCount: coverage.omittedNodeCount,
          rootCount: coverage.omittedRootCount,
          note: `Only the ${coverage.kind} semantic scope is included.`
        };
      }
      function buildScope(snapshot) {
        const coverage = snapshot.meta.coverage;
        return {
          kind: coverage?.kind ?? (isCommentNode(snapshot.focus.node) ? "focus-branch" : "focus-section"),
          rootNodeId: coverage?.rootNodeId ?? snapshot.focus.nodeId,
          focusNodeId: snapshot.focus.nodeId
        };
      }
      function buildProjectionFocusNode(pack) {
        const { metadata: _metadata, relation: _relation, distance: _distance, ...focus } = pack.focus;
        return focus;
      }
      function includeByProfile(node, group, profile) {
        if (group === "containers") {
          return false;
        }
        if (profile === "branch-summary") {
          return true;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        if (group === "ancestors") {
          return node.distance === 1;
        }
        if (group === "descendants") {
          return node.distance === 1;
        }
        if (group === "siblings") {
          return node.distance === 1;
        }
        return false;
      }
      function formatNodeSummary(node) {
        const headerParts = [
          node.author,
          node.timestamp,
          node.kind === "interactive" && node.controlType ? node.controlType : null,
          node.kind === "interactive" && node.action ? node.action : null,
          node.kind === "interactive" && node.state ? node.state : null,
          node.kind === "content" && node.contentType ? node.contentType : null
        ].filter(Boolean);
        if (headerParts.length === 0) {
          return `- ${node.text || node.valuePreview || "(empty)"}`;
        }
        return `- ${headerParts.join(", ")}: ${node.text || node.valuePreview || "(empty)"}`;
      }
      function buildContextPack(snapshot) {
        const ancestors = [
          ...mapSlices(snapshot, "parent"),
          ...mapSlices(snapshot, "ancestor")
        ].sort((left, right) => right.distance - left.distance || left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const descendants = mapSlices(snapshot, "child").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const siblings = mapSlices(snapshot, "sibling").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        const containers = mapSlices(snapshot, "container").sort((left, right) => left.originalIndex - right.originalIndex).map(({ originalIndex: _originalIndex, ...node }) => node);
        return {
          version: 1,
          scope: buildScope(snapshot),
          page: {
            id: snapshot.page.id,
            url: snapshot.page.url,
            ...snapshot.page.title ? { title: snapshot.page.title } : {},
            kind: snapshot.page.kind,
            ...snapshot.page.metadata ? { metadata: snapshot.page.metadata } : {}
          },
          focus: toContextPackNode(snapshot.focus.node, "focus", 0),
          groups: {
            ancestors,
            descendants,
            siblings,
            containers
          },
          omitted: buildOmitted(snapshot),
          provenance: {
            extractorId: snapshot.meta.extractorId,
            capturedAt: snapshot.meta.capturedAt,
            skeletonVersion: snapshot.meta.skeletonVersion
          }
        };
      }
      function selectProjectionView(pack, profile) {
        const groups = {
          ancestors: pack.groups.ancestors.filter((node) => includeByProfile(node, "ancestors", profile)),
          descendants: pack.groups.descendants.filter((node) => includeByProfile(node, "descendants", profile)),
          siblings: pack.groups.siblings.filter((node) => includeByProfile(node, "siblings", profile)),
          containers: pack.groups.containers.filter((node) => includeByProfile(node, "containers", profile))
        };
        return {
          scope: pack.scope,
          page: {
            ...pack.page.title ? { title: pack.page.title } : {},
            url: pack.page.url,
            kind: pack.page.kind
          },
          focus: buildProjectionFocusNode(pack),
          groups,
          omitted: pack.omitted,
          provenance: {
            extractorId: pack.provenance.extractorId,
            capturedAt: pack.provenance.capturedAt
          }
        };
      }
      function renderContextPack(pack) {
        return JSON.stringify(pack, null, 2);
      }
      function renderCompactJson(pack, profile) {
        return JSON.stringify(selectProjectionView(pack, profile), null, 2);
      }
      function renderLinearText(pack, profile) {
        const view = selectProjectionView(pack, profile);
        const lines = [
          `Page: ${view.page.title ?? "(untitled)"}`,
          `URL: ${view.page.url}`,
          `Kind: ${view.page.kind}`,
          `Scope: ${view.scope.kind}`,
          ""
        ];
        const sections = [
          ["Ancestors", view.groups.ancestors],
          ["Focus", [pack.focus]],
          ["Descendants", view.groups.descendants],
          ["Siblings", view.groups.siblings]
        ];
        for (const [label, nodes] of sections) {
          const groupKey = label === "Ancestors" ? "ancestors" : label === "Descendants" ? "descendants" : label === "Siblings" ? "siblings" : null;
          if (groupKey && !projectionIncludesGroup(profile, groupKey)) {
            continue;
          }
          lines.push(label);
          if (nodes.length === 0) {
            lines.push("- none");
          } else {
            for (const node of nodes) {
              lines.push(formatNodeSummary(node));
            }
          }
          lines.push("");
        }
        lines.push("Omitted");
        lines.push(`- ${view.omitted.nodeCount} nodes omitted`);
        lines.push(`- ${view.omitted.rootCount} roots omitted`);
        lines.push(`- ${view.omitted.note}`);
        return lines.join("\n");
      }
      function projectionIncludesGroup(profile, group) {
        if (group === "containers") {
          return false;
        }
        if (profile === "claim-extraction") {
          return group !== "siblings";
        }
        return true;
      }
    }
  });

  // ../../packages/shared/dist/factories/intent.js
  var require_intent2 = __commonJS({
    "../../packages/shared/dist/factories/intent.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createUserSpeechIntent = createUserSpeechIntent;
      exports.createUserSelectionIntent = createUserSelectionIntent;
      exports.createPageNavigationIntent = createPageNavigationIntent;
      function createUserSpeechIntent(transcript, intentType = "general") {
        return {
          type: "UserSpeech",
          transcript,
          intentType
        };
      }
      function createUserSelectionIntent(transcript) {
        return {
          type: "UserSelection",
          transcript,
          intentType: "memory_query"
        };
      }
      function createPageNavigationIntent(transcript) {
        return {
          type: "PageNavigation",
          transcript,
          intentType: "navigation_request"
        };
      }
    }
  });

  // ../../packages/shared/dist/factories/memory.js
  var require_memory2 = __commonJS({
    "../../packages/shared/dist/factories/memory.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.createEmptyInterestProfile = createEmptyInterestProfile;
      exports.createMemoryDelta = createMemoryDelta;
      exports.mergeTopicDeltas = mergeTopicDeltas;
      function createEmptyInterestProfile() {
        return {
          topics: {},
          updatedAt: Date.now()
        };
      }
      function createMemoryDelta(topicDeltas, highlights = []) {
        return {
          interestProfile: { topicDeltas },
          threadHistory: {
            highlights,
            turnCountDelta: 1
          }
        };
      }
      function mergeTopicDeltas(base, incoming) {
        const merged = { ...base };
        for (const [topic, count] of Object.entries(incoming)) {
          merged[topic] = (merged[topic] ?? 0) + count;
        }
        return merged;
      }
    }
  });

  // ../../packages/shared/dist/factories/projection.js
  var require_projection2 = __commonJS({
    "../../packages/shared/dist/factories/projection.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.respond = respond;
      exports.focus = focus;
      exports.focusMultiple = focusMultiple;
      exports.navigate = navigate;
      exports.present = present;
      exports.notify = notify;
      exports.copy = copy;
      function respond(text, mode = "answer") {
        return { type: "respond", payload: { text, mode } };
      }
      function focus(commentId, options) {
        if (options) {
          return { type: "focus", payload: { commentId, options } };
        }
        return { type: "focus", payload: { commentId } };
      }
      function focusMultiple(targets, options) {
        if (options) {
          return { type: "focusMultiple", payload: { targets, options } };
        }
        return { type: "focusMultiple", payload: { targets } };
      }
      function navigate(url, options) {
        if (options) {
          return { type: "navigate", payload: { url, options } };
        }
        return { type: "navigate", payload: { url } };
      }
      function present(target, content, persistent = false) {
        return {
          type: "present",
          payload: {
            target,
            content,
            options: { persistent }
          }
        };
      }
      function notify(message, level = "info") {
        return {
          type: "notify",
          payload: { message, level }
        };
      }
      function copy(text) {
        return { type: "copy", payload: { text } };
      }
    }
  });

  // ../../packages/shared/dist/domain.js
  var require_domain = __commonJS({
    "../../packages/shared/dist/domain.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.buildContextPack = void 0;
      __exportStar(require_api(), exports);
      __exportStar(require_auth_session(), exports);
      __exportStar(require_article(), exports);
      __exportStar(require_context(), exports);
      __exportStar(require_context_pack(), exports);
      __exportStar(require_intent(), exports);
      __exportStar(require_memory(), exports);
      __exportStar(require_projection(), exports);
      __exportStar(require_semantic_snapshot(), exports);
      __exportStar(require_semantics(), exports);
      __exportStar(require_state(), exports);
      __exportStar(require_thread(), exports);
      __exportStar(require_defaults(), exports);
      __exportStar(require_limits(), exports);
      __exportStar(require_context2(), exports);
      __exportStar(require_hash(), exports);
      var context_pack_1 = require_context_pack2();
      Object.defineProperty(exports, "buildContextPack", { enumerable: true, get: function() {
        return context_pack_1.buildContextPack;
      } });
      __exportStar(require_intent2(), exports);
      __exportStar(require_memory2(), exports);
      __exportStar(require_projection2(), exports);
    }
  });

  // ../../packages/shared/dist/index.js
  var require_dist = __commonJS({
    "../../packages/shared/dist/index.js"(exports) {
      "use strict";
      var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function() {
            return m[k];
          } };
        }
        Object.defineProperty(o, k2, desc);
      }) : (function(o, m, k, k2) {
        if (k2 === void 0) k2 = k;
        o[k2] = m[k];
      }));
      var __exportStar = exports && exports.__exportStar || function(m, exports2) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
      };
      Object.defineProperty(exports, "__esModule", { value: true });
      __exportStar(require_domain(), exports);
    }
  });

  // src/common/extension-config.ts
  var import_shared = __toESM(require_dist());
  var API_BASE_URL_KEY = "THREADATLAS_API_BASE_URL";
  var GOOGLE_OAUTH_CLIENT_ID_KEY = "THREADATLAS_GOOGLE_OAUTH_CLIENT_ID";
  var AUTH_GRANT_TYPE_KEY = "THREADATLAS_AUTH_GRANT_TYPE";
  var BOOTSTRAP_SUBJECT_KEY = "THREADATLAS_BOOTSTRAP_SUBJECT";
  var BOOTSTRAP_KEY_KEY = "THREADATLAS_AUTH_BOOTSTRAP_KEY";
  var DISPLAY_NAME_KEY = "THREADATLAS_AUTH_DISPLAY_NAME";
  var PRIMARY_EMAIL_KEY = "THREADATLAS_AUTH_PRIMARY_EMAIL";
  var AVATAR_URL_KEY = "THREADATLAS_AUTH_AVATAR_URL";
  var EXTENSION_CONFIG_KEYS = [
    API_BASE_URL_KEY,
    GOOGLE_OAUTH_CLIENT_ID_KEY,
    AUTH_GRANT_TYPE_KEY,
    BOOTSTRAP_SUBJECT_KEY,
    BOOTSTRAP_KEY_KEY,
    DISPLAY_NAME_KEY,
    PRIMARY_EMAIL_KEY,
    AVATAR_URL_KEY
  ];
  function normalizeText(value) {
    if (typeof value !== "string") {
      return null;
    }
    const normalized = value.trim();
    return normalized.length > 0 ? normalized : null;
  }
  function readCompiledApiBaseUrl() {
    if (true) {
      const normalized = normalizeText("http://localhost:8080");
      if (normalized) {
        return normalized;
      }
    }
    return import_shared.DEFAULT_API_BASE_URL;
  }
  function readCompiledGoogleClientId() {
    if (true) {
      return normalizeText("");
    }
    return null;
  }
  function createChromeLocalStorage(area = chrome.storage.local) {
    return {
      get(keys) {
        return new Promise((resolve, reject) => {
          area.get(keys, (items) => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve(items);
          });
        });
      },
      set(values) {
        return new Promise((resolve, reject) => {
          area.set(values, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      },
      remove(keys) {
        return new Promise((resolve, reject) => {
          area.remove(keys, () => {
            const runtimeError = chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            resolve();
          });
        });
      }
    };
  }
  async function loadExtensionConfig(storage = createChromeLocalStorage()) {
    const stored = await storage.get(EXTENSION_CONFIG_KEYS);
    const apiBaseUrl = normalizeText(stored[API_BASE_URL_KEY]) ?? readCompiledApiBaseUrl();
    const googleOAuthClientId = normalizeText(stored[GOOGLE_OAUTH_CLIENT_ID_KEY]) ?? readCompiledGoogleClientId();
    const configuredGrant = normalizeText(stored[AUTH_GRANT_TYPE_KEY]);
    const bootstrapSubject = normalizeText(stored[BOOTSTRAP_SUBJECT_KEY]);
    const bootstrapKey = normalizeText(stored[BOOTSTRAP_KEY_KEY]);
    let devBootstrap = null;
    if (configuredGrant === "dev-bootstrap" && bootstrapSubject && bootstrapKey) {
      const profile = {};
      const displayName = normalizeText(stored[DISPLAY_NAME_KEY]);
      const primaryEmail = normalizeText(stored[PRIMARY_EMAIL_KEY]);
      const avatarUrl = normalizeText(stored[AVATAR_URL_KEY]);
      if (displayName) {
        profile.displayName = displayName;
      }
      if (primaryEmail) {
        profile.primaryEmail = primaryEmail;
      }
      if (avatarUrl) {
        profile.avatarUrl = avatarUrl;
      }
      devBootstrap = {
        bootstrapSubject,
        bootstrapKey,
        ...Object.keys(profile).length > 0 ? { profile } : {}
      };
    }
    return {
      apiBaseUrl,
      googleOAuthClientId,
      devBootstrap
    };
  }

  // src/popup/index.ts
  function getElement(id) {
    return document.getElementById(id);
  }
  function renderPopupState(state) {
    const status = getElement("popup-status");
    const summary = getElement("popup-summary");
    const internalButton = getElement("popup-open-console-button");
    if (!status || !summary || !internalButton) {
      return;
    }
    status.textContent = state.status;
    summary.textContent = state.summary;
    internalButton.classList.toggle("hidden", !state.showInternalConsole);
  }
  function bindPopupActions(args) {
    getElement("popup-open-sidepanel-button")?.addEventListener("click", args.onOpenSidepanel);
    getElement("popup-open-console-button")?.addEventListener("click", args.onOpenInternalConsole);
  }
  async function getActiveTabId() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0]?.id ?? null;
  }
  async function openSidepanel() {
    const tabId = await getActiveTabId();
    if (typeof tabId !== "number") {
      return;
    }
    await chrome.sidePanel.open({ tabId });
  }
  async function openInternalConsole() {
    await chrome.tabs.create({
      url: chrome.runtime.getURL("console.html"),
      active: true
    });
  }
  async function initializePopup() {
    bindPopupActions({
      onOpenSidepanel: () => {
        void openSidepanel();
      },
      onOpenInternalConsole: () => {
        void openInternalConsole();
      }
    });
    const config = await loadExtensionConfig(createChromeLocalStorage());
    renderPopupState({
      showInternalConsole: Boolean(config.devBootstrap),
      status: "Open the assistant sidepanel to ask by voice or text.",
      summary: config.devBootstrap ? "Internal preview mode is available on this build." : "Current-page assistant is ready."
    });
  }
  if (typeof document !== "undefined" && typeof chrome !== "undefined" && chrome.tabs && chrome.runtime) {
    void initializePopup();
  }
})();
//# sourceMappingURL=popup.js.map
