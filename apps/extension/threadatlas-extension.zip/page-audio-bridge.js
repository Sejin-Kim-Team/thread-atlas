"use strict";
(() => {
  // src/content/page-audio-bridge.ts
  var PCM_CHUNK_SAMPLES = 2048;
  function float32ToInt16(input) {
    const output = new Int16Array(input.length);
    for (let index = 0; index < input.length; index += 1) {
      const sample = Math.max(-1, Math.min(1, input[index] ?? 0));
      output[index] = sample < 0 ? sample * 32768 : sample * 32767;
    }
    return output;
  }
  function concatInt16Arrays(chunks) {
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const output = new Int16Array(total);
    let offset = 0;
    for (const chunk of chunks) {
      output.set(chunk, offset);
      offset += chunk.length;
    }
    return output;
  }
  function int16ToBase64(chunk) {
    const bytes = new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength);
    let binary = "";
    const blockSize = 32768;
    for (let offset = 0; offset < bytes.length; offset += blockSize) {
      const slice = bytes.subarray(offset, Math.min(offset + blockSize, bytes.length));
      binary += String.fromCharCode(...slice);
    }
    return btoa(binary);
  }
  function postToContent(type, payload) {
    window.postMessage(
      {
        source: "threadatlas-page-audio",
        type,
        payload
      },
      "*"
    );
  }
  function mapCaptureError(error) {
    const name = typeof error === "object" && error !== null && "name" in error ? String(error.name) : "";
    const message = typeof error === "object" && error !== null && "message" in error ? String(error.message ?? "") : "";
    if (typeof navigator?.mediaDevices?.getUserMedia !== "function" || typeof AudioContext === "undefined" || typeof AudioWorkletNode === "undefined") {
      return {
        state: "unsupported",
        detail: "Voice input is unavailable on this page."
      };
    }
    switch (name) {
      case "NotAllowedError":
      case "PermissionDeniedError":
      case "SecurityError":
        return {
          state: "error",
          detail: message.toLowerCase().includes("dismissed") ? "Microphone permission was dismissed." : "Microphone permission was denied."
        };
      case "NotFoundError":
        return {
          state: "error",
          detail: "No microphone was found."
        };
      case "NotReadableError":
      case "TrackStartError":
        return {
          state: "error",
          detail: "Microphone capture failed."
        };
      default:
        return {
          state: "error",
          detail: message.trim().length > 0 ? message : "Voice capture failed on this page."
        };
    }
  }
  function stopStream(stream) {
    stream?.getTracks().forEach((track) => track.stop());
  }
  function resolveWorkletUrl() {
    const bridgeScript = document.currentScript;
    if (!(bridgeScript instanceof HTMLScriptElement) || !bridgeScript.src) {
      return null;
    }
    return new URL("audio-input-worklet.js", bridgeScript.src).toString();
  }
  function initializePageAudioBridge() {
    const workletUrl = resolveWorkletUrl();
    let activeSessionId = null;
    let captureGeneration = 0;
    let currentState = "idle";
    let stream = null;
    let audioContext = null;
    let sourceNode = null;
    let workletNode = null;
    let sinkNode = null;
    let pendingChunks = [];
    let pendingSamples = 0;
    const emitState = (sessionId, state, detail) => {
      currentState = state;
      postToContent("THREADATLAS_PAGE_AUDIO_STATE", {
        sessionId,
        state,
        ...detail ? { detail } : {}
      });
    };
    const flushPendingChunks = (sessionId) => {
      if (pendingSamples === 0 || pendingChunks.length === 0) {
        return;
      }
      const merged = concatInt16Arrays(pendingChunks);
      pendingChunks = [];
      pendingSamples = 0;
      postToContent("THREADATLAS_PAGE_AUDIO_CHUNK", {
        sessionId,
        chunkBase64: int16ToBase64(merged)
      });
    };
    const clearPendingChunks = () => {
      pendingChunks = [];
      pendingSamples = 0;
    };
    const closeActiveCapture = async (flush) => {
      const sessionId = activeSessionId;
      if (flush && sessionId) {
        flushPendingChunks(sessionId);
      } else {
        clearPendingChunks();
      }
      workletNode?.disconnect();
      sourceNode?.disconnect();
      sinkNode?.disconnect();
      stopStream(stream);
      workletNode = null;
      sourceNode = null;
      sinkNode = null;
      stream = null;
      if (audioContext) {
        await audioContext.close();
        audioContext = null;
      }
    };
    const resetCaptureState = () => {
      activeSessionId = null;
      currentState = "idle";
      clearPendingChunks();
    };
    const cancelCapture = async (sessionId) => {
      const currentSessionId = activeSessionId;
      if (!currentSessionId || sessionId && sessionId !== currentSessionId) {
        return;
      }
      captureGeneration += 1;
      await closeActiveCapture(false);
      emitState(currentSessionId, "idle");
      resetCaptureState();
    };
    const stopCapture = async (sessionId) => {
      if (!activeSessionId || activeSessionId !== sessionId) {
        return;
      }
      captureGeneration += 1;
      await closeActiveCapture(true);
      emitState(sessionId, "idle");
      resetCaptureState();
    };
    const startCapture = async (sessionId) => {
      await cancelCapture();
      if (typeof navigator?.mediaDevices?.getUserMedia !== "function" || typeof AudioContext === "undefined" || typeof AudioWorkletNode === "undefined" || !workletUrl) {
        emitState(sessionId, "unsupported", "Voice input is unavailable on this page.");
        return;
      }
      const generation = ++captureGeneration;
      activeSessionId = sessionId;
      emitState(sessionId, "processing");
      let nextStream = null;
      let nextAudioContext = null;
      let nextSourceNode = null;
      let nextWorkletNode = null;
      let nextSinkNode = null;
      try {
        nextStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        nextAudioContext = new AudioContext({ sampleRate: 16e3 });
        await nextAudioContext.audioWorklet.addModule(workletUrl);
        await nextAudioContext.resume();
        if (activeSessionId !== sessionId || captureGeneration !== generation) {
          stopStream(nextStream);
          await nextAudioContext.close();
          return;
        }
        nextSourceNode = nextAudioContext.createMediaStreamSource(nextStream);
        nextWorkletNode = new AudioWorkletNode(nextAudioContext, "pcm-capture-processor");
        nextSinkNode = nextAudioContext.createGain();
        nextSinkNode.gain.value = 0;
        nextWorkletNode.port.onmessage = (event) => {
          if (activeSessionId !== sessionId || captureGeneration !== generation) {
            return;
          }
          const chunk = float32ToInt16(event.data);
          pendingChunks.push(chunk);
          pendingSamples += chunk.length;
          if (pendingSamples >= PCM_CHUNK_SAMPLES) {
            flushPendingChunks(sessionId);
          }
        };
        nextSourceNode.connect(nextWorkletNode);
        nextWorkletNode.connect(nextSinkNode);
        nextSinkNode.connect(nextAudioContext.destination);
        stream = nextStream;
        audioContext = nextAudioContext;
        sourceNode = nextSourceNode;
        workletNode = nextWorkletNode;
        sinkNode = nextSinkNode;
        emitState(sessionId, "listening");
      } catch (error) {
        nextWorkletNode?.disconnect();
        nextSourceNode?.disconnect();
        nextSinkNode?.disconnect();
        stopStream(nextStream);
        if (nextAudioContext) {
          try {
            await nextAudioContext.close();
          } catch {
          }
        }
        if (activeSessionId !== sessionId || captureGeneration !== generation) {
          return;
        }
        const failure = mapCaptureError(error);
        emitState(sessionId, failure.state, failure.detail);
        resetCaptureState();
      }
    };
    window.addEventListener("message", (event) => {
      if (event.source !== window) {
        return;
      }
      const data = event.data;
      if (!data || data.source !== "threadatlas-content-audio") {
        return;
      }
      switch (data.type) {
        case "THREADATLAS_PAGE_AUDIO_START":
          void startCapture(data.payload.sessionId);
          return;
        case "THREADATLAS_PAGE_AUDIO_STOP":
          void stopCapture(data.payload.sessionId);
          return;
        case "THREADATLAS_PAGE_AUDIO_CANCEL":
          void cancelCapture(data.payload.sessionId);
          return;
      }
    });
  }
  if (window.__threadatlasPageAudioBridgeInitialized__) {
    postToContent("THREADATLAS_PAGE_AUDIO_READY", {});
  } else {
    window.__threadatlasPageAudioBridgeInitialized__ = true;
    initializePageAudioBridge();
    postToContent("THREADATLAS_PAGE_AUDIO_READY", {});
  }
})();
//# sourceMappingURL=page-audio-bridge.js.map
